#!/bin/bash
# Upload only the scoped payload; credentials are entered into the user's terminal.
set -Eeuo pipefail
umask 077

antispam_package_dir="$(cd "$(dirname "$0")" && pwd -P)"
antispam_temp_dir="$(mktemp -d /tmp/datang-antispam-upgrade.XXXXXX)"
antispam_remote="root@159.65.128.173"
antispam_ssh_opts=(-o ControlMaster=auto -o ControlPersist=120 -o "ControlPath=$antispam_temp_dir/ssh.sock")

on_error() {
  echo "更新未完成。请把错误信息发来，不要发送密码或 Token。"
  read -r -p "按回车保留并退出本窗口。" || true
}
trap on_error ERR

echo "将升级 159.65.128.173 上的独立删广告机器人，保留原配置和数据库。"
echo "如提示密码，请输入服务器密码（输入时不显示字符）；不要在聊天里发送。"
COPYFILE_DISABLE=1 tar -czf "$antispam_temp_dir/payload.tar.gz" \
  -C "$antispam_package_dir" \
  src/antispam_bot/bot.py src/antispam_bot/classifier.py src/antispam_bot/version.py \
  src/antispam_bot/ad_rules.py \
  src/antispam_bot/content.py \
  src/antispam_bot/admin.py \
  scripts/upgrade_server.py scripts/smoke_upgrade.py payload-manifest.json

antispam_remote_dir="$(ssh "${antispam_ssh_opts[@]}" "$antispam_remote" \
  'umask 077; mktemp -d /root/datang-antispam-upgrade-v1.0.9.XXXXXX')"
if [[ ! "$antispam_remote_dir" =~ ^/root/datang-antispam-upgrade-v1\.0\.9\.[a-zA-Z0-9]+$ ]]; then
  echo "服务器没有返回有效的升级目录，已停止。"
  exit 1
fi
scp "${antispam_ssh_opts[@]}" "$antispam_temp_dir/payload.tar.gz" \
  "$antispam_remote:$antispam_remote_dir/payload.tar.gz"
ssh "${antispam_ssh_opts[@]}" "$antispam_remote" \
  "tar -xzf '$antispam_remote_dir/payload.tar.gz' -C '$antispam_remote_dir' && python3 '$antispam_remote_dir/scripts/upgrade_server.py'"
echo "工具执行结束。请在群内发送 /status，确认规则版本为 1.0.9。"
read -r -p "按回车退出。" || true
