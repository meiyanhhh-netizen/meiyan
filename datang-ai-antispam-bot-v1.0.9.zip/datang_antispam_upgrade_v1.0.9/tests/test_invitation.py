from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from aiogram.exceptions import TelegramBadRequest
from test_bot import _service

from antispam_bot.config import Settings


def event(*, old="left", new="member", actor=42, chat_type="supergroup"):
    return SimpleNamespace(
        chat=SimpleNamespace(id=-100123, type=chat_type, title="群", username=None),
        from_user=SimpleNamespace(id=actor, is_bot=False),
        old_chat_member=SimpleNamespace(status=old, is_member=False),
        new_chat_member=SimpleNamespace(status=new, is_member=True),
    )


@pytest.mark.parametrize("status", ["creator", "administrator"])
async def test_group_admin_can_invite(status):
    service = _service()
    service.bot.get_chat_member.return_value = SimpleNamespace(status=status)
    await service.on_my_chat_member(event())
    service.bot.leave_chat.assert_not_awaited()
    service.bot.get_chat_member.assert_awaited_once_with(-100123, 42)
    service.bot.send_message.assert_awaited_once()


@pytest.mark.parametrize("old", ["left", "kicked", "restricted"])
async def test_ordinary_member_invitation_leaves_even_if_bot_owner(old):
    service = _service(settings=Settings(owner_ids=frozenset({42})))
    service.bot.get_chat_member.return_value = SimpleNamespace(status="member")
    # The moderation exemption/cache must never grant invitation permission.
    service.is_admin = AsyncMock(return_value=True)
    await service.on_my_chat_member(event(old=old))
    service.bot.leave_chat.assert_awaited_once_with(-100123)
    assert service.database.upsert_chat.await_args.kwargs["is_enabled"] is False
    service.database.log_audit.assert_awaited_once()
    service.bot.ban_chat_member.assert_not_awaited()


async def test_admin_list_fallback_before_bot_promotion():
    service = _service()
    service.bot.get_chat_member.side_effect = TelegramBadRequest(method=None, message="lookup")
    service.bot.get_chat_administrators.return_value = [
        SimpleNamespace(user=SimpleNamespace(id=42), status="administrator")
    ]
    await service.on_my_chat_member(event())
    service.bot.leave_chat.assert_not_awaited()


async def test_unverified_invitation_and_failed_leave_stay_disabled():
    service = _service()
    service.bot.get_chat_member.side_effect = TelegramBadRequest(method=None, message="lookup")
    service.bot.get_chat_administrators.side_effect = TelegramBadRequest(
        method=None, message="lookup"
    )
    service.bot.leave_chat.side_effect = TelegramBadRequest(method=None, message="leave")
    await service.on_my_chat_member(event(new="administrator"))
    assert service.database.upsert_chat.await_args.kwargs["is_enabled"] is False
    assert service.database.log_audit.await_args.kwargs["details"]["left"] is False


async def test_existing_group_promotion_does_not_recheck_inviter():
    service = _service()
    service.missing_bot_permissions = AsyncMock(return_value=["can_delete_messages"])
    await service.on_my_chat_member(event(old="member", new="administrator"))
    service.bot.get_chat_member.assert_not_awaited()
    service.bot.leave_chat.assert_not_awaited()


async def test_verified_direct_admin_addition_activates_normally():
    service = _service()
    service.bot.get_chat_member.return_value = SimpleNamespace(status="creator")
    service.missing_bot_permissions = AsyncMock(return_value=[])
    service.spawn = lambda task: task.close()
    await service.on_my_chat_member(event(new="administrator"))
    assert service.database.upsert_chat.await_args.kwargs["is_enabled"] is True
    service.bot.leave_chat.assert_not_awaited()


async def test_private_and_removal_events_do_not_validate_inviter():
    service = _service()
    await service.on_my_chat_member(event(chat_type="private"))
    await service.on_my_chat_member(event(old="administrator", new="left"))
    service.bot.get_chat_member.assert_not_awaited()
    service.bot.leave_chat.assert_not_awaited()
