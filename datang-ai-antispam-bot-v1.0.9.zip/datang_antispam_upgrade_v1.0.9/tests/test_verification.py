# ruff: noqa: F811
import asyncio
from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import ChatPermissions, Message
from test_bot_rules import message, service  # noqa: F401

from antispam_bot.config import Settings

CHAT = -1001
USER = SimpleNamespace(id=20, is_bot=False)
JOINED = datetime(2026, 10, 15, tzinfo=UTC)


def member(status="member", **kwargs):
    return SimpleNamespace(status=status, user=USER, is_member=True, until_date=0, **kwargs)


@pytest_asyncio.fixture
async def verifier(service):
    await service.database.upsert_chat(
        CHAT, title="群", username=None, chat_type="supergroup", is_enabled=True
    )
    service.database.is_join_prebanned = AsyncMock(return_value=False)
    service.bot.get_chat_member.return_value = member()
    service.bot.send_message.return_value = SimpleNamespace(message_id=100)

    async def restrict(chat_id, user_id, *, permissions, until_date, **kwargs):
        service.bot.get_chat_member.return_value = SimpleNamespace(
            status="restricted",
            user=USER,
            is_member=True,
            until_date=until_date,
            **permissions.model_dump(),
        )
        return True

    service.bot.restrict_chat_member.side_effect = restrict
    return service


async def start(verifier, joined=JOINED):
    await verifier.start_join_verification(message("").chat, USER, joined)
    return await verifier.rules.get_verification(CHAT, USER.id)


def query(state, *, answer=None, actor=20, chat=CHAT, mid=100, token=None):
    selected = answer if answer is not None else state["a"] + state["b"]
    prompt = Message.model_validate(
        {
            "message_id": mid,
            "date": 1,
            "chat": {"id": chat, "type": "supergroup", "title": "群"},
        }
    )
    return SimpleNamespace(
        message=prompt,
        from_user=SimpleNamespace(id=actor),
        answer=AsyncMock(),
        data=f"jv:{token or state['token']}:{selected}",
    )


async def test_join_mutes_forever_and_sends_four_arithmetic_options(verifier):
    state = await start(verifier)
    call = verifier.bot.restrict_chat_member.await_args.kwargs
    assert call["until_date"] == 0
    assert call["use_independent_chat_permissions"] is True
    assert all(value is False for value in call["permissions"].model_dump().values())
    sent = verifier.bot.send_message.await_args.kwargs
    buttons = sent["reply_markup"].inline_keyboard[0]
    assert len(buttons) == 4
    assert len({b.text for b in buttons}) == 4
    assert str(state["a"] + state["b"]) in [b.text for b in buttons]
    assert f"{state['a']} + {state['b']}" in verifier.bot.send_message.await_args.args[1]
    assert all(len(b.callback_data.encode()) <= 64 for b in buttons)


async def test_wrong_answer_does_not_unmute(verifier):
    state = await start(verifier)
    verifier.bot.restrict_chat_member.reset_mock()
    await verifier.on_verify_answer(query(state, answer=99))
    verifier.bot.restrict_chat_member.assert_not_awaited()
    assert not (await verifier.rules.get_verification(CHAT, 20))["passed"]


@pytest.mark.parametrize(
    "kwargs", [dict(actor=21), dict(chat=-2002), dict(mid=101), dict(token="stale")]
)
async def test_answer_cannot_be_used_by_another_user_group_or_prompt(verifier, kwargs):
    state = await start(verifier)
    verifier.bot.restrict_chat_member.reset_mock()
    await verifier.on_verify_answer(query(state, **kwargs))
    verifier.bot.restrict_chat_member.assert_not_awaited()


async def test_correct_answer_unmutes_once_and_deletes_prompt(verifier):
    state = await start(verifier)
    verifier.bot.restrict_chat_member.reset_mock()
    await asyncio.gather(
        verifier.on_verify_answer(query(state)), verifier.on_verify_answer(query(state))
    )
    verifier.bot.restrict_chat_member.assert_awaited_once()
    permissions = verifier.bot.restrict_chat_member.await_args.kwargs["permissions"]
    assert all(permissions.model_dump().values())
    assert (await verifier.rules.get_verification(CHAT, 20))["passed"]
    verifier.bot.delete_message.assert_awaited_once_with(CHAT, 100)
    assert await verifier.database.get_offender(20) is None


async def test_basic_groups_and_inactive_groups_are_not_falsely_marked_muted(verifier):
    chat = message("").chat
    chat.type = "group"
    await verifier.start_join_verification(chat, USER, JOINED)
    chat.type = "supergroup"
    await verifier.database.upsert_chat(
        CHAT, title="群", username=None, chat_type="supergroup", is_enabled=False
    )
    await verifier.start_join_verification(chat, USER, JOINED)
    verifier.bot.restrict_chat_member.assert_not_awaited()


async def test_external_unlock_is_not_replaced_by_resending_a_question(verifier):
    await start(verifier)
    verifier.bot.get_chat_member.return_value = member()
    verifier.bot.restrict_chat_member.reset_mock()
    await verifier.on_verify(message("/verify 20"))
    verifier.bot.restrict_chat_member.assert_not_awaited()


async def test_only_group_manager_can_resend(verifier):
    await start(verifier)
    verifier.can_manage = AsyncMock(return_value=False)
    verifier.bot.send_message.reset_mock()
    await verifier.on_verify(message("/verify 20", actor=30))
    verifier.bot.send_message.assert_not_awaited()


async def test_unanswered_state_and_buttons_survive_database_reopen(verifier):
    state = await start(verifier)
    await verifier.rules.close()
    await verifier.rules.initialize()
    assert await verifier.rules.get_verification(CHAT, 20) == state
    await verifier.on_verify_answer(query(state))
    assert (await verifier.rules.get_verification(CHAT, 20))["passed"]


async def test_duplicate_join_events_do_not_remute_but_rejoin_does(verifier):
    state = await start(verifier)
    await start(verifier)
    verifier.bot.restrict_chat_member.assert_awaited_once()
    await verifier.on_verify_answer(query(state))
    verifier.bot.get_chat_member.return_value = member()
    later = await start(verifier, JOINED + timedelta(seconds=60))
    assert not later["passed"] and later["token"] != state["token"]


@pytest.mark.parametrize("status", ["creator", "administrator", "left", "kicked"])
async def test_no_challenge_for_admins_or_absent_users(verifier, status):
    verifier.bot.get_chat_member.return_value = member(status)
    assert await start(verifier) is None
    verifier.bot.restrict_chat_member.assert_not_awaited()


async def test_owner_and_bot_exempt(verifier):
    verifier.settings = Settings(owner_ids=frozenset({20}))
    assert await start(verifier) is None
    await verifier.start_join_verification(
        message("").chat, SimpleNamespace(id=30, is_bot=True), JOINED
    )
    verifier.bot.restrict_chat_member.assert_not_awaited()


async def test_mute_failure_is_reported_and_no_fake_question_is_sent(verifier):
    verifier.bot.restrict_chat_member.side_effect = TelegramBadRequest(
        method=None, message="rights"
    )
    state = await start(verifier)
    assert state["message_id"] == 0
    verifier.send_notice.assert_not_awaited()


async def test_failed_unlock_keeps_pending_for_retry(verifier):
    state = await start(verifier)
    verifier.bot.restrict_chat_member.side_effect = TelegramBadRequest(
        method=None, message="rights"
    )
    await verifier.on_verify_answer(query(state))
    assert not (await verifier.rules.get_verification(CHAT, 20))["passed"]


async def test_ad_preban_cannot_be_bypassed_by_correct_answer(verifier):
    state = await start(verifier)
    verifier.database.is_join_prebanned.return_value = True
    verifier.bot.restrict_chat_member.reset_mock()
    await verifier.on_verify_answer(query(state))
    verifier.bot.restrict_chat_member.assert_not_awaited()


async def test_original_restrictions_are_restored_not_lifted(verifier):
    permissions = dict.fromkeys(ChatPermissions.model_fields, False)
    permissions["can_invite_users"] = True
    verifier.bot.get_chat_member.return_value = member("restricted", **permissions)
    state = await start(verifier)
    await verifier.on_verify_answer(query(state))
    assert (
        verifier.bot.restrict_chat_member.await_args.kwargs["permissions"].model_dump()
        == permissions
    )


async def test_later_timed_punishment_is_not_unmuted(verifier):
    state = await start(verifier)
    verifier.bot.get_chat_member.return_value.until_date = datetime.now(UTC) + timedelta(hours=1)
    verifier.bot.restrict_chat_member.reset_mock()
    await verifier.on_verify_answer(query(state))
    verifier.bot.restrict_chat_member.assert_not_awaited()


async def test_external_admin_permission_change_invalidates_old_buttons(verifier):
    state = await start(verifier)
    await verifier.on_chat_member(
        SimpleNamespace(
            chat=message("").chat,
            from_user=SimpleNamespace(id=10),
            old_chat_member=member("restricted"),
            new_chat_member=member("restricted"),
        )
    )
    assert await verifier.rules.get_verification(CHAT, 20) is None
    verifier.bot.restrict_chat_member.reset_mock()
    await verifier.on_verify_answer(query(state))
    verifier.bot.restrict_chat_member.assert_not_awaited()


async def test_recovery_retries_missing_prompt_after_restart(verifier):
    verifier.bot.send_message.side_effect = TelegramBadRequest(method=None, message="network")
    state = await start(verifier)
    assert state["message_id"] == 0
    verifier.bot.send_message.side_effect = None
    await verifier.recover_join_verifications()
    assert (await verifier.rules.get_verification(CHAT, 20))["message_id"] == 100


async def test_admin_can_resend_pending_prompt_without_accepting_old_button(verifier):
    state = await start(verifier)
    command = message("/verify 20")
    await verifier.on_verify(command)
    refreshed = await verifier.rules.get_verification(CHAT, 20)
    assert refreshed["token"] != state["token"]
    verifier.bot.restrict_chat_member.reset_mock()
    await verifier.on_verify_answer(query(state))
    verifier.bot.restrict_chat_member.assert_not_awaited()
