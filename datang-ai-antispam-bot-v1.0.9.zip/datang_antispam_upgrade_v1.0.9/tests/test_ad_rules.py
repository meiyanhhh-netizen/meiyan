from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace

import pytest
import pytest_asyncio

from antispam_bot.ad_rules import AdRuleStore, canonical_sample, matching_categories, media_key

SAMPLE = "本店专业批发各种家居用品，现货供应欢迎全国客户前来洽谈联系 @seller88 https://example.com"


@pytest_asyncio.fixture
async def store(tmp_path: Path):
    rules = AdRuleStore(tmp_path / "rules.db")
    await rules.initialize()
    try:
        yield rules
    finally:
        await rules.close()


@pytest.mark.parametrize(
    ("content", "kind"),
    [
        ("百家乐开户联系 @seller88", "gambling"),
        ("酒店偷拍资源，点我搜索 https://example.com", "adult"),
        ("兼职招募，加我领取返利 @seller88", "job_scam"),
        ("本店批发优惠，欢迎联系 @seller88", "marketing"),
        ("百\u200b家\u200b乐开户联系 https://example.com", "gambling"),
    ],
)
def test_categories_require_complete_solicitation(content: str, kind: str) -> None:
    assert kind in matching_categories(content)


@pytest.mark.parametrize(
    "content",
    [
        "Python 文档 https://docs.python.org",
        "新闻报道：博彩危害 https://example.com",
        "警方提醒不要点击酒店偷拍资源链接 https://example.com",
        "怎么找到兼职工作？",
        "本群禁止推广，联系管理员 @admin88 举报",
        "银行开户教程 https://example.com",
        "我们聊聊营销推广和客服工具",
    ],
)
def test_ordinary_discussion_and_warnings_do_not_match_type(content: str) -> None:
    assert matching_categories(content) == ()


async def test_categories_are_group_scoped_idempotent_and_persistent(
    store: AdRuleStore,
) -> None:
    rule_id, created = await store.add_rule(-1001, 10, kind="gambling")
    assert created
    assert await store.add_rule(-1001, 11, kind="gambling") == (rule_id, False)
    content = "百家乐开户联系 @seller88"
    assert (await store.match(-1001, content)).id == rule_id
    assert await store.match(-1002, content) is None
    await store.close()
    await store.initialize()
    assert (await store.match(-1001, content)).id == rule_id
    assert await store.remove_rule(-1002, rule_id) is False
    assert await store.remove_rule(-1001, rule_id) is True
    assert await store.match(-1001, content) is None
    await store.close()
    await store.initialize()
    assert await store.list_rules(-1001) == ()


async def test_sample_generalizes_changed_handle_domain_numbers_and_spacing(
    store: AdRuleStore,
) -> None:
    await store.add_rule(-1, 10, kind="sample", content=SAMPLE)
    updated = SAMPLE.replace("@seller88", "@newaccount").replace("example.com", "offer.cc")
    updated = updated.replace("家居用品", "家居用品 1234").replace("专业", "专\u200b业")
    assert await store.match(-1, updated) is not None
    assert await store.match(-1, "我今天去买家居用品，大家有推荐吗？") is None
    assert await store.match(-1, "举报：" + updated) is None
    assert await store.match(-2, updated) is None


async def test_similar_long_copy_with_small_edits_matches(store: AdRuleStore) -> None:
    original = (
        "欢迎各位朋友来到我们的精品家居展示中心，长期面向全国客户供应优质家居用品，欢迎来店参观洽谈"
    )
    await store.add_rule(-1, 10, kind="sample", content=original)
    assert await store.match(-1, original.replace("各位朋友", "新老朋友")) is not None
    assert await store.match(-1, "欢迎朋友们参观我们的学校，了解课程设置和校园生活") is None


@pytest.mark.parametrize(
    "content", ["https://example.com", "联系 @seller88", "哈哈哈哈哈哈哈哈哈哈哈哈哈"]
)
async def test_uninformative_samples_rejected(store: AdRuleStore, content: str) -> None:
    with pytest.raises(ValueError, match="样本文字"):
        await store.add_rule(-1, 10, kind="sample", content=content)
    assert await store.list_rules(-1) == ()


async def test_exact_media_can_be_learned_without_caption(store: AdRuleStore) -> None:
    await store.add_rule(-1, 10, kind="sample", media="photo:stable-id")
    assert await store.match(-1, "", "photo:stable-id") is not None
    assert await store.match(-1, "", "photo:another-image") is None
    assert await store.match(-1, "举报这张图", "photo:stable-id") is None
    assert await store.match(-2, "", "photo:stable-id") is None


async def test_concurrent_teaching_deduplicates_rules(store: AdRuleStore) -> None:
    results = await asyncio.gather(
        *(store.add_rule(-1, actor, kind="adult") for actor in range(10))
    )
    assert len({rule_id for rule_id, _ in results}) == 1
    assert sum(created for _, created in results) == 1


async def test_limit_does_not_block_duplicate_or_reuse_after_removal(store: AdRuleStore) -> None:
    store.MAX_RULES_PER_CHAT = 1
    rule_id, _ = await store.add_rule(-1, 10, kind="adult")
    assert await store.add_rule(-1, 10, kind="adult") == (rule_id, False)
    with pytest.raises(ValueError, match="达到"):
        await store.add_rule(-1, 10, kind="gambling")
    await store.remove_rule(-1, rule_id)
    await store.add_rule(-1, 10, kind="gambling")
    assert (await store.list_rules(-1))[0].kind == "gambling"


def test_exact_media_identity_and_url_normalization() -> None:
    image = SimpleNamespace(
        photo=[SimpleNamespace(file_unique_id="small"), SimpleNamespace(file_unique_id="large")]
    )
    assert media_key(image) == "photo:large"
    assert media_key(SimpleNamespace()) == ""
    assert "seller" not in canonical_sample(SAMPLE)
    assert "example" not in canonical_sample(SAMPLE)


async def test_learned_link_is_exact_and_never_expands_to_domain(store: AdRuleStore) -> None:
    rule_id, _ = await store.add_rule(-1, 10, kind="link", content="https://EXAMPLE.com/offer?q=1")
    assert (await store.match(-1, "点击 http://example.com/offer?q=1")).id == rule_id
    assert await store.match(-1, "https://example.com/docs") is None
    assert await store.match(-1, "https://example.com/offer?q=2") is None
    assert await store.match(-1, "举报 https://example.com/offer?q=1") is None
    assert await store.match(-2, "https://example.com/offer?q=1") is None
    await store.remove_rule(-1, rule_id)
    assert await store.match(-1, "https://example.com/offer?q=1") is None


async def test_username_setting_defaults_on_is_isolated_and_persists(store: AdRuleStore) -> None:
    old_rule, _ = await store.add_rule(-1, 10, kind="gambling")
    assert await store.username_blocked(-1)
    await store.set_username_blocked(-1, 10, False)
    assert not await store.username_blocked(-1)
    assert await store.username_blocked(-2)
    await store.close()
    await store.initialize()
    assert not await store.username_blocked(-1)
    assert (await store.list_rules(-1))[0].id == old_rule
    await store.set_username_blocked(-1, 10, True)
    assert await store.username_blocked(-1)


async def test_legacy_mixed_case_telegram_link_rule_still_matches(store: AdRuleStore) -> None:
    rule_id, _ = await store.add_rule(-1, 10, kind="link", content="https://t.me/QQHB93")
    # Simulate the exact case-preserving format written by releases <= 1.0.4.
    await store._conn().execute(
        "UPDATE group_ad_rules SET pattern=? WHERE id=?", ("t.me/QQHB93", rule_id)
    )
    await store._conn().commit()
    assert (await store.match(-1, "https://t.me/qqhb93")).id == rule_id
