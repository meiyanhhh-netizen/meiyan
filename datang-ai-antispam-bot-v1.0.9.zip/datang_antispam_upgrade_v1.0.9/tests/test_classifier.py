from __future__ import annotations

import asyncio

import pytest

from antispam_bot.classifier import HybridAdClassifier, _AIResult
from antispam_bot.config import ClassifierConfig
from antispam_bot.models import ClassificationVerdict, VerdictLabel


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("text", "reason"),
    [
        ("可玩可代 百家樂 AG BG PG电子 开户 联系 @seller88", "gambling_ad_with_destination"),
        ("百家乐开户，点击 https://example.com", "gambling_ad_with_destination"),
        ("赌场开户联系我，example.cc", "gambling_ad_with_destination"),
        ("百\u200d家\ufeff乐，开户联系 @seller88", "gambling_ad_with_destination"),
        ("福利姬直播，限时免费，点我搜索 https://example.com", "adult_ad_with_destination"),
        ("酒店偷拍资源，点击搜索 https://example.com", "adult_ad_with_destination"),
    ],
)
async def test_targeted_link_advertisements_work_without_ai(text: str, reason: str) -> None:
    verdict = await HybridAdClassifier().classify(text)

    assert verdict.is_ad
    assert verdict.confidence >= 0.94
    assert verdict.strong_content_evidence
    assert reason in verdict.reasons
    assert verdict.source == "heuristic"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "text",
    [
        "Python 文档 docs.python.org/3/",
        "本地文件 README.txt 和 main.py，版本 v1.0.2",
        "银行开户流程 https://example.com",
        "新闻报道：警惕百家乐开户骗局 https://example.com",
        "警方提醒不要点击酒店偷拍资源链接 https://example.com",
        "博彩是什么？今天学习概率论。",
        "我们要防范偷拍，保护隐私。",
        "AG BG PG 只是程序变量名，见 https://example.com",
        "百家乐交流群",
    ],
)
async def test_targeted_rules_do_not_punish_discussions_or_ordinary_links(text: str) -> None:
    verdict = await HybridAdClassifier().classify(text)

    assert not verdict.is_ad
    assert "gambling_ad_with_destination" not in verdict.reasons
    assert "adult_ad_with_destination" not in verdict.reasons


@pytest.mark.asyncio
@pytest.mark.parametrize("bot_sender", [False, True])
async def test_received_non_admin_bot_or_user_ad_can_be_classified(bot_sender: bool) -> None:
    verdict = await HybridAdClassifier().classify(
        "PG电子，开户联系 @seller88", sender_is_bot=bot_sender
    )
    assert verdict.is_ad


@pytest.mark.asyncio
async def test_targeted_ad_is_still_exempt_for_an_administrator() -> None:
    verdict = await HybridAdClassifier().classify(
        "百家乐开户，点击 https://example.com", sender_is_admin=True
    )
    assert not verdict.is_ad
    assert verdict.source == "exemption"


@pytest.mark.asyncio
async def test_risk_keywords_in_nickname_do_not_trigger_targeted_rule() -> None:
    verdict = await HybridAdClassifier().classify(
        "官网文档 https://example.com", nickname="百家乐开户代理"
    )
    assert not verdict.is_ad
    assert "gambling_ad_with_destination" not in verdict.reasons


@pytest.mark.asyncio
async def test_remote_ai_cannot_downgrade_targeted_link_ad(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    classifier = HybridAdClassifier(ClassifierConfig(ai_endpoint="http://127.0.0.1/v1"))

    async def remote_clean(*_: object) -> _AIResult:
        return _AIResult(probability=0.0, reasons=("ai:clean",))

    monkeypatch.setattr(classifier, "_classify_with_ai", remote_clean)
    verdict = await classifier.classify("百家乐开户，点击 https://example.com")
    assert verdict.is_ad
    assert verdict.heuristic_confidence >= 0.94


@pytest.mark.asyncio
async def test_heuristic_classifier_flags_explicit_advertising() -> None:
    classifier = HybridAdClassifier()

    verdict = await classifier.classify(
        "限时优惠！USDT代充只要99元，立即下单联系 @cheap_service，加入 https://t.me/+abcdef"
    )

    assert verdict.label is VerdictLabel.ADVERTISEMENT
    assert verdict.is_ad is True
    assert verdict.confidence >= classifier.config.ad_threshold
    assert verdict.strong_content_evidence is True
    assert "promotion_language" in verdict.reasons
    assert "contact_handle" in verdict.reasons
    assert "telegram_invite" in verdict.reasons


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "text",
    [
        "今晚八点一起开会吗？我把昨天的资料整理好了。",
        "这是 Python 官方文档：https://docs.python.org/3/",
        "宝宝今天已经吃过奶了，晚点再看看情况。",
    ],
)
async def test_heuristic_classifier_keeps_legitimate_chat_clean(text: str) -> None:
    verdict = await HybridAdClassifier().classify(text)

    assert verdict.label is VerdictLabel.CLEAN
    assert verdict.is_ad is False
    assert verdict.strong_content_evidence is False


@pytest.mark.asyncio
async def test_sales_like_nickname_alone_cannot_trigger_ad_or_preban() -> None:
    classifier = HybridAdClassifier()

    verdict = await classifier.classify(
        "大家早上好",
        nickname="低价代充客服",
        username="service_agent",
    )

    assert verdict.label is VerdictLabel.CLEAN
    assert "sales_like_sender_name" in verdict.reasons
    assert verdict.strong_content_evidence is False
    assert verdict.qualifies_for_global_preban(classifier.config.global_preban_threshold) is False


@pytest.mark.asyncio
async def test_configured_threshold_changes_borderline_label() -> None:
    text = "低价出售，联系我"
    ad_classifier = HybridAdClassifier(
        ClassifierConfig(
            suspicious_threshold=0.30,
            ad_threshold=0.40,
            global_preban_threshold=0.90,
        )
    )
    suspicious_classifier = HybridAdClassifier(
        ClassifierConfig(
            suspicious_threshold=0.30,
            ad_threshold=0.41,
            global_preban_threshold=0.90,
        )
    )

    ad_verdict = await ad_classifier.classify(text)
    suspicious_verdict = await suspicious_classifier.classify(text)

    assert ad_verdict.confidence == pytest.approx(0.40)
    assert suspicious_verdict.confidence == pytest.approx(0.40)
    assert ad_verdict.label is VerdictLabel.ADVERTISEMENT
    assert suspicious_verdict.label is VerdictLabel.SUSPICIOUS


def test_global_preban_threshold_is_inclusive_and_requires_content_evidence() -> None:
    strong_verdict = ClassificationVerdict(
        label=VerdictLabel.ADVERTISEMENT,
        confidence=0.92,
        heuristic_confidence=0.92,
        strong_content_evidence=True,
    )
    weak_verdict = ClassificationVerdict(
        label=VerdictLabel.ADVERTISEMENT,
        confidence=1.0,
        heuristic_confidence=0.16,
        strong_content_evidence=False,
    )

    assert strong_verdict.qualifies_for_global_preban(0.92) is True
    assert strong_verdict.qualifies_for_global_preban(0.921) is False
    assert weak_verdict.qualifies_for_global_preban(0.92) is False


@pytest.mark.parametrize(
    "config_kwargs",
    [
        {"suspicious_threshold": 0.80, "ad_threshold": 0.70},
        {"ad_threshold": 0.95, "global_preban_threshold": 0.90},
        {"suspicious_threshold": -0.01},
        {"global_preban_threshold": 1.01},
        {"ai_queue_timeout_seconds": 0.0},
    ],
)
def test_classifier_rejects_invalid_thresholds(
    config_kwargs: dict[str, float],
) -> None:
    with pytest.raises(ValueError):
        ClassifierConfig(**config_kwargs)


def test_public_openai_endpoint_requires_an_api_key() -> None:
    without_key = ClassifierConfig(
        ai_endpoint="https://api.openai.com/v1",
        ai_api_key=None,
    )
    with_key = ClassifierConfig(
        ai_endpoint="https://api.openai.com/v1",
        ai_api_key="test-key",
    )

    assert without_key.ai_enabled is False
    assert with_key.ai_enabled is True


@pytest.mark.parametrize(
    "endpoint",
    [
        "http://127.0.0.1:11434/v1",
        "https://llm.internal.example/v1",
    ],
)
def test_custom_ai_endpoint_can_be_keyless(endpoint: str) -> None:
    config = ClassifierConfig(ai_endpoint=endpoint, ai_api_key=None)

    assert config.ai_enabled is True


@pytest.mark.asyncio
async def test_remote_ai_is_skipped_for_implausible_messages(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    classifier = HybridAdClassifier(ClassifierConfig(ai_endpoint="http://127.0.0.1:11434/v1"))

    async def unexpected_call(*_: object) -> _AIResult:
        raise AssertionError("remote AI should not be called")

    monkeypatch.setattr(classifier, "_classify_with_ai", unexpected_call)
    verdict = await classifier.classify("今晚八点一起开会")

    assert verdict.source == "heuristic"
    assert verdict.label is VerdictLabel.CLEAN


@pytest.mark.asyncio
async def test_remote_ai_cannot_downgrade_strong_local_advertisement(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    classifier = HybridAdClassifier(ClassifierConfig(ai_endpoint="http://127.0.0.1:11434/v1"))

    async def remote_clean(*_: object) -> _AIResult:
        return _AIResult(probability=0.01, reasons=("ai:not_ad",))

    monkeypatch.setattr(classifier, "_classify_with_ai", remote_clean)
    verdict = await classifier.classify(
        "限时低价推广，100元立即下单，联系 @seller88，加入 https://t.me/+abcdef"
    )

    assert verdict.label is VerdictLabel.ADVERTISEMENT
    assert verdict.confidence == verdict.heuristic_confidence
    assert verdict.ai_confidence == pytest.approx(0.01)


@pytest.mark.asyncio
async def test_remote_ai_concurrency_is_bounded(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    classifier = HybridAdClassifier(
        ClassifierConfig(
            ai_endpoint="http://127.0.0.1:11434/v1",
            ai_max_concurrency=2,
        )
    )
    active = 0
    maximum_active = 0

    async def delayed_remote(*_: object) -> _AIResult:
        nonlocal active, maximum_active
        active += 1
        maximum_active = max(maximum_active, active)
        await asyncio.sleep(0.01)
        active -= 1
        return _AIResult(probability=0.2, reasons=())

    monkeypatch.setattr(classifier, "_classify_with_ai", delayed_remote)
    await asyncio.gather(
        *(classifier.classify(f"请查看 https://example.com/{index}") for index in range(8))
    )

    assert maximum_active == 2


@pytest.mark.asyncio
async def test_remote_ai_queue_timeout_falls_back_without_backlog(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    classifier = HybridAdClassifier(
        ClassifierConfig(
            ai_endpoint="http://127.0.0.1:11434/v1",
            ai_max_concurrency=1,
            ai_queue_timeout_seconds=0.01,
        )
    )
    entered = asyncio.Event()
    release = asyncio.Event()

    async def blocked_remote(*_: object) -> _AIResult:
        entered.set()
        await release.wait()
        return _AIResult(probability=0.8, reasons=("ai:promotion",))

    monkeypatch.setattr(classifier, "_classify_with_ai", blocked_remote)
    first = asyncio.create_task(
        classifier.classify("低价推广，联系 @seller88，https://example.com/one")
    )
    await entered.wait()
    second = await classifier.classify("请查看 https://example.com/two")
    release.set()
    await first

    assert second.source == "heuristic"
    assert second.ai_confidence is None
