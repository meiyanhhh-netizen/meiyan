from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pytest

from antispam_bot.db import Database
from antispam_bot.models import ClassificationVerdict, VerdictLabel


def _ad_verdict(
    confidence: float = 0.96,
    *,
    strong_content_evidence: bool = True,
) -> ClassificationVerdict:
    return ClassificationVerdict(
        label=VerdictLabel.ADVERTISEMENT,
        confidence=confidence,
        reasons=("promotion_language", "contact_handle"),
        source="heuristic",
        heuristic_confidence=confidence,
        strong_content_evidence=strong_content_evidence,
    )


@pytest.mark.asyncio
async def test_chat_and_explicit_audit_event_persist_after_reopen(
    tmp_path: Path,
) -> None:
    database_path = tmp_path / "antispam.sqlite3"
    database = Database(database_path)
    await database.initialize()
    await database.upsert_chat(
        -1001234567890,
        title="大唐交流群",
        username="datang_group",
        chat_type="supergroup",
    )
    audit_id = await database.log_audit(
        "bot_added_to_chat",
        actor_user_id=1001,
        chat_id=-1001234567890,
        details={"source": "my_chat_member", "enabled": True},
    )
    await database.close()

    reopened = Database(database_path)
    await reopened.initialize()
    chat = await reopened.get_chat(-1001234567890)
    await reopened.close()

    assert chat is not None
    assert chat.title == "大唐交流群"
    assert chat.username == "datang_group"
    assert chat.chat_type == "supergroup"
    assert chat.is_enabled is True

    with sqlite3.connect(database_path) as connection:
        row = connection.execute(
            "SELECT event_type, actor_user_id, chat_id, details_json FROM audit WHERE id = ?",
            (audit_id,),
        ).fetchone()

    assert row is not None
    assert row[:3] == ("bot_added_to_chat", 1001, -1001234567890)
    assert json.loads(row[3]) == {
        "source": "my_chat_member",
        "enabled": True,
    }


@pytest.mark.asyncio
async def test_infraction_is_idempotent_and_offender_counts_persist(
    tmp_path: Path,
) -> None:
    database_path = tmp_path / "antispam.sqlite3"
    database = Database(database_path)
    await database.initialize()
    verdict = _ad_verdict(0.84)

    first = await database.record_infraction(
        user_id=2002,
        chat_id=-10011,
        message_id=77,
        verdict=verdict,
        username="repeat_sender",
        display_name="重复消息测试",
        content="优惠推广，联系 @repeat_sender",
        action="delete_and_warn",
        global_preban_threshold=0.92,
    )
    duplicate = await database.record_infraction(
        user_id=2002,
        chat_id=-10011,
        message_id=77,
        verdict=verdict,
        username="repeat_sender",
        display_name="重复消息测试",
        content="优惠推广，联系 @repeat_sender",
        action="delete_and_warn",
        global_preban_threshold=0.92,
    )
    await database.close()

    reopened = Database(database_path)
    await reopened.initialize()
    offender = await reopened.get_offender(2002)
    await reopened.close()

    assert first.inserted is True
    assert first.infraction_id is not None
    assert first.chat_infraction_count == 1
    assert first.global_infraction_count == 1
    assert duplicate.inserted is False
    assert duplicate.infraction_id is None
    assert duplicate.chat_infraction_count == 1
    assert duplicate.global_infraction_count == 1
    assert offender is not None
    assert offender.total_infractions == 1
    assert offender.confirmed_ads == 1
    assert offender.max_confidence == pytest.approx(0.84)
    assert offender.global_blocked is False

    with sqlite3.connect(database_path) as connection:
        infraction_count = connection.execute(
            "SELECT COUNT(*) FROM infractions WHERE user_id = ?", (2002,)
        ).fetchone()[0]
        audit_count = connection.execute(
            "SELECT COUNT(*) FROM audit "
            "WHERE event_type = 'infraction_recorded' AND target_user_id = ?",
            (2002,),
        ).fetchone()[0]

    assert infraction_count == 1
    assert audit_count == 1


@pytest.mark.asyncio
async def test_high_confidence_ad_is_audited_without_automatic_global_block(
    tmp_path: Path,
) -> None:
    database_path = tmp_path / "antispam.sqlite3"
    database = Database(database_path)
    await database.initialize()

    outcome = await database.record_infraction(
        user_id=3003,
        chat_id=-10021,
        message_id=88,
        verdict=_ad_verdict(0.96),
        username="global_spammer",
        content="限时推广，立即联系 @global_spammer 加入 https://t.me/+spam",
        action="delete_and_ban",
        global_preban_threshold=0.92,
    )

    assert outcome.global_blocked is False
    assert outcome.newly_global_blocked is False
    assert await database.is_globally_blocked(3003) is False
    listed = await database.list_global_offenders()
    assert listed == []
    await database.close()

    reopened = Database(database_path)
    await reopened.initialize()
    offender = await reopened.get_offender(3003)
    assert await reopened.is_globally_blocked(3003) is False
    await reopened.close()

    assert offender is not None
    assert offender.global_blocked is False
    assert offender.global_block_reason is None
    assert offender.global_blocked_at is None

    with sqlite3.connect(database_path) as connection:
        candidate = connection.execute(
            "SELECT details_json FROM audit "
            "WHERE event_type = 'high_confidence_candidate' "
            "AND target_user_id = ?",
            (3003,),
        ).fetchone()

    assert candidate is not None
    assert json.loads(candidate[0])["confidence"] == pytest.approx(0.96)


@pytest.mark.asyncio
async def test_weak_evidence_cannot_create_global_preban_even_at_full_confidence(
    tmp_path: Path,
) -> None:
    database = Database(tmp_path / "antispam.sqlite3")
    await database.initialize()

    outcome = await database.record_infraction(
        user_id=4004,
        chat_id=-10031,
        message_id=99,
        verdict=_ad_verdict(1.0, strong_content_evidence=False),
        display_name="客服",
        content="大家好",
        global_preban_threshold=0.92,
    )
    blocked = await database.is_globally_blocked(4004)
    await database.close()

    assert outcome.inserted is True
    assert outcome.global_blocked is False
    assert outcome.newly_global_blocked is False
    assert blocked is False


@pytest.mark.asyncio
async def test_confirmed_ad_prebans_future_joins_without_global_block(
    tmp_path: Path,
) -> None:
    database = Database(tmp_path / "antispam.sqlite3")
    await database.initialize()

    assert await database.is_join_prebanned(4104) is False
    await database.record_infraction(
        user_id=4104,
        chat_id=-10032,
        message_id=100,
        verdict=_ad_verdict(0.84),
        content="优惠推广，联系 @sender",
    )

    assert await database.is_join_prebanned(4104) is True
    assert await database.is_globally_blocked(4104) is False
    await database.close()


@pytest.mark.asyncio
async def test_manual_global_block_is_also_a_join_preban(tmp_path: Path) -> None:
    database = Database(tmp_path / "antispam.sqlite3")
    await database.initialize()
    await database.set_global_block(4204, reason="manual_review")

    assert await database.is_join_prebanned(4204) is True
    await database.clear_global_block(4204, reset_strikes=True)
    assert await database.is_join_prebanned(4204) is False
    await database.close()


@pytest.mark.asyncio
async def test_manual_global_block_and_clear_are_persisted_and_audited(
    tmp_path: Path,
) -> None:
    database_path = tmp_path / "antispam.sqlite3"
    database = Database(database_path)
    await database.initialize()
    await database.set_global_block(
        5005,
        reason="confirmed_in_other_group",
        actor_user_id=9009,
    )
    assert await database.is_globally_blocked(5005) is True
    await database.close()

    reopened = Database(database_path)
    await reopened.initialize()
    assert await reopened.is_globally_blocked(5005) is True
    changed = await reopened.clear_global_block(
        5005,
        reason="owner_reviewed",
        actor_user_id=9009,
    )
    unchanged = await reopened.clear_global_block(5005)
    await reopened.close()

    assert changed is True
    assert unchanged is False

    with sqlite3.connect(database_path) as connection:
        events = connection.execute(
            "SELECT event_type, actor_user_id, target_user_id, details_json "
            "FROM audit WHERE target_user_id = ? ORDER BY id",
            (5005,),
        ).fetchall()
        blocked = connection.execute(
            "SELECT global_blocked FROM offenders WHERE user_id = ?", (5005,)
        ).fetchone()[0]

    assert blocked == 0
    assert [event[0] for event in events] == [
        "global_block_set",
        "global_block_cleared",
    ]
    assert all(event[1:3] == (9009, 5005) for event in events)
    assert json.loads(events[0][3])["reason"] == "confirmed_in_other_group"
    assert json.loads(events[1][3])["reason"] == "owner_reviewed"


@pytest.mark.asyncio
async def test_bot_owned_bans_are_tracked_per_chat_and_safely_cleared(
    tmp_path: Path,
) -> None:
    database = Database(tmp_path / "antispam.sqlite3")
    await database.initialize()

    await database.record_bot_ban(-10020, 6006, "global_sync")
    await database.record_bot_ban(-10010, 6006, "member_join")
    await database.record_bot_ban(-10010, 6006, "updated_reason")
    await database.record_bot_ban(-10030, 7007, "unrelated_user")

    assert await database.list_bot_ban_chats(6006) == [-10020, -10010]
    assert await database.clear_bot_ban(-10020, 6006) is True
    assert await database.clear_bot_ban(-10020, 6006) is False
    assert await database.list_bot_ban_chats(6006) == [-10010]
    assert await database.list_bot_ban_chats(7007) == [-10030]
    await database.close()


@pytest.mark.asyncio
async def test_clear_global_block_can_reset_strikes_without_deleting_evidence(
    tmp_path: Path,
) -> None:
    database_path = tmp_path / "antispam.sqlite3"
    database = Database(database_path)
    await database.initialize()
    for message_id in (1, 2):
        await database.record_infraction(
            user_id=8008,
            chat_id=-10040,
            message_id=message_id,
            verdict=_ad_verdict(0.84),
            content="推广联系 @sender",
        )
    await database.set_global_block(8008, reason="strike_threshold")

    changed = await database.clear_global_block(
        8008,
        reason="appeal_accepted",
        actor_user_id=9009,
        reset_strikes=True,
    )
    offender = await database.get_offender(8008)
    await database.close()

    assert changed is True
    assert offender is not None
    assert offender.global_blocked is False
    assert offender.total_infractions == 0
    assert offender.confirmed_ads == 0
    assert offender.max_confidence == 0.0
    assert offender.risk_score == 0.0

    with sqlite3.connect(database_path) as connection:
        evidence_count = connection.execute(
            "SELECT COUNT(*) FROM infractions WHERE user_id = ?", (8008,)
        ).fetchone()[0]
        clear_details = connection.execute(
            "SELECT details_json FROM audit "
            "WHERE event_type = 'global_block_cleared' AND target_user_id = ?",
            (8008,),
        ).fetchone()[0]

    assert evidence_count == 2
    assert json.loads(clear_details)["reset_strikes"] is True
