from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, call

import pytest
from aiogram.enums import ChatMemberStatus, ChatType
from aiogram.exceptions import TelegramBadRequest

from antispam_bot.bot import AntiSpamBot, configure_bot_commands
from antispam_bot.classifier import HybridAdClassifier
from antispam_bot.config import ClassifierConfig, Settings
from antispam_bot.models import (
    ClassificationVerdict,
    InfractionOutcome,
    VerdictLabel,
)


def _service(*, settings: Settings | None = None) -> AntiSpamBot:
    rules = AsyncMock()
    rules.match.return_value = None
    rules.list_rules.return_value = ()
    rules.username_blocked.return_value = False
    rules.username_required.return_value = False
    rules.category_policies.return_value = {}
    return AntiSpamBot(
        bot=AsyncMock(),
        database=AsyncMock(),
        classifier=AsyncMock(),
        settings=settings or Settings(),
        rules=rules,
    )


def _message(
    *,
    text: str | None = None,
    caption: str | None = None,
    entities: list[object] | None = None,
    caption_entities: list[object] | None = None,
    reply_user_id: int | None = None,
) -> SimpleNamespace:
    reply = None
    if reply_user_id is not None:
        reply = SimpleNamespace(from_user=SimpleNamespace(id=reply_user_id))
    return SimpleNamespace(
        text=text,
        caption=caption,
        entities=entities,
        caption_entities=caption_entities,
        reply_to_message=reply,
    )


def _text_link(url: str) -> SimpleNamespace:
    return SimpleNamespace(type="text_link", url=url)


def _moderation_message() -> SimpleNamespace:
    return SimpleNamespace(
        chat=SimpleNamespace(
            id=-100123,
            type=ChatType.SUPERGROUP,
            title="测试群",
            username="test_group",
        ),
        from_user=SimpleNamespace(
            id=12345,
            full_name="测试用户",
            username="test_sender",
            is_bot=False,
        ),
        message_id=77,
        text="限时推广，立即联系 @test_sender",
        caption=None,
        entities=[],
        caption_entities=[],
    )


def test_router_registers_every_required_telegram_update_type() -> None:
    service = _service()

    assert set(service.router.resolve_used_update_types()) == {
        "message",
        "edited_message",
        "my_chat_member",
        "chat_member",
        "chat_join_request",
        "callback_query",
    }
    assert service.router.message.handlers[-1].callback == service.on_message
    assert service.router.edited_message.handlers[0].callback == service.on_message
    assert service.router.my_chat_member.handlers[0].callback == service.on_my_chat_member
    assert service.router.chat_member.handlers[0].callback == service.on_chat_member
    assert service.router.chat_join_request.handlers[0].callback == service.on_join_request


def test_message_content_includes_hidden_text_links() -> None:
    message = _message(
        text="点这里查看详情",
        entities=[
            _text_link("https://t.me/+hidden_invite"),
            SimpleNamespace(type="bold", url=None),
        ],
    )

    assert AntiSpamBot.message_content(message) == ("点这里查看详情\nhttps://t.me/+hidden_invite")


def test_message_content_uses_caption_entities_for_media() -> None:
    message = _message(
        caption="图片说明",
        caption_entities=[_text_link("https://example.com/hidden-offer")],
    )

    assert AntiSpamBot.message_content(message) == ("图片说明\nhttps://example.com/hidden-offer")


def test_message_content_reads_url_and_web_app_buttons_but_not_callback_data() -> None:
    message = _message(caption="可玩可代 PG电子")
    message.reply_markup = SimpleNamespace(
        inline_keyboard=[
            [
                SimpleNamespace(text="开户联系", url="https://example.com/open"),
                SimpleNamespace(
                    text="频道", web_app=SimpleNamespace(url="https://example.com/app")
                ),
                SimpleNamespace(text="下一页", callback_data="https://malicious.example/hidden"),
            ]
        ]
    )
    content = AntiSpamBot.message_content(message)
    assert "开户联系" in content
    assert "https://example.com/open" in content
    assert "https://example.com/app" in content
    assert "https://malicious.example/hidden" not in content


def test_message_content_keeps_hidden_url_after_maximum_length_body() -> None:
    message = _message(text="字" * 4000, entities=[_text_link("https://example.com")])
    content = AntiSpamBot.message_content(message)
    assert len(content) <= 4000
    assert "https://example.com" in content


def test_message_content_deduplicates_repeated_hidden_destinations() -> None:
    message = _message(text="点我搜索", entities=[_text_link("https://example.com")] * 8)
    assert AntiSpamBot.message_content(message).count("https://example.com") == 1


@pytest.mark.asyncio
async def test_screenshot_style_caption_and_buttons_are_classified_offline() -> None:
    message = _message(caption="可玩可代 百家乐 AG BG PG电子 开户 联系 @seller88")
    message.reply_markup = SimpleNamespace(
        inline_keyboard=[
            [
                SimpleNamespace(text="开户联系", url="https://t.me/seller88"),
                SimpleNamespace(text="发财频道", url="https://t.me/example_channel"),
            ]
        ]
    )
    verdict = await HybridAdClassifier().classify(AntiSpamBot.message_content(message))
    assert verdict.is_ad
    assert "gambling_ad_with_destination" in verdict.reasons


@pytest.mark.asyncio
async def test_screenshot_style_hidden_ad_links_are_classified_offline() -> None:
    message = _message(
        text=("点我搜索 酒店偷拍，福利姬直播，限时免费搜索\n" * 3),
        entities=[_text_link("https://example.com/search")] * 6,
    )
    verdict = await HybridAdClassifier().classify(AntiSpamBot.message_content(message))
    assert verdict.is_ad
    assert "adult_ad_with_destination" in verdict.reasons


@pytest.mark.asyncio
async def test_button_ad_reaches_delete_and_original_first_strike_policy() -> None:
    service = _service()
    service.classifier = HybridAdClassifier()
    service._bot_id = 99999
    service.ensure_chat_active = AsyncMock(return_value=True)
    service.is_admin = AsyncMock(return_value=False)
    service.database.is_globally_blocked.return_value = False
    service.database.record_infraction.return_value = InfractionOutcome(
        inserted=True,
        infraction_id=1,
        chat_infraction_count=1,
        global_infraction_count=1,
        confirmed_ad_count=1,
        global_blocked=False,
        newly_global_blocked=False,
    )
    service.safe_delete = AsyncMock(return_value=True)
    service.send_notice = AsyncMock()
    service.restrict_user = AsyncMock()
    service.ban_in_chat = AsyncMock()
    message = _moderation_message()
    message.text = None
    message.caption = "可玩可代 百家乐 PG电子 开户 联系 @seller88"
    message.reply_markup = SimpleNamespace(
        inline_keyboard=[
            [
                SimpleNamespace(text="开户联系", url="https://example.com/open"),
            ]
        ]
    )
    assert await service.on_message(message) is True
    service.safe_delete.assert_awaited_once_with(message)
    service.database.record_infraction.assert_awaited_once()
    assert "第 1 次违规" in service.send_notice.await_args.args[1]
    service.restrict_user.assert_not_awaited()
    service.ban_in_chat.assert_not_awaited()


@pytest.mark.asyncio
async def test_admin_commands_deny_a_failed_role_lookup() -> None:
    service = _service()
    message = _moderation_message()
    service.bot.get_chat_member.side_effect = TelegramBadRequest(
        method=MagicMock(), message="lookup failed"
    )
    assert await service.is_admin(message.chat.id, message.from_user.id) is True
    assert await service.can_manage(message) is False


@pytest.mark.asyncio
async def test_adcheck_is_non_destructive_and_never_calls_remote_ai(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    service = _service(
        settings=Settings(classifier=ClassifierConfig(ai_endpoint="http://127.0.0.1:11434/v1"))
    )
    message = _moderation_message()
    message.text = "/adcheck"
    message.reply_to_message = _moderation_message()
    message.reply_to_message.text = "百家乐开户联系 @seller88"
    message.answer = AsyncMock()
    service.on_message = AsyncMock(return_value=False)
    service.can_manage = AsyncMock(return_value=True)
    service.is_admin = AsyncMock(return_value=False)
    service._bot_id = 99999
    service.missing_bot_permissions = AsyncMock(return_value=[])
    service.database.get_chat.return_value = SimpleNamespace(is_enabled=True)
    service.safe_delete = AsyncMock()

    async def forbidden_network(*_: object) -> None:
        raise AssertionError("adcheck must not call AI")

    monkeypatch.setattr(HybridAdClassifier, "_classify_with_ai", forbidden_network)
    await service.on_adcheck(message)
    answer = message.answer.await_args.args[0]
    assert "判定：广告" in answer
    assert "1.0.9" in answer
    service.safe_delete.assert_not_awaited()
    service.database.record_infraction.assert_not_awaited()
    service.database.log_audit.assert_not_awaited()
    service.bot.ban_chat_member.assert_not_awaited()


@pytest.mark.asyncio
async def test_bot_command_setup_has_all_required_aiogram_331_rights() -> None:
    bot = AsyncMock()
    await configure_bot_commands(bot)
    rights = bot.set_my_default_administrator_rights.await_args.kwargs["rights"]
    assert rights.can_send_welcome_messages is False
    assert rights.can_delete_messages is True


@pytest.mark.asyncio
async def test_membership_update_accepts_string_chat_type() -> None:
    service = _service()
    event = SimpleNamespace(
        chat=SimpleNamespace(id=-100123, type="supergroup", title="群", username=None),
        new_chat_member=SimpleNamespace(status=ChatMemberStatus.LEFT),
    )
    await service.on_my_chat_member(event)
    assert service.database.upsert_chat.await_args.kwargs["chat_type"] == "supergroup"


@pytest.mark.parametrize(
    ("text", "reply_user_id", "expected"),
    [
        ("/ban 123456 跨群广告", None, (123456, "跨群广告")),
        ("/check 123456", None, (123456, "")),
        ("/ban", 9988, (9988, "")),
        ("/ban 刷屏", 9988, (9988, "刷屏")),
        ("/ban copied ad", 9988, (9988, "copied ad")),
        ("/ban -123456 跨群广告", None, (None, "跨群广告")),
        ("/ban", None, (None, "")),
        ("/ban not-a-user", None, (None, "")),
    ],
)
def test_command_target_parsing(
    text: str,
    reply_user_id: int | None,
    expected: tuple[int | None, str],
) -> None:
    message = _message(text=text, reply_user_id=reply_user_id)

    assert AntiSpamBot._command_target(message) == expected


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("strike", "mute_minutes", "notice_fragment"),
    [
        (1, None, "第 1 次违规，已警告"),
        (2, 10, "第 2 次违规，禁言 10 分钟"),
        (3, 24 * 60, "第 3 次违规，禁言 1 天"),
    ],
)
async def test_progressive_policy_warns_then_mutes(
    strike: int,
    mute_minutes: int | None,
    notice_fragment: str,
) -> None:
    service = _service()
    message = _moderation_message()
    verdict = ClassificationVerdict(
        label=VerdictLabel.ADVERTISEMENT,
        confidence=0.95,
        reasons=("promotion_language",),
        heuristic_confidence=0.95,
        strong_content_evidence=True,
    )
    outcome = InfractionOutcome(
        inserted=True,
        infraction_id=strike,
        chat_infraction_count=strike,
        global_infraction_count=strike,
        confirmed_ad_count=strike,
        global_blocked=False,
        newly_global_blocked=False,
    )
    service._bot_id = 99999
    service.is_admin = AsyncMock(return_value=False)
    service.database.is_globally_blocked.return_value = False
    service.database.record_infraction.return_value = outcome
    service.classifier.classify_message.return_value = verdict
    service.safe_delete = AsyncMock()
    service.send_notice = AsyncMock()
    service.restrict_user = AsyncMock()
    service.ban_in_chat = AsyncMock(return_value=True)

    await service.on_message(message)

    service.safe_delete.assert_awaited_once_with(message)
    service.database.record_infraction.assert_awaited_once()
    service.ban_in_chat.assert_not_awaited()
    service.database.set_global_block.assert_not_awaited()
    if mute_minutes is None:
        service.restrict_user.assert_not_awaited()
    else:
        service.restrict_user.assert_awaited_once_with(
            message.chat.id,
            message.from_user.id,
            minutes=mute_minutes,
        )
    notice = service.send_notice.await_args.args[1]
    assert notice_fragment in notice


@pytest.mark.asyncio
async def test_fourth_strike_adds_global_preban_and_propagates() -> None:
    service = _service(settings=Settings(global_ban_strikes=4))
    message = _moderation_message()
    verdict = ClassificationVerdict(
        label=VerdictLabel.ADVERTISEMENT,
        confidence=0.95,
        reasons=("promotion_language",),
        heuristic_confidence=0.95,
        strong_content_evidence=True,
    )
    service._bot_id = 99999
    service.is_admin = AsyncMock(return_value=False)
    service.database.is_globally_blocked.return_value = False
    service.database.record_infraction.return_value = InfractionOutcome(
        inserted=True,
        infraction_id=4,
        chat_infraction_count=4,
        global_infraction_count=4,
        confirmed_ad_count=4,
        global_blocked=False,
        newly_global_blocked=False,
    )
    service.classifier.classify_message.return_value = verdict
    service.safe_delete = AsyncMock()
    service.send_notice = AsyncMock()
    service.restrict_user = AsyncMock()
    service.ban_in_chat = AsyncMock(return_value=True)
    service.propagate_ban = MagicMock(return_value=object())
    service.spawn = MagicMock()

    await service.on_message(message)

    service.database.set_global_block.assert_awaited_once_with(
        message.from_user.id,
        reason="累计广告违规 4 次",
    )
    service.ban_in_chat.assert_awaited_once_with(
        message.chat.id,
        message.from_user.id,
        reason="progressive_global_ban",
    )
    service.propagate_ban.assert_called_once_with(
        message.from_user.id,
        "advertising",
    )
    service.spawn.assert_called_once()
    service.restrict_user.assert_not_awaited()
    assert "加入全局预封名单" in service.send_notice.await_args.args[1]


@pytest.mark.asyncio
async def test_existing_global_preban_short_circuits_classification() -> None:
    service = _service()
    message = _moderation_message()
    service._bot_id = 99999
    service.database.is_globally_blocked.return_value = True
    service.safe_delete = AsyncMock()
    service.ban_in_chat = AsyncMock(return_value=True)

    await service.on_message(message)

    service.safe_delete.assert_awaited_once_with(message)
    service.ban_in_chat.assert_awaited_once_with(
        message.chat.id,
        message.from_user.id,
        reason="global_preban_message",
    )
    service.classifier.classify_message.assert_not_awaited()
    service.database.record_infraction.assert_not_awaited()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("handler_name", "command"),
    [
        ("on_start", "/start"),
        ("on_status", "/status"),
        ("on_check", "/check 12345"),
        ("on_manual_ban", "/ban 54321"),
        ("on_manual_unban", "/unban 54321"),
    ],
)
async def test_group_command_handlers_apply_global_preban_guard(
    handler_name: str,
    command: str,
) -> None:
    service = _service()
    message = _moderation_message()
    message.text = command
    message.answer = AsyncMock()
    service._bot_id = 99999
    service.ensure_chat_active = AsyncMock(return_value=True)
    service.is_admin = AsyncMock(return_value=False)
    service.database.is_globally_blocked.return_value = True
    service.safe_delete = AsyncMock(return_value=True)
    service.ban_in_chat = AsyncMock(return_value=True)

    await getattr(service, handler_name)(message)

    service.safe_delete.assert_awaited_once_with(message)
    service.ban_in_chat.assert_awaited_once_with(
        message.chat.id,
        message.from_user.id,
        reason="global_preban_message",
    )
    message.answer.assert_not_awaited()
    service.database.get_stats.assert_not_awaited()
    service.database.get_offender.assert_not_awaited()
    service.database.set_global_block.assert_not_awaited()
    service.database.clear_global_block.assert_not_awaited()


@pytest.mark.asyncio
async def test_administrator_is_exempt_even_if_registry_says_globally_blocked() -> None:
    service = _service()
    message = _moderation_message()
    service._bot_id = 99999
    service.ensure_chat_active = AsyncMock(return_value=True)
    service.is_admin = AsyncMock(return_value=True)
    service.database.is_globally_blocked.return_value = True
    service.classifier.classify_message.return_value = ClassificationVerdict(
        label=VerdictLabel.CLEAN,
        confidence=0.0,
        reasons=("sender_exempt",),
        source="exemption",
    )
    service.safe_delete = AsyncMock(return_value=True)
    service.ban_in_chat = AsyncMock(return_value=True)

    consumed = await service.on_message(message)

    assert consumed is False
    service.database.is_globally_blocked.assert_not_awaited()
    service.safe_delete.assert_not_awaited()
    service.ban_in_chat.assert_not_awaited()
    service.database.record_infraction.assert_not_awaited()
    sender = service.classifier.classify_message.await_args.args[1]
    assert sender.is_admin is True


@pytest.mark.asyncio
async def test_disabled_chat_cannot_classify_or_record_infraction() -> None:
    service = _service()
    message = _moderation_message()
    service.database.get_chat.return_value = SimpleNamespace(is_enabled=False)
    service.is_admin = AsyncMock(return_value=False)
    service.safe_delete = AsyncMock(return_value=True)

    consumed = await service.on_message(message)

    assert consumed is False
    service.database.get_chat.assert_awaited_once_with(message.chat.id)
    service.database.upsert_chat.assert_not_awaited()
    service.is_admin.assert_not_awaited()
    service.classifier.classify_message.assert_not_awaited()
    service.safe_delete.assert_not_awaited()
    service.database.record_infraction.assert_not_awaited()


def test_restricted_membership_uses_is_member_flag() -> None:
    restricted_inside = SimpleNamespace(
        status=ChatMemberStatus.RESTRICTED,
        is_member=True,
    )
    restricted_outside = SimpleNamespace(
        status=ChatMemberStatus.RESTRICTED,
        is_member=False,
    )

    assert AntiSpamBot.member_is_present(restricted_inside) is True
    assert AntiSpamBot.member_is_present(restricted_outside) is False


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("status", "expected_audit"),
    [
        (ChatMemberStatus.ADMINISTRATOR, "ban_skipped_administrator"),
        (ChatMemberStatus.CREATOR, "ban_skipped_administrator"),
        (ChatMemberStatus.KICKED, None),
    ],
)
async def test_ban_in_chat_skips_admins_and_preexisting_bans(
    status: ChatMemberStatus,
    expected_audit: str | None,
) -> None:
    service = _service()
    service._bot_id = 99999
    service.bot.get_chat_member.return_value = SimpleNamespace(status=status)

    banned = await service.ban_in_chat(-100123, 12345, reason="registry_sync")

    assert banned is False
    service.bot.ban_chat_member.assert_not_awaited()
    service.database.record_bot_ban.assert_not_awaited()
    if expected_audit is None:
        service.database.log_audit.assert_not_awaited()
    else:
        service.database.log_audit.assert_awaited_once_with(
            expected_audit,
            target_user_id=12345,
            chat_id=-100123,
            details={"reason": "registry_sync"},
        )


@pytest.mark.asyncio
async def test_ban_in_chat_records_only_a_successful_bot_ban() -> None:
    service = _service()
    service._bot_id = 99999
    service.bot.get_chat_member.return_value = SimpleNamespace(status=ChatMemberStatus.MEMBER)

    banned = await service.ban_in_chat(-100123, 12345, reason="advertising")

    assert banned is True
    service.bot.ban_chat_member.assert_awaited_once_with(
        -100123,
        12345,
        revoke_messages=True,
    )
    service.database.record_bot_ban.assert_awaited_once_with(
        -100123,
        12345,
        reason="advertising",
    )
    service.database.log_audit.assert_awaited_once_with(
        "user_banned",
        target_user_id=12345,
        chat_id=-100123,
        details={"reason": "advertising"},
    )


@pytest.mark.asyncio
async def test_failed_telegram_ban_does_not_claim_bot_ban_ownership() -> None:
    service = _service()
    service._bot_id = 99999
    service.bot.get_chat_member.return_value = SimpleNamespace(status=ChatMemberStatus.MEMBER)
    service.bot.ban_chat_member.side_effect = TelegramBadRequest(
        method=MagicMock(),
        message="not enough rights",
    )

    banned = await service.ban_in_chat(-100123, 12345, reason="advertising")

    assert banned is False
    service.database.record_bot_ban.assert_not_awaited()
    service.database.log_audit.assert_awaited_once_with(
        "ban_failed",
        target_user_id=12345,
        chat_id=-100123,
        details={"reason": "advertising"},
    )


@pytest.mark.asyncio
async def test_propagate_unban_touches_only_bot_owned_ban_chats() -> None:
    service = _service()
    service.database.list_bot_ban_chats.return_value = [-1002, -1001]

    await service.propagate_unban(12345)

    service.database.list_bot_ban_chats.assert_awaited_once_with(12345)
    service.database.list_chats.assert_not_awaited()
    assert service.bot.unban_chat_member.await_args_list == [
        call(-1002, 12345, only_if_banned=True),
        call(-1001, 12345, only_if_banned=True),
    ]
    assert service.database.clear_bot_ban.await_args_list == [
        call(-1002, 12345),
        call(-1001, 12345),
    ]
    assert service.database.log_audit.await_args_list == [
        call("user_unbanned", target_user_id=12345, chat_id=-1002),
        call("user_unbanned", target_user_id=12345, chat_id=-1001),
    ]


@pytest.mark.asyncio
async def test_external_sender_chat_ad_is_deleted_blocked_and_audited() -> None:
    service = _service()
    message = _moderation_message()
    message.from_user = None
    message.sender_chat = SimpleNamespace(
        id=-100999,
        title="广告频道",
        username="ad_channel",
    )
    service.ensure_chat_active = AsyncMock(return_value=True)
    service.classifier.classify_message.return_value = ClassificationVerdict(
        label=VerdictLabel.ADVERTISEMENT,
        confidence=0.99,
        reasons=("promotion_language",),
        heuristic_confidence=0.99,
        strong_content_evidence=True,
    )
    service.safe_delete = AsyncMock(return_value=True)
    service.send_notice = AsyncMock()

    consumed = await service.on_message(message)

    assert consumed is True
    service.safe_delete.assert_awaited_once_with(message)
    service.bot.ban_chat_sender_chat.assert_awaited_once_with(
        message.chat.id,
        message.sender_chat.id,
    )
    service.database.log_audit.assert_awaited_once_with(
        "sender_chat_advertisement",
        chat_id=message.chat.id,
        details={
            "sender_chat_id": message.sender_chat.id,
            "confidence": 0.99,
            "deleted": True,
            "blocked": True,
        },
    )
    service.database.record_infraction.assert_not_awaited()
    sender = service.classifier.classify_message.await_args.args[1]
    assert sender.user_id is None
    assert sender.nickname == "广告频道"
    assert sender.username == "ad_channel"


@pytest.mark.asyncio
async def test_current_group_sender_chat_is_treated_as_anonymous_admin() -> None:
    service = _service()
    message = _moderation_message()
    message.sender_chat = SimpleNamespace(
        id=message.chat.id,
        title=message.chat.title,
        username=message.chat.username,
    )
    service.ensure_chat_active = AsyncMock(return_value=True)
    service.safe_delete = AsyncMock(return_value=True)

    consumed = await service.on_message(message)

    assert consumed is False
    service.classifier.classify_message.assert_not_awaited()
    service.safe_delete.assert_not_awaited()
    service.bot.ban_chat_sender_chat.assert_not_awaited()
    service.database.log_audit.assert_not_awaited()
