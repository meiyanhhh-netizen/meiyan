from __future__ import annotations

import hashlib
import importlib.util
import json
import shutil
import subprocess
import tomllib
from pathlib import Path
from types import SimpleNamespace

import pytest

SCRIPT = Path(__file__).resolve().parents[1] / "scripts/upgrade_server.py"
SPEC = importlib.util.spec_from_file_location("antispam_upgrade", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
upgrade = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(upgrade)


@pytest.fixture
def installation(tmp_path: Path) -> tuple[Path, Path]:
    project_root = SCRIPT.parents[1]
    target = tmp_path / "datang_ai_antispam_bot"
    (target / "src/antispam_bot").mkdir(parents=True)
    for filename in ("config.py", "models.py", "db.py"):
        shutil.copy2(project_root / "src/antispam_bot" / filename, target / "src/antispam_bot")
    (target / "src/antispam_bot/bot.py").write_text("# old-bot\n")
    (target / "src/antispam_bot/classifier.py").write_text("# old-classifier\n")
    (target / ".env").write_text("BOT_TOKEN=test-placeholder\nAI_API_KEY=\n")
    (target / "docker-compose.yml").write_text("services:\n  anti-ad-bot:\n    build: .\n")
    (target / "pyproject.toml").write_text(
        '[project]\nname = "datang-ai-antispam-bot"\nversion = "1.0.0"\n'
        'dependencies = ["custom-existing-dependency==1.2.3"]\n'
    )
    package = tmp_path / "payload"
    (package / "src/antispam_bot").mkdir(parents=True)
    (package / "scripts").mkdir()
    for relative in upgrade.REPLACEMENTS:
        shutil.copy2(project_root / relative, package / relative)
    shutil.copy2(project_root / "scripts/smoke_upgrade.py", package / "scripts")
    manifest = {
        "version": "1.0.9",
        "files": {
            relative: hashlib.sha256((package / relative).read_bytes()).hexdigest()
            for relative in upgrade.REPLACEMENTS
        },
    }
    (package / "payload-manifest.json").write_text(json.dumps(manifest))
    return target, package


class FakeDocker:
    old_image = "sha256:" + "a" * 64
    new_image = "sha256:" + "b" * 64
    image_ref = "datang_ai_antispam_bot-anti-ad-bot:latest"

    def __init__(self, *, failure: str | None = None) -> None:
        self.failure = failure
        self.running = True
        self.new = False
        self.reference_points_to_new = False
        self.services = "anti-ad-bot\nunrelated-bot\n"
        self.calls: list[list[str]] = []

    def __call__(self, args: list[str], **kwargs: object) -> SimpleNamespace:
        args = list(args)
        self.calls.append(args)
        assert args[0] == "docker"
        assert not any(value in args for value in ("prune", "down", "--volumes", "--env-file"))
        out = ""
        if args[1] == "compose":
            if args[2] == "version":
                out = "Docker Compose test"
            elif args[-2:] == ["config", "--services"]:
                out = self.services
            elif "ps" in args:
                out = "new-container" if self.new else "old-container"
            elif "build" in args:
                assert args[-1] == "anti-ad-bot"
                if self.failure == "build":
                    raise subprocess.CalledProcessError(1, args)
                self.reference_points_to_new = True
            elif "stop" in args:
                assert args[-1] == "anti-ad-bot"
                self.running = False
            elif "up" in args:
                assert args[-1] == "anti-ad-bot" and "--no-deps" in args
                self.running = True
                self.new = self.reference_points_to_new
        elif args[1] == "inspect":
            field = args[3]
            if field == "{{.Image}}":
                out = self.new_image if self.new else self.old_image
            elif field == "{{.Config.Image}}":
                out = self.image_ref
            elif field == "{{.State.Running}}":
                out = "true" if self.running else "false"
            elif field == "{{.RestartCount}}":
                out = "1" if self.failure == "restart" and self.new else "0"
            elif field == "{{json .Mounts}}":
                out = json.dumps([{"Destination": "/app/data"}])
            else:
                raise AssertionError("must never dump Docker environment")
        elif args[1] == "run":
            assert "--network" in args and "none" in args
            if "--volumes-from" in args:
                if self.failure == "data":
                    raise subprocess.CalledProcessError(1, args)
                kwargs["stdout"].write(b"test-database-backup")
            else:
                assert "--read-only" in args and "input" in kwargs
                if self.failure == "smoke":
                    raise subprocess.CalledProcessError(1, args)
        elif args[1] == "tag" and args[-1] == self.image_ref:
            self.reference_points_to_new = False
        elif args[1] == "logs":
            out = "" if self.failure == "unconnected" else "Run polling for bot"
        elif args[1] == "exec":
            out = "1.0.9"
        elif args[1] not in {"info", "tag"}:
            raise AssertionError(args)
        return SimpleNamespace(stdout=out, stderr="", returncode=0)


def test_upgrade_preserves_env_dependencies_data_and_unrelated_services(
    installation: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    target, package = installation
    original_env = (target / ".env").read_bytes()
    fake = FakeDocker()
    monkeypatch.setattr(upgrade.subprocess, "run", fake)
    upgrade.upgrade(package, target)
    assert (target / ".env").read_bytes() == original_env
    project = tomllib.loads((target / "pyproject.toml").read_text())
    assert project["project"]["version"] == "1.0.9"
    assert project["project"]["dependencies"] == ["custom-existing-dependency==1.2.3"]
    assert (target / "src/antispam_bot/version.py").is_file()
    assert (target / "src/antispam_bot/ad_rules.py").is_file()
    backups = list((target.parent / "datang-antispam-backups").iterdir())
    assert len(backups) == 1
    assert (backups[0] / "data.tar.gz").read_bytes() == b"test-database-backup"
    assert (backups[0] / "source/.env").read_bytes() == original_env


@pytest.mark.parametrize("failure", ["build", "smoke", "data", "restart"])
def test_failure_rolls_back_without_touching_env_or_deleting_data(
    installation: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
    failure: str,
) -> None:
    target, package = installation
    fake = FakeDocker(failure=failure)
    monkeypatch.setattr(upgrade.subprocess, "run", fake)
    with pytest.raises(subprocess.CalledProcessError if failure != "restart" else RuntimeError):
        upgrade.upgrade(package, target)
    assert (target / "src/antispam_bot/bot.py").read_text() == "# old-bot\n"
    assert not (target / "src/antispam_bot/version.py").exists()
    assert tomllib.loads((target / "pyproject.toml").read_text())["project"]["version"] == "1.0.0"
    assert "BOT_TOKEN=test-placeholder" in (target / ".env").read_text()
    assert fake.running is True
    assert fake.new is False
    assert not (target / "src/antispam_bot/ad_rules.py").exists()


def test_manual_rollback_retains_newer_settings_and_existing_data(
    installation: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    target, package = installation
    fake = FakeDocker()
    monkeypatch.setattr(upgrade.subprocess, "run", fake)
    upgrade.upgrade(package, target)
    backup = next((target.parent / "datang-antispam-backups").iterdir())
    (target / ".env").write_text("BOT_TOKEN=new-test-placeholder\nAI_API_KEY=\n")
    (target / "data").mkdir()
    (target / "data/antispam.db").write_bytes(b"newer-infraction-records")
    (target / "data/antispam.db.rules.db").write_bytes(b"newer-admin-rules")
    upgrade.rollback(backup)
    assert (target / ".env").read_text().startswith("BOT_TOKEN=new-test-placeholder")
    assert (target / "data/antispam.db").read_bytes() == b"newer-infraction-records"
    assert (target / "data/antispam.db.rules.db").read_bytes() == b"newer-admin-rules"
    assert fake.new is False


def test_unconfirmed_telegram_connection_is_reported_honestly(
    installation: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    target, package = installation
    fake = FakeDocker(failure="unconnected")
    monkeypatch.setattr(upgrade.subprocess, "run", fake)
    monkeypatch.setattr(upgrade.time, "sleep", lambda _: None)
    upgrade.upgrade(package, target)
    assert "尚未确认 Telegram 连接" in capsys.readouterr().out


def test_tampered_payload_is_rejected_before_docker_or_source_writes(
    installation: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    target, package = installation
    (package / "src/antispam_bot/bot.py").write_text("tampered")
    fake = FakeDocker()
    monkeypatch.setattr(upgrade.subprocess, "run", fake)
    with pytest.raises(ValueError, match="校验失败"):
        upgrade.upgrade(package, target)
    assert fake.calls == []
    assert (target / "src/antispam_bot/bot.py").read_text() == "# old-bot\n"


def test_ambiguous_service_is_rejected_before_backup_or_source_writes(
    installation: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    target, package = installation
    fake = FakeDocker()
    fake.services = "bot\nanti-ad-bot\n"
    monkeypatch.setattr(upgrade.subprocess, "run", fake)
    with pytest.raises(ValueError, match="唯一识别"):
        upgrade.upgrade(package, target)
    assert not (target.parent / "datang-antispam-backups").exists()


def test_symbolic_link_code_destination_is_rejected(
    installation: tuple[Path, Path],
    tmp_path: Path,
) -> None:
    target, _ = installation
    unrelated = tmp_path / "unrelated.py"
    unrelated.write_text("keep-me")
    (target / "src/antispam_bot/version.py").symlink_to(unrelated)
    with pytest.raises(ValueError, match="符号链接"):
        upgrade.validate_target(target)
    assert unrelated.read_text() == "keep-me"
