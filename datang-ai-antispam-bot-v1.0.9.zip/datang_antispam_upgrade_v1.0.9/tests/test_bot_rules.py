from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio

from antispam_bot.ad_rules import AdRuleStore
from antispam_bot.bot import AntiSpamBot
from antispam_bot.classifier import HybridAdClassifier
from antispam_bot.config import Settings
from antispam_bot.db import Database
from antispam_bot.models import SenderContext

SAMPLE = "本店专业批发各种家居用品，现货供应欢迎全国客户前来洽谈联系 @seller88 https://example.com"


def message(text: str, *, actor: int = 10, chat: int = -1001, mid: int = 1):
    return SimpleNamespace(
        chat=SimpleNamespace(id=chat, type="supergroup", title="测试群", username=None),
        from_user=SimpleNamespace(id=actor, full_name="成员", username=None, is_bot=False),
        text=text,
        caption=None,
        entities=[],
        caption_entities=[],
        message_id=mid,
        reply_to_message=None,
        answer=AsyncMock(),
    )


@pytest_asyncio.fixture
async def service(tmp_path: Path):
    rules = AdRuleStore(tmp_path / "main.db.rules.db")
    db = Database(tmp_path / "main.db")
    await rules.initialize()
    await db.initialize()
    bot = AntiSpamBot(AsyncMock(), db, HybridAdClassifier(), Settings(), rules=rules)
    bot._bot_id = 9999
    bot.ensure_chat_active = AsyncMock(return_value=True)
    bot.is_admin = AsyncMock(side_effect=lambda chat, uid: uid == 10)
    bot.can_manage = AsyncMock(return_value=True)
    bot.missing_bot_permissions = AsyncMock(return_value=[])
    bot.safe_delete = AsyncMock(return_value=True)
    bot.send_notice = AsyncMock()
    try:
        yield bot
    finally:
        await bot.shutdown()
        await rules.close()
        await db.close()


async def test_teach_then_receive_new_variant_delete_and_keep_progressive_policy(service) -> None:
    command = message("/adlearn 相似")
    command.reply_to_message = message(SAMPLE, actor=20, mid=70)
    await service.on_adlearn(command)
    service.safe_delete.assert_awaited_once_with(command.reply_to_message)
    assert await service.database.get_offender(20) is None
    rules = await service.rules.list_rules(-1001)
    assert len(rules) == 1
    service.safe_delete.reset_mock()
    incoming = message(SAMPLE.replace("seller88", "newuser88"), actor=20, mid=71)
    assert await service.on_message(incoming)
    service.safe_delete.assert_awaited_once_with(incoming)
    assert (await service.database.get_offender(20)).confirmed_ads == 1
    assert "第 1 次违规" in service.send_notice.await_args.args[1]


async def test_auto_category_learn_deletes_other_copy_in_category(service) -> None:
    command = message("/adlearn")
    command.reply_to_message = message("百家乐开户，联系 @seller88", actor=20, mid=80)
    await service.on_adlearn(command)
    assert (await service.rules.list_rules(-1001))[0].kind == "gambling"
    verdict = await service.classify_with_rules(
        message("PG电子下注，点击 https://offer.cc", actor=21),
        "PG电子下注，点击 https://offer.cc",
        SenderContext(user_id=21),
    )
    assert verdict.is_ad and verdict.source == "group_rule"


@pytest.mark.parametrize(
    "method,text",
    [("on_adlearn", "/adlearn"), ("on_adtype", "/adtype 博彩 开"), ("on_adforget", "/adforget 1")],
)
async def test_non_admin_cannot_mutate_rules(service, method: str, text: str) -> None:
    service.can_manage.return_value = False
    command = message(text, actor=30)
    command.reply_to_message = message(SAMPLE, actor=20)
    await getattr(service, method)(command)
    assert await service.rules.list_rules(-1001) == ()
    service.safe_delete.assert_not_awaited()


async def test_rule_cannot_override_admin_exemption_and_needs_no_ai(service) -> None:
    await service.rules.add_rule(-1001, 10, kind="sample", content=SAMPLE)
    service.classifier = AsyncMock()
    member = SenderContext(user_id=20)
    verdict = await service.classify_with_rules(message(SAMPLE, actor=20), SAMPLE, member)
    assert verdict.is_ad and verdict.source == "group_rule"
    service.classifier.classify_message.assert_not_awaited()
    verdict = await service.classify_with_rules(
        message(SAMPLE), SAMPLE, SenderContext(user_id=10, is_admin=True), local_only=True
    )
    assert not verdict.is_ad and verdict.source == "exemption"


async def test_type_toggle_remove_and_status_are_scoped(service) -> None:
    command = message("/adtype 博彩 开")
    await service.on_adtype(command)
    assert len(await service.rules.list_rules(-1001)) == 1
    await service.on_adtype(command)
    assert len(await service.rules.list_rules(-1001)) == 1
    await service.on_adrules(message("/adrules"))
    rule_id = (await service.rules.list_rules(-1001))[0].id
    await service.on_adforget(message(f"/adforget {rule_id}", chat=-1002))
    assert len(await service.rules.list_rules(-1001)) == 1
    await service.on_adtype(message("/adtype 博彩 关"))
    assert await service.rules.list_rules(-1001) == ()
    status = message("/status")
    await service.on_status(status)
    assert "本群教学规则：0 条" in status.answer.await_args.args[0]


async def test_forget_immediately_stops_rule_match_and_preserves_previous_strikes(service) -> None:
    rule_id, _ = await service.rules.add_rule(-1001, 10, kind="sample", content=SAMPLE)
    await service.on_message(message(SAMPLE, actor=20, mid=60))
    await service.on_adforget(message(f"/adforget {rule_id}"))
    assert await service.rules.match(-1001, SAMPLE) is None
    assert (await service.database.get_offender(20)).confirmed_ads == 1


async def test_missing_permissions_and_unsupported_samples_never_saved_or_deleted(service) -> None:
    command = message("/adlearn")
    command.reply_to_message = message(SAMPLE, actor=20)
    service.missing_bot_permissions.return_value = ["删除消息"]
    await service.on_adlearn(command)
    assert await service.rules.list_rules(-1001) == ()
    service.safe_delete.assert_not_awaited()
    service.missing_bot_permissions.return_value = []
    command.reply_to_message.text = "您好"
    await service.on_adlearn(command)
    assert await service.rules.list_rules(-1001) == ()
    service.safe_delete.assert_not_awaited()


async def test_adcheck_reports_teaching_rule_without_enforcement(service) -> None:
    rule_id, _ = await service.rules.add_rule(-1001, 10, kind="sample", content=SAMPLE)
    command = message("/adcheck")
    command.reply_to_message = message(SAMPLE, actor=20)
    await service.on_adcheck(command)
    assert f"group_rule:{rule_id}:sample" in command.answer.await_args.args[0]
    service.safe_delete.assert_not_awaited()
    assert await service.database.get_offender(20) is None


async def test_sample_delete_failure_keeps_saved_rule_and_reports_failure(service) -> None:
    service.safe_delete.return_value = False
    command = message("/adlearn 相似")
    command.reply_to_message = message(SAMPLE, actor=20)
    await service.on_adlearn(command)
    assert await service.rules.match(-1001, SAMPLE) is not None
    assert "删除失败" in command.answer.await_args.args[0]


async def test_edited_messages_and_external_channel_messages_use_taught_rules(service) -> None:
    await service.rules.add_rule(-1001, 10, kind="sample", content=SAMPLE)
    incoming = message(SAMPLE, actor=20)
    incoming.sender_chat = SimpleNamespace(id=-100555, title="频道", username=None)
    assert await service.moderate_sender_chat(incoming)
    service.safe_delete.assert_awaited_once_with(incoming)
    service.bot.ban_chat_sender_chat.assert_awaited_once_with(-1001, -100555)
    assert service.router.edited_message.handlers[0].callback == service.on_message


async def test_teaching_plain_link_and_captionless_media(service) -> None:
    command = message("/adlearn")
    command.reply_to_message = message("https://example.com/advert", actor=20, mid=30)
    await service.on_adlearn(command)
    assert "指定广告链接" in command.answer.await_args.args[0]
    verdict = await service.classify_with_rules(
        command.reply_to_message, "https://example.com/advert", SenderContext(user_id=20)
    )
    assert verdict.source == "group_rule"
    picture = message("", actor=20, mid=31)
    picture.photo = [SimpleNamespace(file_unique_id="sample-photo")]
    command.reply_to_message = picture
    await service.on_adlearn(command)
    assert await service.on_message(picture)
    assert len(await service.rules.list_rules(-1001)) == 2


async def test_income_contact_ad_is_deleted_and_only_its_sender_gets_a_strike(service) -> None:
    card = message("", actor=20)
    card.contact = SimpleNamespace(
        first_name="一天赚8k", last_name=None, phone_number="+1 202 555 0148", user_id=7654321
    )
    assert await service.on_message(card)
    service.safe_delete.assert_awaited_once_with(card)
    assert (await service.database.get_offender(20)).confirmed_ads == 1
    assert await service.database.get_offender(7654321) is None
    assert "第 1 次违规" in service.send_notice.await_args.args[1]


async def test_plain_contact_is_kept_and_taught_contact_can_be_removed_later(service) -> None:
    card = message("", actor=20)
    card.contact = SimpleNamespace(first_name="张三", last_name=None, phone_number="+12025550148")
    assert not await service.on_message(card)
    service.safe_delete.assert_not_awaited()
    command = message("/adlearn 相似")
    command.reply_to_message = card
    await service.on_adlearn(command)
    rule = (await service.rules.list_rules(-1001))[0]
    assert rule.media_key.startswith("contact:")
    assert "12025550148" not in rule.media_key
    changed = message("", actor=21, mid=2)
    changed.contact = SimpleNamespace(
        first_name="新名字", last_name=None, phone_number="+1 202 555 0148"
    )
    assert await service.on_message(changed)


async def test_username_only_is_deleted_without_an_ad_strike_or_cross_group_ban(service) -> None:
    ordinary = message("大家好，我的用户名是 @example88", actor=20)
    assert await service.on_message(ordinary)
    service.safe_delete.assert_awaited_once_with(ordinary)
    assert await service.database.get_offender(20) is None
    assert not await service.database.is_join_prebanned(20)
    service.bot.ban_chat_member.assert_not_awaited()
    ad = message("百家乐开户，联系 @example88", actor=20, mid=2)
    assert await service.on_message(ad)
    assert (await service.database.get_offender(20)).confirmed_ads == 1


async def test_username_admin_exemption_and_group_toggle(service) -> None:
    assert not await service.on_message(message("联系 @example88", actor=10))
    service.safe_delete.assert_not_awaited()
    await service.on_nousername(message("/nousername 关"))
    assert not await service.rules.username_blocked(-1001)
    assert await service.rules.username_blocked(-1002)
    assert not await service.on_message(message("你好 @example88", actor=20))
    await service.on_nousername(message("/nousername 开"))
    assert await service.on_message(message("你好 @example88", actor=20))
    assert await service.database.get_offender(20) is None


async def test_non_admin_cannot_switch_username_policy(service) -> None:
    service.can_manage.return_value = False
    await service.on_nousername(message("/nousername 关", actor=20))
    assert await service.rules.username_blocked(-1001)


async def test_new_types_can_be_taught_without_dropping_existing_rules(service) -> None:
    await service.rules.add_rule(-1001, 10, kind="gambling")
    card = message("", actor=20)
    card.contact = SimpleNamespace(
        first_name="一天赚8k", last_name=None, phone_number="+12025550148"
    )
    command = message("/adlearn")
    command.reply_to_message = card
    await service.on_adlearn(command)
    assert {r.kind for r in await service.rules.list_rules(-1001)} == {"gambling", "income_project"}


async def test_rich_long_ad_learns_and_deletes_a_later_copy(service) -> None:
    text = "要过年了招人搞钱，单人一天能赚2843，想挣钱有执行力的来，过来了解具体 @QQHB93"
    ad = message("", actor=20, mid=30)
    ad.rich_message = {"blocks": [{"type": "paragraph", "text": {"type": "bold", "text": text}}]}
    command = message("/adlearn@DTJT002_BOT")
    command.reply_to_message = ad
    await service.on_adlearn(command)
    assert "已保存" in command.answer.await_args.args[0]
    assert "1.0.9" in command.answer.await_args.args[0]
    service.safe_delete.assert_awaited_once_with(ad)
    ad.message_id = 31
    assert await service.on_message(ad)


async def test_handle_only_ad_can_be_learned_instead_of_short_sample_error(service) -> None:
    command = message("/adlearn")
    command.reply_to_message = message("@QQHB93", actor=20)
    await service.on_adlearn(command)
    assert (await service.rules.list_rules(-1001))[0].kind == "link"
    assert await service.rules.match(-1001, "https://t.me/qqhb93") is not None


async def test_manual_pasted_sample_without_reply_is_saved_without_deleting_another_message(
    service,
) -> None:
    command = message("/adlearn 文本 " + SAMPLE)
    await service.on_adlearn(command)
    assert "已保存输入的文字样本" in command.answer.await_args.args[0]
    assert await service.rules.match(-1001, SAMPLE) is not None
    service.safe_delete.assert_not_awaited()


async def test_unknown_short_sample_reports_version_and_counts_then_direct_delete_works(
    service,
) -> None:
    command = message("/adlearn")
    command.reply_to_message = message("", actor=20)
    await service.on_adlearn(command)
    answer = command.answer.await_args.args[0]
    assert "读取诊断 1.0.9" in answer and "/addelete" in answer and "提取 0" in answer
    service.safe_delete.assert_not_awaited()
    command.text = "/addelete"
    await service.on_addelete(command)
    service.safe_delete.assert_awaited_once_with(command.reply_to_message)
    assert await service.database.get_offender(20) is None


async def test_non_admin_cannot_use_direct_ad_delete(service) -> None:
    service.can_manage.return_value = False
    command = message("/addelete", actor=20)
    command.reply_to_message = message("normal text", actor=21)
    await service.on_addelete(command)
    service.safe_delete.assert_not_awaited()
