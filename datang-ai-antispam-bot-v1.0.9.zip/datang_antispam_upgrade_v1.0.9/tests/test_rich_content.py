from __future__ import annotations

from types import SimpleNamespace

import pytest
from aiogram.types import Message

from antispam_bot.ad_rules import canonical_sample, destinations, media_key, message_has_username
from antispam_bot.bot import AntiSpamBot
from antispam_bot.classifier import HybridAdClassifier
from antispam_bot.content import rich_content

SCREENSHOT = (
    "要过年了招人搞钱 💸\n单人一天能赚2843+ 🧧\n想挣钱 有执行力 不墨迹的来 🔥\n"
    "简单安全容易上手 ✅\n没有任何弄虚作假 🌍\n不用担心被跑路\n"
    "过来了解看看具体\n@QQHB93"
)


def rich_message(blocks: list[dict]) -> Message:
    return Message.model_validate(
        {
            "message_id": 55,
            "date": 0,
            "chat": {"id": -1001, "type": "supergroup"},
            "from": {"id": 20, "is_bot": False, "first_name": "测试"},
            "rich_message": {"blocks": blocks},
        }
    )


async def test_screenshot_plain_text_is_long_and_classifies_as_an_ad() -> None:
    assert len(canonical_sample(SCREENSHOT)) >= 50
    assert (await HybridAdClassifier().classify(SCREENSHOT)).is_ad


async def test_actual_aiogram_rich_message_reads_bold_paragraphs_and_mention() -> None:
    message = rich_message(
        [
            {"type": "paragraph", "text": {"type": "bold", "text": SCREENSHOT}},
            {
                "type": "paragraph",
                "text": {"type": "mention", "text": "联系", "username": "QQHB93"},
            },
        ]
    )
    assert not message.text
    content = AntiSpamBot.message_content(message)
    assert "2843" in content and "https://t.me/QQHB93" in content
    assert len(canonical_sample(content)) >= 50
    assert (await HybridAdClassifier().classify(content)).is_ad
    assert message_has_username(message)


def test_nested_rich_nodes_extract_only_visible_fields_and_link_targets() -> None:
    message = SimpleNamespace(
        rich_message={
            "blocks": [
                {
                    "type": "details",
                    "summary": "摘要",
                    "blocks": [
                        {
                            "type": "paragraph",
                            "text": ["日", {"type": "bold", "text": "赚"}, "8000"],
                        },
                        {
                            "type": "paragraph",
                            "text": {"type": "url", "text": "详情", "url": "https://example.com"},
                        },
                        {"type": "table", "cells": [[{"text": "联系"}]]},
                    ],
                },
                {
                    "type": "buttons",
                    "buttons": [
                        [{"text": "教程", "url": "tg://user?id=321", "callback_data": "secret"}]
                    ],
                },
            ],
            "reply_to_message": {"text": "must-not-read"},
            "user": {"first_name": "must-not-read"},
        }
    )
    rich = rich_content(message)
    assert "日赚8000" in rich.text
    assert "摘要" in rich.text and "教程" in rich.text
    assert "secret" not in rich.text and "must-not-read" not in rich.text
    assert set(rich.links) == {"https://example.com", "tg://user?id=321"}
    assert message_has_username(message)


def test_rich_callback_protocol_and_replied_to_ad_do_not_become_content() -> None:
    message = SimpleNamespace(
        rich_message={
            "blocks": [
                {
                    "type": "buttons",
                    "buttons": [
                        [{"text": "下一页", "callback_data": "@hidden88 https://t.me/hidden88"}]
                    ],
                }
            ]
        },
        reply_to_message=SimpleNamespace(text=SCREENSHOT),
    )
    assert not message_has_username(message)
    assert "hidden88" not in rich_content(message).text
    assert not rich_content(message).links


def test_rich_and_classic_media_have_exact_learning_identity() -> None:
    rich = SimpleNamespace(
        rich_message={
            "blocks": [
                {
                    "type": "photo",
                    "photo": [{"file_unique_id": "small"}, {"file_unique_id": "large"}],
                }
            ]
        }
    )
    assert media_key(rich) == "photo:large"
    assert (
        media_key(SimpleNamespace(sticker=SimpleNamespace(file_unique_id="sticker")))
        == "sticker:sticker"
    )
    assert (
        media_key(SimpleNamespace(video_note=SimpleNamespace(file_unique_id="video")))
        == "video_note:video"
    )


@pytest.mark.parametrize("value", ["@QQHB93", "https://t.me/QQHB93", "tg://resolve?domain=QQHB93"])
def test_handle_only_learning_uses_the_same_canonical_destination(value: str) -> None:
    assert "t.me/qqhb93" in destinations(value)


def test_rich_extraction_limits_deep_nesting_and_large_strings() -> None:
    deep = "bottom"
    for _ in range(40):
        deep = {"text": deep}
    assert rich_content(SimpleNamespace(rich_message=deep)).truncated
    large = rich_content(SimpleNamespace(rich_message={"blocks": [{"text": "字" * 50000}]}))
    assert large.truncated and len(large.text) <= 20000
