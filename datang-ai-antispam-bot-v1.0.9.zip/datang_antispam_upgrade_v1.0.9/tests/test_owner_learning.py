# ruff: noqa: F811
from unittest.mock import AsyncMock

import pytest
from test_bot_rules import message, service  # noqa: F401

from antispam_bot.config import Settings


@pytest.mark.parametrize("text", ["123", "🔥", "好"])
async def test_owner_short_sample_matches_exactly(service, text):
    service.settings = Settings(owner_ids=frozenset({10}))
    command = message("/adlearn 相似")
    command.reply_to_message = message(text, actor=20, mid=70)
    await service.on_adlearn(command)
    rule = await service.rules.match(-1001, text)
    assert rule and rule.kind == "exact"
    assert await service.rules.match(-1001, text + "其他") is None
    assert await service.rules.match(-1001, "") is None
    assert await service.rules.match(-1002, text) is None
    service.safe_delete.assert_awaited_once_with(command.reply_to_message)


async def test_owner_bypasses_category_cap_and_permission_gate(service):
    service.settings = Settings(owner_ids=frozenset({10}))
    service.rules.MAX_RULES_PER_CHAT = 1
    await service.rules.add_rule(-1001, 10, kind="gambling")
    service.missing_bot_permissions = AsyncMock(return_value=["can_restrict_members"])
    command = message("/adlearn 博彩")
    command.reply_to_message = message("完全无关的短文本", actor=20, mid=70)
    await service.on_adlearn(command)
    assert len(await service.rules.list_rules(-1001)) == 2
    assert await service.rules.match(-1001, "完全无关的短文本")
    service.safe_delete.assert_awaited_once()


async def test_ordinary_admin_still_cannot_force_short_rule(service):
    command = message("/adlearn 相似")
    command.reply_to_message = message("123", actor=20, mid=70)
    await service.on_adlearn(command)
    assert not await service.rules.list_rules(-1001)
    service.safe_delete.assert_not_awaited()
    with pytest.raises(ValueError):
        await service.rules.add_rule(-1001, 10, kind="exact", content="123")
    service.rules.MAX_RULES_PER_CHAT = 1
    await service.rules.add_rule(-1001, 10, kind="gambling")
    with pytest.raises(ValueError):
        await service.rules.add_rule(-1001, 10, kind="adult")


async def test_unreadable_owner_selection_never_becomes_wildcard(service):
    service.settings = Settings(owner_ids=frozenset({10}))
    command = message("/adlearn")
    command.reply_to_message = message("", actor=20, mid=70)
    await service.on_adlearn(command)
    assert await service.rules.match(-1001, "", "message:-1001:70")
    assert await service.rules.match(-1001, "", "message:-1001:71") is None
    assert await service.rules.match(-1001, "正常聊天") is None
    assert "只登记本条" in command.answer.await_args.args[0]


async def test_owner_direct_delete_does_not_require_classification(service):
    service.settings = Settings(owner_ids=frozenset({10}))
    service.missing_bot_permissions = AsyncMock(return_value=["can_invite_users"])
    command = message("/addelete")
    command.reply_to_message = message("", actor=10, mid=70)
    await service.on_addelete(command)
    service.safe_delete.assert_awaited_once_with(command.reply_to_message)
    assert not await service.rules.list_rules(-1001)
