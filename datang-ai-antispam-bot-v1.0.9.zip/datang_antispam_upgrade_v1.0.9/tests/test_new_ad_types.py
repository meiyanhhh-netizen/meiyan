from __future__ import annotations

from types import SimpleNamespace

import pytest
from aiogram.types import Message

from antispam_bot.ad_rules import message_has_username, username_in_text
from antispam_bot.bot import AntiSpamBot
from antispam_bot.classifier import HybridAdClassifier, _AIResult
from antispam_bot.config import ClassifierConfig

RED_PACKET = (
    "想多一份收入的看这里 💰\n支付宝口令红包玩法 🧧\n"
    "手把手讲解操作流程 📱\n不夸大收益 理性参与 ✅\n想了解详情欢迎咨询 🔥\n@"
)
PROJECT = "简单安全容易上手 ✅ 没有任何弄虚作假 🌍 不用担心被跑路 过来了解看看具体 @example88"


def contact_message(name: str = "一天赚8k", *, text: str | None = None) -> Message:
    return Message.model_validate(
        {
            "message_id": 51,
            "date": 0,
            "chat": {"id": -1001, "type": "supergroup", "title": "测试群"},
            "from": {"id": 20, "is_bot": False, "first_name": "普通成员"},
            "text": text,
            "contact": {
                "first_name": name,
                "phone_number": "+1 202 555 0148",
                "user_id": 7654321,
                "vcard": "This field must never be used as ad content",
            },
        }
    )


@pytest.mark.parametrize(
    "content,reason",
    [
        (RED_PACKET, "red_packet_advertisement"),
        (RED_PACKET.replace("口令红包", "口\u200b令\ufeff红包"), "red_packet_advertisement"),
        (PROJECT, "income_project_advertisement"),
        ("日入5000，欢迎咨询 @example88", "income_project_advertisement"),
        ("月收入20000，私聊了解详情 https://example.com", "income_project_advertisement"),
    ],
)
async def test_new_screenshot_ad_types_work_without_ai(content: str, reason: str) -> None:
    verdict = await HybridAdClassifier().classify(content)
    assert verdict.is_ad and verdict.confidence >= 0.96
    assert reason in verdict.reasons and verdict.strong_content_evidence


@pytest.mark.parametrize("name", ["一天赚8k", "日入5000", "月收入20000", "每天赚８Ｋ"])
async def test_contact_name_is_message_content_and_income_card_is_detected(name: str) -> None:
    content = AntiSpamBot.message_content(contact_message(name))
    assert name in content
    assert "名片电话" in content
    assert "vcard" not in content and "7654321" not in content
    verdict = await HybridAdClassifier().classify(content)
    assert verdict.is_ad and "income_project_advertisement" in verdict.reasons


@pytest.mark.parametrize(
    "content",
    [
        "支付宝口令红包怎么发送？",
        "支付宝口令红包教程，讲解收益计算 https://example.com/docs",
        "我想多一份收入，有什么建议？",
        "这个工具简单安全容易上手，教程 https://example.com/help",
        "张师傅的维修名片，请保存",
        "不要相信一天赚8k，举报 @example88",
        "反诈提醒：" + RED_PACKET,
        "举报：" + PROJECT,
    ],
)
async def test_new_patterns_leave_ordinary_content_and_reports_to_existing_rules(
    content: str,
) -> None:
    verdict = await HybridAdClassifier().classify(content)
    assert not verdict.is_ad
    assert "red_packet_advertisement" not in verdict.reasons
    assert "income_project_advertisement" not in verdict.reasons


async def test_ordinary_contact_or_income_sender_name_is_not_an_ad() -> None:
    content = AntiSpamBot.message_content(contact_message("维修师傅 李师傅"))
    assert not (await HybridAdClassifier().classify(content)).is_ad
    assert not (await HybridAdClassifier().classify("你好", nickname="一天赚8k")).is_ad


async def test_new_ad_local_verdict_cannot_be_downgraded_by_ai(monkeypatch) -> None:
    classifier = HybridAdClassifier(ClassifierConfig(ai_endpoint="http://127.0.0.1/v1"))

    async def remote_clean(*args):
        return _AIResult(probability=0, reasons=("ai:clean",))

    monkeypatch.setattr(classifier, "_classify_with_ai", remote_clean)
    assert (await classifier.classify(RED_PACKET)).is_ad
    assert not (await classifier.classify(RED_PACKET, sender_is_admin=True)).is_ad


@pytest.mark.parametrize(
    "value",
    [
        "@example88",
        "联系＠ｅｘａｍｐｌｅ８８",
        "t.me/example88",
        "https://t.me/example88/123",
        "https://telegram.me/example88",
        "https://t.me/s/example88",
        "tg://user?id=12345",
        "tg://resolve?domain=example88",
        "@exa\u200bmple88",
    ],
)
def test_username_rule_covers_plain_and_hidden_username_destinations(value: str) -> None:
    assert username_in_text(value)


@pytest.mark.parametrize(
    "value",
    [
        "hello@example.com",
        "https://docs.python.org",
        "https://t.me/c/123456/7",
        "https://t.me/+private_invite",
        "https://t.me/share/url?url=https://example.com",
        "https://t.me.evil.example/user",
        "我的用户名设置好了",
        "今天讨论邮箱 admin@example.com",
    ],
)
def test_username_rule_does_not_treat_emails_or_generic_links_as_usernames(value: str) -> None:
    assert not username_in_text(value)


def test_username_rule_reads_entities_buttons_and_end_of_long_message_only() -> None:
    assert message_has_username(SimpleNamespace(text="字" * 4090 + "@example88"))
    assert message_has_username(SimpleNamespace(entities=[SimpleNamespace(type="text_mention")]))
    assert message_has_username(
        SimpleNamespace(entities=[SimpleNamespace(type="text_link", url="tg://user?id=12345")])
    )
    assert message_has_username(
        SimpleNamespace(
            reply_markup=SimpleNamespace(
                inline_keyboard=[[SimpleNamespace(text="了解详情", url="https://t.me/example88")]]
            )
        )
    )
    assert not message_has_username(
        SimpleNamespace(
            text="收到",
            from_user=SimpleNamespace(username="example88"),
            reply_to_message=SimpleNamespace(text="@example88"),
        )
    )
    assert not message_has_username(SimpleNamespace(text="/status@DTJT002_BOT"))
