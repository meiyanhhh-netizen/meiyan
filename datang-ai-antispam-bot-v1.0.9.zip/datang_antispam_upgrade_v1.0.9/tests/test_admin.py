# ruff: noqa: F811
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from aiogram.types import Message
from test_bot_rules import message, service  # noqa: F401

from antispam_bot.config import Settings
from antispam_bot.models import SenderContext


def private(text, actor=10):
    msg = message(text, actor=actor)
    msg.chat.type = "private"
    msg.chat.id = actor
    return msg


def callback(data, actor=10, chat=None, kind="private"):
    return SimpleNamespace(
        data=data,
        from_user=SimpleNamespace(id=actor),
        answer=AsyncMock(),
        message=Message.model_validate(
            {
                "message_id": 42,
                "date": 1,
                "chat": {"id": chat if chat is not None else actor, "type": kind},
            }
        ),
    )


@pytest_asyncio.fixture
async def panel(service):
    service.settings = Settings(owner_ids=frozenset({10, 11}))
    await service.database.upsert_chat(
        -1001,
        title="测试群",
        username=None,
        chat_type="supergroup",
        is_enabled=True,
    )
    service.spawn = lambda task: task.close()
    return service


@pytest.mark.parametrize(
    "actor,chat,kind", [(20, 20, "private"), (10, -1001, "supergroup"), (10, 11, "private")]
)
async def test_nonowner_or_group_cannot_access_panel(panel, actor, chat, kind):
    q = callback("oa:required:-1001:1", actor, chat, kind)
    await panel.admin.callback(q)
    assert not await panel.rules.username_required(-1001)
    panel.bot.edit_message_text.assert_not_awaited()


async def test_owner_home_and_customer_service_confirm_persist_and_clear(panel):
    cmd = private("/admin")
    await panel.admin.home(cmd)
    assert "主管理后台" in cmd.answer.await_args.args[0]
    await panel.admin.callback(callback("oa:support_input"))
    await panel.admin.private_message(private("@DTJT001"))
    assert await panel.rules.panel_setting("support_username") == ""
    token = panel.admin.pending[10]["token"]
    await panel.admin.callback(callback("oa:confirm:" + token))
    assert await panel.rules.panel_setting("support_username") == "DTJT001"
    buttons = await panel.admin.public_buttons(20)
    assert buttons.inline_keyboard[0][0].url == "https://t.me/DTJT001"
    await panel.rules.close()
    await panel.rules.initialize()
    assert await panel.rules.panel_setting("support_username") == "DTJT001"
    await panel.admin.callback(callback("oa:support_clear"))
    token = panel.admin.pending[10]["token"]
    await panel.admin.callback(callback("oa:confirm:" + token))
    assert await panel.admin.public_buttons(20) is None


@pytest.mark.parametrize(
    "text", ["https://evil.test", "@name with spaces", "name\n123", "sk-proj-test-key"]
)
async def test_invalid_customer_service_input_never_saves(panel, text):
    panel.admin.request_input(10, "support")
    await panel.admin.private_message(private(text))
    assert await panel.rules.panel_setting("support_username") == ""


async def test_confirmation_actor_bound_single_use_and_cancellable(panel):
    token = panel.admin.confirmation(10, "support", "DTJT001")
    await panel.admin.callback(callback("oa:confirm:" + token, actor=11))
    assert await panel.rules.panel_setting("support_username") == ""
    await panel.admin.callback(callback("oa:home"))
    await panel.admin.callback(callback("oa:confirm:" + token))
    assert await panel.rules.panel_setting("support_username") == ""


async def test_subscribers_deduplicate_track_username_changes_and_block_state(panel):
    handler = AsyncMock()
    msg = private("/start", actor=20)
    await panel.admin.track_private(handler, msg, {})
    msg.text = "hello"
    msg.from_user.username = "latestname"
    await panel.admin.track_private(handler, msg, {})
    total, users = await panel.rules.subscribers()
    assert total == 1 and users[0]["started"] == 1
    assert users[0]["username"] == "latestname"
    await panel.on_my_chat_member(
        SimpleNamespace(
            chat=SimpleNamespace(id=20, type="private"),
            new_chat_member=SimpleNamespace(status="kicked"),
        )
    )
    assert (await panel.rules.subscribers())[1][0]["blocked"] == 1
    await panel.admin.callback(callback("oa:users:0"))
    assert "20" in panel.bot.edit_message_text.await_args.args[0]
    assert "latestname" in panel.bot.edit_message_text.await_args.args[0]


async def test_group_messages_do_not_become_subscribers(panel):
    await panel.admin.track_private(AsyncMock(), message("hi", actor=20), {})
    assert (await panel.rules.subscribers())[0] == 0


async def test_require_username_toggle_is_separate_from_forbid_mentions(panel):
    assert not await panel.rules.username_required(-1001)
    assert await panel.rules.username_blocked(-1001)
    await panel.admin.callback(callback("oa:required:-1001:1"))
    assert await panel.rules.username_required(-1001)
    assert not await panel.rules.username_required(-1002)
    plain = message("大家好", actor=20)
    await panel.on_message(plain)
    panel.safe_delete.assert_awaited_once_with(plain)
    assert await panel.database.get_offender(20) is None
    panel.safe_delete.reset_mock()
    plain.from_user.username = "member20"
    await panel.on_message(plain)
    panel.safe_delete.assert_not_awaited()
    await panel.admin.callback(callback("oa:required:-1001:0"))
    plain.from_user.username = None
    await panel.on_message(plain)
    panel.safe_delete.assert_not_awaited()


async def test_type_toggle_affects_only_chosen_group_and_reenable_works(panel):
    text = "百家乐开户联系 @seller88"
    source = message(text, actor=20)
    sender = SenderContext(user_id=20)
    await panel.admin.callback(callback("oa:category:-1001:gambling:0"))
    assert not (await panel.classify_with_rules(source, text, sender)).is_ad
    other = message(text, actor=20, chat=-1002)
    assert (await panel.classify_with_rules(other, text, sender)).is_ad
    await panel.admin.callback(callback("oa:category:-1001:gambling:1"))
    assert (await panel.classify_with_rules(source, text, sender)).is_ad


async def test_ban_and_unban_need_confirmation_and_use_existing_registry(panel):
    await panel.admin.callback(callback("oa:input:ban"))
    await panel.admin.private_message(private("20 垃圾广告"))
    assert not await panel.database.is_globally_blocked(20)
    token = panel.admin.pending[10]["token"]
    await panel.admin.callback(callback("oa:confirm:" + token))
    assert await panel.database.is_globally_blocked(20)
    await panel.admin.callback(callback("oa:confirm:" + token))
    await panel.admin.callback(callback("oa:input:unban"))
    await panel.admin.private_message(private("20"))
    token = panel.admin.pending[10]["token"]
    await panel.admin.callback(callback("oa:confirm:" + token))
    assert not await panel.database.is_globally_blocked(20)


async def test_unknown_group_and_forged_confirmation_do_not_mutate(panel):
    await panel.admin.callback(callback("oa:required:-9999:1"))
    await panel.admin.callback(callback("oa:confirm:fake"))
    assert not await panel.rules.username_required(-9999)
    assert await panel.rules.panel_setting("support_username") == ""


async def test_ownerless_name_restriction_does_not_affect_admin(panel):
    await panel.rules.set_username_required(-1001, True)
    panel.safe_delete.reset_mock()
    await panel.on_message(message("大家好", actor=10))
    panel.safe_delete.assert_not_awaited()


async def test_group_settings_persist_after_restart(panel):
    await panel.rules.set_username_required(-1001, True)
    await panel.rules.set_category_policy(-1001, "gambling", False)
    await panel.rules.close()
    await panel.rules.initialize()
    assert await panel.rules.username_required(-1001)
    assert (await panel.rules.category_policies(-1001))["gambling"] is False
