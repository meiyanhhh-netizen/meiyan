"""Offline image acceptance; no credentials or Telegram/AI traffic required."""

import asyncio
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock

from aiogram.types import ChatPermissions, Message

from antispam_bot.ad_rules import AdRuleStore, message_has_username
from antispam_bot.bot import AntiSpamBot, configure_bot_commands
from antispam_bot.classifier import HybridAdClassifier
from antispam_bot.config import Settings
from antispam_bot.version import __version__


async def main() -> None:
    assert __version__ == "1.0.9"
    message = Message.model_validate(
        {
            "message_id": 1,
            "date": 0,
            "chat": {"id": -100123, "type": "supergroup", "title": "离线测试"},
            "from": {"id": 12345, "is_bot": False, "first_name": "测试"},
            "caption": "可玩可代 百家乐 AG BG PG电子 开户 联系 @seller88",
            "reply_markup": {
                "inline_keyboard": [
                    [
                        {"text": "开户联系", "url": "https://example.com/open"},
                        {"text": "发财频道", "url": "https://example.com/channel"},
                    ]
                ]
            },
        }
    )
    classifier = HybridAdClassifier()
    assert (await classifier.classify(AntiSpamBot.message_content(message))).is_ad
    assert (
        await classifier.classify("酒店偷拍资源、福利姬直播，点我搜索 https://example.com")
    ).is_ad
    assert not (await classifier.classify("Python 文档 https://docs.python.org/3/")).is_ad
    assert not (
        await classifier.classify("警方提醒不要点击酒店偷拍资源链接 https://example.com")
    ).is_ad
    assert not (await classifier.classify("百家乐开户联系 @seller88", sender_is_admin=True)).is_ad
    assert (
        await classifier.classify(
            "想多一份收入，支付宝口令红包玩法，手把手讲解操作流程，想了解详情欢迎咨询"
        )
    ).is_ad
    assert (
        await classifier.classify(
            "简单安全容易上手，没有任何弄虚作假，不用担心被跑路，过来了解看看具体 @example88"
        )
    ).is_ad
    card = Message.model_validate(
        {
            "message_id": 2,
            "date": 0,
            "chat": {"id": -100123, "type": "supergroup"},
            "from": {"id": 12345, "is_bot": False, "first_name": "测试"},
            "contact": {"first_name": "一天赚8k", "phone_number": "+12025550148"},
        }
    )
    assert (await classifier.classify(AntiSpamBot.message_content(card))).is_ad
    assert message_has_username(message)
    rich = Message.model_validate(
        {
            "message_id": 3,
            "date": 0,
            "chat": {"id": -100123, "type": "supergroup"},
            "rich_message": {
                "blocks": [
                    {
                        "type": "paragraph",
                        "text": {
                            "type": "bold",
                            "text": "单人一天能赚2843，想挣钱有执行力的来，过来了解具体 @QQHB93",
                        },
                    }
                ]
            },
        }
    )
    assert "2843" in AntiSpamBot.message_content(rich)
    assert (await classifier.classify(AntiSpamBot.message_content(rich))).is_ad
    assert message_has_username(rich)
    await configure_bot_commands(AsyncMock())
    with tempfile.TemporaryDirectory(prefix="antispam-rule-smoke-") as directory:
        rules = AdRuleStore(Path(directory) / "rules.db")
        await rules.initialize()
        try:
            service = AntiSpamBot(AsyncMock(), AsyncMock(), classifier, Settings(), rules=rules)
            assert "callback_query" in service.router.resolve_used_update_types()
            muted = ChatPermissions(**dict.fromkeys(ChatPermissions.model_fields, False))
            assert muted.can_send_messages is False
            pending = {"passed": False, "message_id": 0, "token": "offline-only"}
            await rules.save_verification(-100123, 123, pending)
            assert await rules.get_verification(-100456, 123) is None
            assert (-100123, 123, pending) in await rules.unfinished_verifications()
            rule_id, _ = await rules.add_rule(-100123, 10, kind="gambling")
            assert await rules.username_blocked(-100123)
            await rules.set_username_blocked(-100123, 10, False)
            assert not await rules.username_blocked(-100123)
            assert await rules.username_blocked(-100456)
            assert (await rules.match(-100123, "百家乐开户联系 @seller88")).id == rule_id
            assert await rules.match(-100456, "百家乐开户联系 @seller88") is None
            assert await rules.match(-100123, "Python 文档 https://docs.python.org") is None
            await rules.close()
            await rules.initialize()
            assert await rules.get_verification(-100123, 123) == pending
            assert not await rules.username_blocked(-100123)
            assert (await rules.match(-100123, "百家乐开户联系 @seller88")).id == rule_id
            await rules.remove_rule(-100123, rule_id)
            assert await rules.match(-100123, "百家乐开户联系 @seller88") is None
        finally:
            await rules.close()
    print("新镜像离线验收通过：广告规则、禁用户名、验证回调及待验证记录持久化。")


asyncio.run(main())
