#!/usr/bin/env python3
"""Scoped Docker upgrade: preserve settings, back up source/data, and roll back."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import tomllib
from datetime import UTC, datetime
from pathlib import Path

VERSION = "1.0.9"
REPLACEMENTS = (
    "src/antispam_bot/bot.py",
    "src/antispam_bot/classifier.py",
    "src/antispam_bot/version.py",
    "src/antispam_bot/ad_rules.py",
    "src/antispam_bot/content.py",
    "src/antispam_bot/admin.py",
)
RESTORE_FILES = (*REPLACEMENTS, "pyproject.toml")


def run(args: list[str], *, show: bool = False, **kwargs: object) -> str:
    if show:
        subprocess.run(args, check=True, **kwargs)
        return ""
    result = subprocess.run(args, check=True, capture_output=True, text=True, **kwargs)
    return result.stdout.strip()


def compose_args(target: Path, compose_file: str) -> list[str]:
    return [
        "docker",
        "compose",
        "--project-directory",
        str(target),
        "-f",
        str(target / compose_file),
    ]


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_target(raw: Path) -> tuple[Path, str]:
    target = raw.resolve(strict=True)
    if target in {Path("/"), Path("/root"), Path("/home"), Path("/tmp")}:
        raise ValueError("目标必须是具体的机器人项目目录")
    if not (target / ".env").is_file():
        raise ValueError("原项目 .env 不存在；不会创建或覆盖配置")
    project = target / "pyproject.toml"
    if project.is_symlink() or not project.is_file():
        raise ValueError("原项目 pyproject.toml 无法安全更新")
    config = tomllib.loads(project.read_text())
    if config.get("project", {}).get("name") != "datang-ai-antispam-bot":
        raise ValueError("目标不是独立删广告机器人，已停止")
    for relative in REPLACEMENTS:
        destination = target / relative
        if destination.is_symlink() or destination.parent.resolve() != target / "src/antispam_bot":
            raise ValueError("代码路径是符号链接，已停止")
    for module in ("config.py", "models.py", "db.py"):
        if not (target / "src/antispam_bot" / module).is_file():
            raise ValueError("原源码不完整，已停止")
    tree = ast.parse((target / "src/antispam_bot/db.py").read_text())
    database = next(
        (n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "Database"), None
    )
    methods = (
        {n.name for n in database.body if isinstance(n, ast.FunctionDef | ast.AsyncFunctionDef)}
        if database
        else set()
    )
    required = {
        "get_chat",
        "upsert_chat",
        "record_infraction",
        "get_stats",
        "log_audit",
        "is_globally_blocked",
    }
    if not required <= methods:
        raise ValueError("原数据库接口不兼容；请提供不含密钥的当前源码")
    for compose_file in (
        "compose.yaml",
        "compose.yml",
        "docker-compose.yml",
        "docker-compose.yaml",
    ):
        if (target / compose_file).is_file():
            return target, compose_file
    raise ValueError("原项目未找到 Compose 配置")


def validate_payload(package: Path) -> None:
    manifest = json.loads((package / "payload-manifest.json").read_text())
    if manifest["version"] != VERSION or set(manifest["files"]) != set(REPLACEMENTS):
        raise ValueError("升级包清单不完整")
    for relative, expected in manifest["files"].items():
        source = package / relative
        if source.is_symlink() or not source.is_file() or file_hash(source) != expected:
            raise ValueError(f"升级包校验失败：{relative}")


def patched_project(text: str) -> str:
    section = re.search(r"(?ms)^\[project\]\s*\n(.*?)(?=^\[|\Z)", text)
    if section is None:
        raise ValueError("原 pyproject.toml 缺少 project 段")
    block, count = re.subn(
        r"(?m)^(version\s*=\s*)[\x22\x27][^\x22\x27]*[\x22\x27]",
        lambda match: match[1] + f'"{VERSION}"',
        section[1],
        count=1,
    )
    if count != 1:
        raise ValueError("无法只修改版本号；原依赖保持不动")
    return text[: section.start(1)] + block + text[section.end(1) :]


def backup_source(target: Path, backup: Path) -> dict[str, bool]:
    present = {}
    for relative in (*RESTORE_FILES, ".env"):
        source = target / relative
        present[relative] = source.is_file()
        if source.is_file():
            destination = backup / "source" / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
    return present


def restore_source(target: Path, backup: Path, present: dict[str, bool]) -> None:
    # Do not restore .env or the database: newer settings/infractions must survive.
    for relative in RESTORE_FILES:
        destination = target / relative
        if destination.is_symlink() or destination.parent.resolve() != (target / relative).parent:
            raise ValueError("回退目标出现符号链接，已停止")
        if destination.exists():
            saved = backup / "failed-source" / relative
            saved.parent.mkdir(parents=True, exist_ok=True)
            if present[relative]:
                if not saved.exists():
                    shutil.copy2(destination, saved)
            else:
                saved = saved.with_name(saved.name + "." + str(time.time_ns()))
                shutil.move(str(destination), str(saved))
        if present[relative]:
            shutil.copy2(backup / "source" / relative, destination)


def rollback(backup: Path) -> None:
    metadata = json.loads((backup / "rollback.json").read_text())
    target, compose_file = validate_target(Path(metadata["target"]))
    service = metadata["service"]
    if service not in {"anti-ad-bot", "bot"}:
        raise ValueError("回退服务名称不在允许列表")
    if not re.fullmatch(r"sha256:[a-f0-9]{64}", metadata["old_image"]):
        raise ValueError("旧镜像标识无效")
    if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_./:-]*", metadata["old_image_ref"]):
        raise ValueError("旧镜像标签无效")
    present = metadata["present"]
    if set(present) != {*RESTORE_FILES, ".env"}:
        raise ValueError("回退文件清单无效")
    commands = compose_args(target, compose_file)
    current = run([*commands, "ps", "-a", "-q", service]).splitlines()
    for container in current:
        image = run(["docker", "inspect", "--format", "{{.Image}}", container])
        if image != metadata["old_image"]:
            run([*commands, "stop", "--timeout", "15", service], show=True)
            break
    restore_source(target, backup, present)
    run(["docker", "tag", metadata["old_image"], metadata["old_image_ref"]])
    if metadata["was_running"]:
        run([*commands, "up", "-d", "--no-deps", "--no-build", service], show=True)
    else:
        run([*commands, "stop", "--timeout", "15", service], show=True)
    print("已回退代码和镜像；当前 .env、数据库及其他机器人未改动。", flush=True)


def upgrade(package: Path, raw_target: Path) -> None:
    target, compose_file = validate_target(raw_target)
    if target == package.resolve():
        raise ValueError("请在独立的升级包目录运行；不能把升级包覆盖到原目录")
    validate_payload(package)
    run(["docker", "compose", "version"])
    run(["docker", "info", "--format", "{{.ServerVersion}}"])
    commands = compose_args(target, compose_file)
    services = run([*commands, "config", "--services"]).splitlines()
    candidates = [s for s in services if s in {"anti-ad-bot", "bot"}]
    if len(candidates) != 1:
        raise ValueError("无法唯一识别删广告服务；不会操作其他服务")
    service = candidates[0]
    containers = run([*commands, "ps", "-a", "-q", service]).splitlines()
    if len(containers) != 1:
        raise ValueError("未找到唯一的旧容器；请先确认部署目录")
    old_container = containers[0]
    old_image = run(["docker", "inspect", "--format", "{{.Image}}", old_container])
    old_image_ref = run(["docker", "inspect", "--format", "{{.Config.Image}}", old_container])
    was_running = (
        run(["docker", "inspect", "--format", "{{.State.Running}}", old_container]) == "true"
    )
    if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_./:-]*", old_image_ref):
        raise ValueError("当前镜像不是可回退的构建标签，已停止")
    mounts = json.loads(run(["docker", "inspect", "--format", "{{json .Mounts}}", old_container]))
    if not any(m.get("Destination") == "/app/data" for m in mounts):
        raise ValueError("旧数据库挂载不是 /app/data；不会自动更改数据布局")
    original_project = (target / "pyproject.toml").read_text()
    new_project = patched_project(original_project)
    backup_parent = target.parent / "datang-antispam-backups"
    backup_parent.mkdir(mode=0o700, exist_ok=True)
    prefix = f"v{VERSION}-" + datetime.now(UTC).strftime("%Y%m%d-%H%M%S") + "-"
    backup = Path(tempfile.mkdtemp(prefix=prefix, dir=backup_parent))
    present = backup_source(target, backup)
    metadata = {
        "target": str(target),
        "service": service,
        "old_image": old_image,
        "old_image_ref": old_image_ref,
        "was_running": was_running,
        "env_hash": file_hash(target / ".env"),
        "present": present,
    }
    (backup / "rollback.json").write_text(json.dumps(metadata, indent=2))
    run(["docker", "tag", old_image, "datang-antispam-rollback:" + backup.name])
    print(f"已备份旧代码和配置：{backup}", flush=True)
    applied = False
    try:
        applied = True
        for relative in REPLACEMENTS:
            shutil.copy2(package / relative, target / relative)
        (target / "pyproject.toml").write_text(new_project)
        print("构建新镜像；旧容器此时继续运行。", flush=True)
        run([*commands, "build", service], show=True)
        smoke = (package / "scripts/smoke_upgrade.py").read_bytes()
        subprocess.run(
            [
                "docker",
                "run",
                "--rm",
                "-i",
                "--network",
                "none",
                "--read-only",
                "--tmpfs",
                "/tmp:rw,size=32m",
                "--entrypoint",
                "python",
                old_image_ref,
                "-",
            ],
            input=smoke,
            check=True,
        )
        if metadata["env_hash"] != file_hash(target / ".env"):
            raise ValueError("检测到配置同时被修改；停止升级，不覆盖配置")
        print("离线验收通过，短暂停止本服务以备份数据库。", flush=True)
        run([*commands, "stop", "--timeout", "20", service], show=True)
        snapshot_code = (
            "import sys,tarfile; "
            "archive=tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz'); "
            "archive.add('/app/data',arcname='data'); archive.close()"
        )
        with (backup / "data.tar.gz").open("wb") as output:
            subprocess.run(
                [
                    "docker",
                    "run",
                    "--rm",
                    "--network",
                    "none",
                    "--volumes-from",
                    old_container + ":ro",
                    "--entrypoint",
                    "python",
                    old_image,
                    "-c",
                    snapshot_code,
                ],
                stdout=output,
                check=True,
            )
        run([*commands, "up", "-d", "--no-deps", "--no-build", service], show=True)
        ready = False
        for _ in range(15):
            current = run([*commands, "ps", "-a", "-q", service]).splitlines()
            if len(current) != 1:
                raise RuntimeError("新容器没有正常建立")
            container = current[0]
            state = run(["docker", "inspect", "--format", "{{.State.Running}}", container])
            restarts = int(run(["docker", "inspect", "--format", "{{.RestartCount}}", container]))
            if state != "true" or restarts > 0:
                raise RuntimeError("新容器退出或反复重启")
            result = subprocess.run(
                ["docker", "logs", "--tail", "120", container],
                capture_output=True,
                text=True,
                check=True,
            )
            if "Run polling for bot" in result.stdout + result.stderr:
                ready = True
                break
            time.sleep(1)
        installed = run(
            [
                "docker",
                "exec",
                container,
                "python",
                "-c",
                "from antispam_bot.version import __version__; print(__version__)",
            ]
        )
        if installed != VERSION:
            raise RuntimeError("运行中的容器仍是旧版本")
        print(f"已安装规则版本 {VERSION}，原 Token、AI 配置和数据卷保持不变。", flush=True)
        if ready:
            print("Telegram 轮询已连接；请在群内 /status 并用普通成员测试。", flush=True)
        else:
            print("容器运行中，但尚未确认 Telegram 连接；请检查 /status 或运行日志。", flush=True)
        print(f"需要回退时：python3 {package / 'scripts/upgrade_server.py'} --rollback {backup}")
    except (Exception, KeyboardInterrupt):
        if applied:
            print("更新未完成，正在尝试自动回退。", flush=True)
            try:
                rollback(backup)
            except Exception as error:
                print(
                    f"自动回退失败（{type(error).__name__}）；备份保留在 {backup}。",
                    file=sys.stderr,
                )
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description="独立删广告机器人安全更新工具")
    parser.add_argument("--target", type=Path, default=Path("/root/datang_ai_antispam_bot"))
    parser.add_argument("--rollback", type=Path)
    args = parser.parse_args()
    import os

    os.umask(0o077)

    def interrupted(_signum: int, _frame: object) -> None:
        raise KeyboardInterrupt

    # A dropped SSH session should take the same recovery path as Ctrl-C.
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGHUP, interrupted)
    try:
        if args.rollback is not None:
            rollback(args.rollback.resolve(strict=True))
        else:
            upgrade(Path(__file__).resolve().parent.parent, args.target)
    except (Exception, KeyboardInterrupt) as error:
        # Compose errors may contain interpolated config. Do not echo their raw
        # stdout/stderr or any secret-bearing env values.
        if isinstance(error, ValueError | RuntimeError | FileNotFoundError):
            print(f"未完成：{error}", file=sys.stderr)
        else:
            print(f"未完成：{type(error).__name__}。请保留终端结果用于排查。", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
