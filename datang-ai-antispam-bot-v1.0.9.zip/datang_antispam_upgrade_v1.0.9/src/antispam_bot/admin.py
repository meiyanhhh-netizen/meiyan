"""Private, owner-only Telegram control panel. No web server or credentials."""

from __future__ import annotations

import asyncio
import re
import secrets
import time

from aiogram.enums import ChatType
from aiogram.exceptions import TelegramAPIError
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from .ad_rules import CATEGORY_NAMES


def clean_label(value: str, limit: int = 64) -> str:
    return " ".join(value.split())[:limit]


def keyboard(rows: list[list[tuple[str, str]]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=label, callback_data=data) for label, data in row]
            for row in rows
        ]
    )


class OwnerPanel:
    def __init__(self, service) -> None:
        self.service = service
        self.pending: dict[int, dict] = {}
        self._lock = asyncio.Lock()

    async def track_private(self, handler, event: Message, data: dict):
        user = event.from_user
        if event.chat.type == ChatType.PRIVATE and user is not None and not user.is_bot:
            command = (event.text or "").split(maxsplit=1)[0:1]
            started = bool(command and command[0].split("@")[0] == "/start")
            await self.service.rules.remember_subscriber(
                user.id,
                user.username or "",
                user.full_name,
                started=started,
            )
        return await handler(event, data)

    async def public_buttons(self, user_id: int | None) -> InlineKeyboardMarkup | None:
        rows = []
        username = await self.service.rules.panel_setting("support_username")
        if username and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{2,31}", username):
            rows.append([InlineKeyboardButton(text="联系客服", url="https://t.me/" + username)])
        if await self.service.is_owner(user_id):
            rows.append([InlineKeyboardButton(text="主管理后台", callback_data="oa:home")])
        return InlineKeyboardMarkup(inline_keyboard=rows) if rows else None

    async def support(self, message: Message) -> None:
        await message.answer(
            "点击下方按钮联系客服。"
            if await self.service.rules.panel_setting("support_username")
            else "暂未设置客服，请联系群管理员。",
            reply_markup=await self.public_buttons(
                message.from_user.id if message.from_user else None
            ),
        )

    async def home(self, message: Message) -> None:
        if message.chat.type != ChatType.PRIVATE:
            await message.answer("请私聊机器人发送 /admin 打开主管理后台。")
            return
        if not await self.service.owner_only(message):
            return
        self.pending.pop(message.from_user.id, None)
        await message.answer("主管理后台\n请选择管理项目。", reply_markup=self.home_keys())

    @staticmethod
    def home_keys() -> InlineKeyboardMarkup:
        return keyboard(
            [
                [("启动／私聊用户", "oa:users:0"), ("群设置／广告类型", "oa:groups:0")],
                [("封禁用户", "oa:input:ban"), ("解封用户", "oa:input:unban")],
                [("全局封禁名单", "oa:bans:0"), ("客服设置", "oa:support")],
            ]
        )

    async def render(self, query: CallbackQuery, text: str, rows: list) -> None:
        try:
            await self.service.bot.edit_message_text(
                text,
                chat_id=query.message.chat.id,
                message_id=query.message.message_id,
                reply_markup=keyboard(rows),
            )
        except TelegramAPIError:
            # A deleted/unchanged old panel must not abort a saved setting.
            await self.service.bot.send_message(
                query.from_user.id,
                text,
                reply_markup=keyboard(rows),
            )

    def request_input(self, actor: int, kind: str) -> None:
        self.pending[actor] = {"kind": kind, "expires": time.monotonic() + 600}

    def confirmation(self, actor: int, kind: str, value: object) -> str:
        token = secrets.token_hex(8)
        self.pending[actor] = {
            "kind": "confirm",
            "action": kind,
            "value": value,
            "token": token,
            "expires": time.monotonic() + 600,
        }
        return token

    async def private_message(self, message: Message) -> None:
        user = message.from_user
        if user is None:
            return
        owner = await self.service.is_owner(user.id)
        if not owner:
            if await self.service.database.is_globally_blocked(user.id):
                await message.answer("账号已被主管理封禁，请通过 /support 联系客服申诉。")
            else:
                await message.answer(
                    "请使用 /start 查看机器人说明，或 /support 联系客服。",
                    reply_markup=await self.public_buttons(user.id),
                )
            return
        if message.text == "/cancel":
            self.pending.pop(user.id, None)
            await self.home(message)
            return
        async with self._lock:
            state = self.pending.get(user.id)
            if not state or state["expires"] < time.monotonic():
                self.pending.pop(user.id, None)
                await self.home(message)
                return
            raw = (message.text or "").strip()
            if state["kind"] == "confirm" or raw.startswith("/"):
                await message.answer("请点击确认按钮，或发送 /cancel 返回后台。")
                return
            if state["kind"] == "support":
                value = raw.removeprefix("@")
                if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{2,31}", value):
                    await message.answer(
                        "请输入客服用户名，例如 @DTJT001；不要输入网址、空格或密码。"
                    )
                    return
                token = self.confirmation(user.id, "support", value)
                text = f"确认将客服设置为 @{value}？\n保存后首页将显示该账号的联系按钮。"
            else:
                parts = raw.split(maxsplit=1)
                if not parts or not parts[0].isdigit() or not 0 < int(parts[0]) < 2**52:
                    await message.answer("请输入数字用户 ID，可在后面附原因；不是 @用户名。")
                    return
                target = int(parts[0])
                if (
                    target in self.service.settings.owner_ids
                    or target == await self.service.get_bot_id()
                ):
                    await message.answer("不能对主管理或本机器人执行此操作。")
                    return
                reason = parts[1][:256] if len(parts) > 1 else "主管理后台操作"
                token = self.confirmation(user.id, state["kind"], {"id": target, "reason": reason})
                text = (
                    f"确认全局封禁用户 {target}？\n原因：{clean_label(reason, 256)}\n"
                    "将加入全局预封，并向受保护群执行封禁；群管理员不自动封禁。"
                    if state["kind"] == "ban"
                    else f"确认解除用户 {target} 的全局预封并清零违规次数？\n"
                    "只撤销本机器人执行的封禁，不解除其他管理员手动封禁或禁言。"
                )
            await message.answer(
                text,
                reply_markup=keyboard(
                    [
                        [("确认保存／执行", f"oa:confirm:{token}")],
                        [("取消／返回", "oa:home")],
                    ]
                ),
            )

    async def callback(self, query: CallbackQuery) -> None:
        if (
            not isinstance(query.message, Message)
            or query.message.chat.type != ChatType.PRIVATE
            or query.message.chat.id != query.from_user.id
            or not await self.service.is_owner(query.from_user.id)
        ):
            await query.answer("仅主管理可在私聊操作。", show_alert=True)
            return
        await query.answer()
        parts = (query.data or "").split(":")
        action = parts[1] if len(parts) > 1 else ""
        actor = query.from_user.id
        async with self._lock:
            try:
                await self.dispatch(query, parts, action, actor)
            except (ValueError, IndexError):
                await self.render(query, "参数无效或页面已过期。", [[("返回后台", "oa:home")]])

    async def dispatch(self, query, parts, action, actor) -> None:
        service = self.service
        back = [[("返回后台", "oa:home")]]
        if action == "home":
            self.pending.pop(actor, None)
            await self.render(
                query,
                "主管理后台\n请选择管理项目。",
                [
                    [(b.text, b.callback_data) for b in row]
                    for row in self.home_keys().inline_keyboard
                ],
            )
        elif action == "users":
            page = max(0, min(int(parts[2]), 1_000_000))
            total, users = await service.rules.subscribers(page)
            text = [
                f"启动／私聊用户：{total} 人（第 {page + 1} 页）",
                "仅记录升级后私聊互动的用户，非频道订阅者或浏览者名单。",
            ]
            for user in users:
                username = "@" + user["username"] if user["username"] else "无用户名"
                text.append(
                    f"\n{user['user_id']} · {clean_label(user['display_name'], 40)} · {username}\n"
                    f"首次 {user['first_seen'][:10]} · 最近 {user['last_seen'][:10]}"
                    + (" · 已屏蔽机器人（最近观测）" if user["blocked"] else "")
                )
            nav = []
            if page:
                nav.append(("上一页", f"oa:users:{page - 1}"))
            if (page + 1) * 10 < total:
                nav.append(("下一页", f"oa:users:{page + 1}"))
            await self.render(query, "\n".join(text), ([nav] if nav else []) + back)
        elif action == "groups":
            page = max(0, min(int(parts[2]), 1_000_000))
            groups = await service.database.list_chats(enabled_only=False)
            rows = [
                [(clean_label(g.title or str(g.chat_id), 30), f"oa:group:{g.chat_id}")]
                for g in groups[page * 8 : (page + 1) * 8]
            ]
            nav = []
            if page:
                nav.append(("上一页", f"oa:groups:{page - 1}"))
            if (page + 1) * 8 < len(groups):
                nav.append(("下一页", f"oa:groups:{page + 1}"))
            await self.render(
                query, "选择要设置的群（只修改该群）：", rows + ([nav] if nav else []) + back
            )
        elif action in {"group", "required", "category"}:
            chat_id = int(parts[2])
            chat = await service.database.get_chat(chat_id)
            if chat is None:
                raise ValueError("Unknown group")
            if action == "required":
                if parts[3] not in {"0", "1"}:
                    raise ValueError("Invalid state")
                await service.rules.set_username_required(chat_id, parts[3] == "1")
                await service.database.log_audit(
                    "username_required_changed",
                    actor_user_id=actor,
                    chat_id=chat_id,
                    details={"enabled": parts[3] == "1"},
                )
            elif action == "category":
                if parts[3] not in CATEGORY_NAMES or parts[4] not in {"0", "1"}:
                    raise ValueError("Invalid category")
                kind, enabled = parts[3], parts[4] == "1"
                if enabled:
                    await service.rules.add_rule(chat_id, actor, kind=kind, force=True)
                else:
                    for rule in await service.rules.list_rules(chat_id):
                        if rule.kind == kind:
                            await service.rules.remove_rule(chat_id, rule.id)
                await service.rules.set_category_policy(chat_id, kind, enabled)
                await service.database.log_audit(
                    "owner_category_policy",
                    actor_user_id=actor,
                    chat_id=chat_id,
                    details={"kind": kind, "enabled": enabled},
                )
            required = await service.rules.username_required(chat_id)
            policies = await service.rules.category_policies(chat_id)
            rows = [
                [
                    (
                        f"无用户名禁发：{'开' if required else '关'}",
                        f"oa:required:{chat_id}:{int(not required)}",
                    )
                ]
            ]
            for kind, name in CATEGORY_NAMES.items():
                enabled = policies.get(kind, True)
                rows.append(
                    [
                        (
                            f"{'✅' if enabled else '❌'} {name}",
                            f"oa:category:{chat_id}:{kind}:{int(not enabled)}",
                        )
                    ]
                )
            await self.render(
                query,
                f"群设置：{clean_label(chat.title)}\n群 ID：{chat_id}\n"
                f"保护状态：{'启用' if chat.is_enabled else '暂停／权限不足'}\n"
                "无用户名禁发开启时，删除普通成员无用户名账号的发言；设置用户名后即可正常发言。"
                "不记广告次数，不自动封禁；管理员免此限制。\n"
                "广告类型关闭仅跳过明确识别为该类型的广告，未分类 AI 广告仍审核。"
                "混合广告只要含其他开启类型仍处理；禁发 @用户名等独立群规仍生效。",
                rows + [[("返回群列表", "oa:groups:0")]] + back,
            )
        elif action == "input" and parts[2] in {"ban", "unban"}:
            self.request_input(actor, parts[2])
            await self.render(query, "请输入目标数字用户 ID，可附原因。\n收到后会再次确认。", back)
        elif action == "support":
            username = await service.rules.panel_setting("support_username")
            await self.render(
                query,
                "客服设置\n当前：" + ("@" + username if username else "未设置"),
                [
                    [
                        ("输入／修改客服用户名", "oa:support_input"),
                        ("清除客服", "oa:support_clear"),
                    ],
                ]
                + back,
            )
        elif action == "support_input":
            self.request_input(actor, "support")
            await self.render(
                query, "请发送客服用户名，例如 @DTJT001（也可不带 @）。\n发送 /cancel 取消。", back
            )
        elif action == "support_clear":
            token = self.confirmation(actor, "support", "")
            await self.render(
                query,
                "确认清除客服设置并隐藏首页联系按钮？",
                [
                    [("确认清除", f"oa:confirm:{token}")],
                ]
                + back,
            )
        elif action == "confirm":
            state = self.pending.get(actor)
            if (
                not state
                or state["kind"] != "confirm"
                or state["token"] != parts[2]
                or state["expires"] < time.monotonic()
            ):
                raise ValueError("Expired confirmation")
            self.pending.pop(actor, None)
            if state["action"] == "support":
                await service.rules.set_panel_setting("support_username", state["value"])
                await service.database.log_audit(
                    "support_username_changed",
                    actor_user_id=actor,
                    details={"username": state["value"]},
                )
                text = "客服已保存为 @" + state["value"] if state["value"] else "客服设置已清除。"
            elif state["action"] == "ban":
                text = await service.owner_ban_user(
                    state["value"]["id"], actor, state["value"]["reason"]
                )
            else:
                text = await service.owner_unban_user(state["value"]["id"], actor)
            await self.render(query, text, back)
        elif action == "bans":
            page = max(0, min(int(parts[2]), 1_000_000))
            users = await service.database.list_global_offenders(limit=11, offset=page * 10)
            lines = ["全局封禁名单（不是仅一次违规的入群预封名单）："]
            for user in users[:10]:
                lines.append(f"{user.user_id} · {clean_label(user.display_name or '', 40)}")
            nav = []
            if page:
                nav.append(("上一页", f"oa:bans:{page - 1}"))
            if len(users) > 10:
                nav.append(("下一页", f"oa:bans:{page + 1}"))
            await self.render(
                query,
                "\n".join(lines),
                ([nav] if nav else [])
                + [
                    [("输入 ID 解封", "oa:input:unban")],
                ]
                + back,
            )
        else:
            raise ValueError("Unknown action")
