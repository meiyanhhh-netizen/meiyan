"""Telegram transport and moderation policy for the anti-ad bot."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import secrets
import time
from dataclasses import replace
from datetime import UTC, datetime, timedelta
from typing import Final

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ChatMemberStatus, ChatType
from aiogram.exceptions import (
    TelegramAPIError,
    TelegramBadRequest,
    TelegramForbiddenError,
    TelegramRetryAfter,
)
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    BotCommand,
    BotCommandScopeAllChatAdministrators,
    CallbackQuery,
    ChatAdministratorRights,
    ChatJoinRequest,
    ChatMemberAdministrator,
    ChatMemberOwner,
    ChatMemberUpdated,
    ChatPermissions,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from dotenv import load_dotenv

from .ad_rules import (
    CATEGORY_NAMES,
    AdRuleStore,
    canonical_sample,
    category_key,
    matching_categories,
    media_key,
    message_has_username,
    rule_verdict,
    sample_kind,
)
from .admin import OwnerPanel
from .classifier import HybridAdClassifier
from .config import Settings
from .content import rich_content
from .db import Database
from .models import ClassificationVerdict, SenderContext, VerdictLabel
from .version import __version__

LOGGER = logging.getLogger(__name__)

GROUP_TYPES: Final = {ChatType.GROUP, ChatType.SUPERGROUP}
ADMIN_STATUSES: Final = {
    ChatMemberStatus.CREATOR,
    ChatMemberStatus.ADMINISTRATOR,
}
PRESENT_STATUSES: Final = {
    ChatMemberStatus.MEMBER,
    ChatMemberStatus.ADMINISTRATOR,
    ChatMemberStatus.CREATOR,
    ChatMemberStatus.RESTRICTED,
}
ABSENT_STATUSES: Final = {ChatMemberStatus.LEFT, ChatMemberStatus.KICKED}


class AntiSpamBot:
    """Connect Telegram updates to classification, persistence and enforcement."""

    def __init__(
        self,
        bot: Bot,
        database: Database,
        classifier: HybridAdClassifier,
        settings: Settings,
        *,
        rules: AdRuleStore | None = None,
    ) -> None:
        self.bot = bot
        self.database = database
        self.classifier = classifier
        self.settings = settings
        self.rules = (
            rules
            if rules is not None
            else AdRuleStore(
                settings.database.path.with_name(settings.database.path.name + ".rules.db")
            )
        )
        self.router = Router(name="datang-ai-antispam")
        self._bot_id: int | None = None
        self._admin_cache: dict[tuple[int, int], tuple[float, bool]] = {}
        self._background_tasks: set[asyncio.Task[object]] = set()
        self._verification_lock = asyncio.Lock()
        self.admin = OwnerPanel(self)
        self._register_handlers()

    def _register_handlers(self) -> None:
        self.router.message.outer_middleware(self.admin.track_private)
        self.router.message.register(self.admin.home, Command("admin"))
        self.router.message.register(self.admin.support, Command("support"))
        self.router.callback_query.register(self.admin.callback, F.data.startswith("oa:"))
        self.router.message.register(self.on_start, CommandStart())
        self.router.message.register(self.on_status, Command("status"))
        self.router.message.register(self.on_adcheck, Command("adcheck"))
        self.router.message.register(self.on_adlearn, Command("adlearn"))
        self.router.message.register(self.on_addelete, Command("addelete"))
        self.router.message.register(self.on_adtype, Command("adtype"))
        self.router.message.register(self.on_adrules, Command("adrules"))
        self.router.message.register(self.on_adforget, Command("adforget"))
        self.router.message.register(self.on_nousername, Command("nousername"))
        self.router.message.register(self.on_verify, Command("verify"))
        self.router.callback_query.register(self.on_verify_answer, F.data.startswith("jv:"))
        self.router.message.register(self.on_check, Command("check"))
        self.router.message.register(self.on_manual_ban, Command("ban"))
        self.router.message.register(self.on_manual_unban, Command("unban"))
        self.router.chat_join_request.register(self.on_join_request)
        self.router.my_chat_member.register(self.on_my_chat_member)
        self.router.chat_member.register(self.on_chat_member)
        self.router.message.register(
            self.on_service_message,
            F.new_chat_members | F.left_chat_member,
        )
        self.router.message.register(self.admin.private_message, F.chat.type == ChatType.PRIVATE)
        self.router.message.register(self.on_message)
        self.router.edited_message.register(self.on_message)

    async def get_bot_id(self) -> int:
        if self._bot_id is None:
            self._bot_id = (await self.bot.get_me()).id
        return self._bot_id

    def spawn(self, coroutine: object) -> None:
        task = asyncio.create_task(coroutine)  # type: ignore[arg-type]
        self._background_tasks.add(task)
        task.add_done_callback(self._background_task_done)

    def _background_task_done(self, task: asyncio.Task[object]) -> None:
        self._background_tasks.discard(task)
        if task.cancelled():
            return
        error = task.exception()
        if error is not None:
            LOGGER.error(
                "Background moderation task failed",
                exc_info=(type(error), error, error.__traceback__),
            )

    async def shutdown(self) -> None:
        if not self._background_tasks:
            return
        done, pending = await asyncio.wait(self._background_tasks, timeout=8)
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        for task in done:
            with contextlib.suppress(asyncio.CancelledError, Exception):
                task.result()

    async def is_owner(self, user_id: int | None) -> bool:
        return user_id is not None and user_id in self.settings.owner_ids

    async def is_admin(self, chat_id: int, user_id: int) -> bool:
        """Fail closed for destructive actions: lookup failures are exempt."""

        if await self.is_owner(user_id):
            return True
        loop = asyncio.get_running_loop()
        cache_key = (chat_id, user_id)
        cached = self._admin_cache.get(cache_key)
        if cached and cached[0] > loop.time():
            return cached[1]
        try:
            member = await self.bot.get_chat_member(chat_id, user_id)
            result = member.status in ADMIN_STATUSES
        except TelegramAPIError:
            LOGGER.warning(
                "Could not verify administrator status in chat %s; exempting user",
                chat_id,
            )
            result = True
        self._admin_cache[cache_key] = (loop.time() + 45, result)
        return result

    async def can_manage(self, message: Message) -> bool:
        user = message.from_user
        if user is None:
            return False
        if await self.is_owner(user.id):
            return True
        if message.chat.type in GROUP_TYPES:
            # Moderation treats a failed lookup as exempt; that must NOT grant
            # command privileges to an unverified sender.
            try:
                member = await self.bot.get_chat_member(message.chat.id, user.id)
                return member.status in ADMIN_STATUSES
            except TelegramAPIError:
                return False
        return False

    async def owner_only(self, message: Message) -> bool:
        user_id = message.from_user.id if message.from_user else None
        if await self.is_owner(user_id):
            return True
        await message.answer("此命令仅限机器人主管理员使用。")
        return False

    @staticmethod
    def _command_target(message: Message) -> tuple[int | None, str]:
        text = message.text or ""
        parts = text.split(maxsplit=2)
        raw_target = parts[1] if len(parts) >= 2 else ""
        reason = parts[2].strip() if len(parts) >= 3 else ""
        if raw_target.isdigit() and int(raw_target) > 0:
            return int(raw_target), reason
        reply_user = message.reply_to_message.from_user if message.reply_to_message else None
        if reply_user is not None:
            reason = " ".join(parts[1:]).strip()
            return reply_user.id, reason
        return None, reason

    async def on_start(self, message: Message) -> None:
        if message.chat.type in GROUP_TYPES:
            await self.on_message(message)
            return
        user_id = message.from_user.id if message.from_user else None
        self.admin.pending.pop(user_id, None)
        if user_id is not None and not await self.is_owner(user_id):
            if await self.database.is_globally_blocked(user_id):
                await message.answer("账号已被主管理封禁，请通过 /support 联系客服申诉。")
                return
        await message.answer(
            "大唐 AI 删广告机器人已运行。\n\n"
            "把我加入群并授予：删除消息、封禁用户、邀请用户权限，"
            "即可自动启用，无需群内配置。"
            "\n管理员可回复广告发送 /adlearn，设置本群持续删除同类广告。"
            "\n客服入口：/support；主管理后台：/admin。"
            "\n私聊会记录数字 ID、昵称、用户名及互动时间，用于机器人用户管理。",
            reply_markup=await self.admin.public_buttons(user_id),
        )

    async def on_status(self, message: Message) -> None:
        if await self.on_message(message):
            return
        if not await self.can_manage(message):
            await message.answer("仅群管理员或机器人主管理员可以查看状态。")
            return
        user_id = message.from_user.id if message.from_user else None
        lines = [
            "✅ 反广告机器人运行正常",
            f"规则版本：{__version__}",
            f"AI语义判断：{'已启用' if self.settings.classifier.ai_enabled else '本地规则模式'}",
            f"删除阈值：{self.settings.classifier.ad_threshold:.2f}",
            "操作身份："
            + ("主管理（可强制学习/删除）" if await self.is_owner(user_id) else "群管理员"),
        ]
        if await self.is_owner(user_id):
            stats = await self.database.get_stats()
            lines.extend(
                [
                    f"已接入群：{stats['active_chats']}",
                    f"已记录账号：{stats['offenders']}",
                    f"广告违规：{stats['infractions']}",
                    f"永久全局封禁：{stats['global_blocked']}",
                ]
            )
        if message.chat.type in GROUP_TYPES:
            missing = await self.missing_bot_permissions(message.chat.id)
            lines.append("本群权限：" + ("完整" if not missing else "缺少" + "、".join(missing)))
            record = await self.database.get_chat(message.chat.id)
            active = record is not None and record.is_enabled
            lines.append("本群保护：" + ("已启用" if active else "暂停或未登记"))
            lines.append("入群验证：加法按钮验证；未通过保持禁言（超级群）")
            required = await self.rules.username_required(message.chat.id)
            lines.append("无用户名账号禁发：" + ("开启" if required else "关闭"))
            rules = await self.rules.list_rules(message.chat.id)
            lines.append(f"本群教学规则：{len(rules)} 条（/adrules 查看）")
            username_blocked = await self.rules.username_blocked(message.chat.id)
            lines.append("本群禁发用户名：" + ("开启" if username_blocked else "关闭"))
        await message.answer("\n".join(lines))

    async def _rule_manager(self, message: Message) -> bool:
        if await self.on_message(message):
            return False
        if message.chat.type not in GROUP_TYPES or not await self.can_manage(message):
            await message.answer("仅本群管理员或机器人主管理员可以设置广告规则；请使用本人身份。")
            return False
        return True

    async def _activate_for_rule(self, message: Message) -> bool:
        missing = await self.missing_bot_permissions(message.chat.id)
        if missing:
            await message.answer("请先补齐机器人权限：" + "、".join(missing))
            return False
        await self.database.upsert_chat(
            message.chat.id,
            title=message.chat.title or "",
            username=message.chat.username,
            chat_type=message.chat.type,
            is_enabled=True,
        )
        return True

    async def on_adlearn(self, message: Message) -> None:
        """An explicit admin action teaches a local policy, never model weights."""

        if not await self._rule_manager(message):
            return
        owner = await self.is_owner(message.from_user.id if message.from_user else None)
        target = message.reply_to_message
        args = (message.text or "").split(maxsplit=2)
        manual = len(args) > 1 and args[1] in {"文本", "text"}
        if target is not None and target.chat.id != message.chat.id:
            await message.answer("请在当前群回复广告。")
            return
        if target is None and not manual:
            await message.answer(
                "请回复广告发送 /adlearn；支持博彩、色情、兼职、营销、红包、赚钱 或 相似。"
                "\n也可发送 /adlearn 文本 后接完整广告文案。"
            )
            return
        choice = "相似" if manual else " ".join(args[1:]).strip()
        if manual:
            content = args[2].strip() if len(args) > 2 else ""
            if not content:
                await message.answer(
                    "用法：/adlearn 文本 后接完整广告文案；也可以先回复广告再发此命令。"
                )
                return
            content = content[: self.settings.classifier.max_content_chars]
        else:
            content = self.message_content(
                target, max_chars=self.settings.classifier.max_content_chars
            )
        if choice in {"相似", "样本", "sample"}:
            kind = "sample"
        elif choice:
            kind = category_key(choice)
            if kind is None:
                if owner:
                    kind = "sample"
                else:
                    await message.answer(
                        "支持：博彩、色情、兼职、营销、红包、赚钱、相似。例：/adlearn 相似"
                    )
                    return
            if kind not in matching_categories(content):
                if owner:
                    kind = "sample"
                else:
                    await message.answer(
                        "这条样本未包含所选类型的完整导流特征。"
                        "可用 /adlearn 相似 学习文案或相同媒体；"
                        "也可用 /adtype 类型 开 直接启用该类型。"
                    )
                    return
        else:
            categories = matching_categories(content)
            kind = categories[0] if categories else "sample"
        media = media_key(target)
        message_only = False
        if owner and not content.strip() and not media and target is not None:
            # No reusable content is available: save this message's exact ID,
            # never an empty pattern that would accidentally match every post.
            media = f"message:{target.chat.id}:{target.message_id}"
            kind = "exact"
            message_only = True
        if kind == "sample":
            kind = sample_kind(content, media)
        if not owner and not await self._activate_for_rule(message):
            return
        if owner and not await self.missing_bot_permissions(message.chat.id):
            await self.database.upsert_chat(
                message.chat.id,
                title=message.chat.title or "",
                username=message.chat.username,
                chat_type=message.chat.type,
                is_enabled=True,
            )
        assert message.from_user is not None
        try:
            rule_id, created = await self.rules.add_rule(
                message.chat.id,
                message.from_user.id,
                kind=kind,
                content=content,
                media=media,
                force=owner,
            )
        except ValueError as error:
            diagnostics = (
                self.content_diagnostics(target, content) if target else f"版本 {__version__}"
            )
            await message.answer(
                str(error)
                + "\n"
                + diagnostics
                + "\n可回复广告发送 /addelete 直接删除，或 /adlearn 文本 后接完整文案。"
            )
            return
        # Manual teaching deletes the sample without retroactive penalties.
        if owner:
            for learned_kind in matching_categories(content):
                await self.rules.set_category_policy(message.chat.id, learned_kind, True)
        deleted = await self.safe_delete(target) if target is not None else False
        name = (
            "指定广告链接" if kind == "link" else CATEGORY_NAMES.get(kind, "相似文案／名片或媒体")
        )
        if owner:
            name = "主管理强制学习：" + name
        deletion = "已保存输入的文字样本"
        if target is not None:
            deletion = "已删除当前广告" if deleted else "当前广告删除失败，请检查权限或消息时间"
        await self.database.log_audit(
            "group_ad_rule_learned",
            actor_user_id=message.from_user.id,
            chat_id=message.chat.id,
            details={
                "rule_id": rule_id,
                "kind": kind,
                "sample_message_id": target.message_id if target is not None else None,
                "manual_text": manual,
                "owner_override": owner,
            },
        )
        await message.answer(
            f"✅ {'已保存' if created else '已有'}规则 #{rule_id}：{name}（{__version__}）。"
            f"\n{deletion}；样本不追加处罚。"
            + (
                "\n此消息无可复用正文或媒体，只登记本条消息标识；可另行粘贴完整文案学习。"
                if message_only
                else "\n规则仅本群生效，重启仍保留；后续命中消息按原机制处理。"
            )
            + f"\n撤销：/adforget {rule_id}"
        )

    async def on_addelete(self, message: Message) -> None:
        if not await self._rule_manager(message):
            return
        target = message.reply_to_message
        if target is None or target.chat.id != message.chat.id:
            await message.answer("请回复要删除的广告后发送 /addelete；此操作不学习、不追加处罚。")
            return
        deleted = await self.safe_delete(target)
        await self.database.log_audit(
            "manual_ad_deleted",
            actor_user_id=message.from_user.id if message.from_user else None,
            chat_id=message.chat.id,
            details={"message_id": target.message_id, "deleted": deleted},
        )
        await message.answer(
            (
                "已删除这条消息；未追加处罚。"
                if deleted
                else "删除失败，请检查机器人删除权限或消息时间。"
            )
            + f"\n版本：{__version__}"
        )

    async def on_adtype(self, message: Message) -> None:
        if not await self._rule_manager(message):
            return
        parts = (message.text or "").split()
        kind = category_key(parts[1]) if len(parts) >= 2 else None
        enabled = {"开": True, "开启": True, "on": True, "关": False, "关闭": False, "off": False}
        state = enabled.get(parts[2].casefold()) if len(parts) == 3 else None
        if kind is None or state is None:
            await message.answer(
                "用法：/adtype 博彩 开（或 关）\n支持：博彩、色情、兼职、营销、红包、赚钱。"
                "\n仅更改管理员教学规则；关闭后原有 AI 和基础反广告规则仍工作。"
            )
            return
        assert message.from_user is not None
        if state:
            owner = await self.is_owner(message.from_user.id)
            if not owner and not await self._activate_for_rule(message):
                return
            try:
                rule_id, _ = await self.rules.add_rule(
                    message.chat.id, message.from_user.id, kind=kind, force=owner
                )
            except ValueError as error:
                await message.answer(str(error))
                return
            await message.answer(
                f"✅ 本群已开启 {CATEGORY_NAMES[kind]} 自动删除，规则 #{rule_id}。"
                "\n仅命中题材、推广话术和链接／联系方式组合时执行；重启仍生效。"
                f"\n撤销：/adforget {rule_id}"
            )
        else:
            for rule in await self.rules.list_rules(message.chat.id):
                if rule.kind == kind:
                    await self.rules.remove_rule(message.chat.id, rule.id)
            await message.answer(
                f"已关闭本群 {CATEGORY_NAMES[kind]} 类型教学规则。"
                "该明确识别类型暂停自动广告处理，其他类型和独立群规继续工作。"
            )
        await self.rules.set_category_policy(message.chat.id, kind, state)
        await self.database.log_audit(
            "group_ad_type_changed",
            actor_user_id=message.from_user.id,
            chat_id=message.chat.id,
            details={"kind": kind, "enabled": state},
        )

    async def on_adrules(self, message: Message) -> None:
        if not await self._rule_manager(message):
            return
        rules = await self.rules.list_rules(message.chat.id)
        parts = (message.text or "").split()
        if len(parts) > 2 or (len(parts) == 2 and not parts[1].isdigit()):
            await message.answer("用法：/adrules 或 /adrules 页码")
            return
        pages = max(1, (len(rules) + 19) // 20)
        page = min(max(1, int(parts[1]) if len(parts) == 2 else 1), pages)
        lines = [f"本群教学规则：{len(rules)} 条（第 {page}/{pages} 页）"]
        for rule in rules[(page - 1) * 20 : page * 20]:
            preview = f"：{rule.pattern[:36]}" if rule.kind == "sample" and rule.pattern else ""
            if rule.media_key:
                preview += (
                    "〔含相同名片匹配〕"
                    if rule.media_key.startswith("contact:")
                    else "〔含相同媒体匹配〕"
                )
            lines.append(f"#{rule.id} {rule.name}{preview}")
        if not rules:
            lines.append("回复广告发送 /adlearn，或 /adtype 博彩 开。")
        lines.append("撤销：/adforget 编号。仅撤销该教学规则，不清除原有违规记录。")
        if pages > 1:
            lines.append("翻页：/adrules 页码")
        await message.answer("\n".join(lines))

    async def on_adforget(self, message: Message) -> None:
        if not await self._rule_manager(message):
            return
        parts = (message.text or "").split()
        if len(parts) != 2 or not parts[1].isdigit() or not 0 < int(parts[1]) < 2**63:
            await message.answer("用法：/adforget 规则编号；先用 /adrules 查看。")
            return
        rule_id = int(parts[1])
        if not await self.rules.remove_rule(message.chat.id, rule_id):
            await message.answer("本群没有这条规则。")
            return
        await self.database.log_audit(
            "group_ad_rule_removed",
            actor_user_id=message.from_user.id if message.from_user else None,
            chat_id=message.chat.id,
            details={"rule_id": rule_id},
        )
        await message.answer(
            f"已撤销本群规则 #{rule_id}；今后的消息不再使用该规则。"
            "其他规则及原有 AI／基础反广告判断继续工作，历史处罚不自动撤销。"
        )

    async def on_nousername(self, message: Message) -> None:
        if not await self._rule_manager(message):
            return
        parts = (message.text or "").split()
        states = {"开": True, "开启": True, "on": True, "关": False, "关闭": False, "off": False}
        state = states.get(parts[1].casefold()) if len(parts) == 2 else None
        if state is None:
            await message.answer("用法：/nousername 开 或 /nousername 关。默认开启，管理员豁免。")
            return
        if state and not await self._activate_for_rule(message):
            return
        assert message.from_user is not None
        await self.rules.set_username_blocked(message.chat.id, message.from_user.id, state)
        await self.database.log_audit(
            "group_username_policy_changed",
            actor_user_id=message.from_user.id,
            chat_id=message.chat.id,
            details={"enabled": state},
        )
        await message.answer(
            "本群禁发用户名已" + ("开启" if state else "关闭") + "，重启后保留。"
            "\n开启时删除成员发布的 @用户名、Telegram 用户名链接和隐藏的用户跳转。"
            "管理员豁免；单纯用户名违规仅删消息，广告仍按原次数处罚。"
        )

    async def on_adcheck(self, message: Message) -> None:
        """Inspect a replied-to message without deleting, recording or using AI."""

        if await self.on_message(message):
            return
        if message.chat.type not in GROUP_TYPES or not await self.can_manage(message):
            await message.answer("仅本群管理员或机器人主管理员可以检查广告。")
            return
        target = message.reply_to_message
        if target is None:
            await message.answer("请回复未删除的广告后发送 /adcheck；只检查，不删除、不记违规。")
            return
        sender_chat = getattr(target, "sender_chat", None)
        user = target.from_user
        if sender_chat is not None:
            anonymous = sender_chat.id == message.chat.id
            identity = "匿名管理员（豁免）" if anonymous else "外部频道身份"
            sender = SenderContext(
                user_id=None,
                nickname=sender_chat.title or "",
                username=sender_chat.username or "",
                is_anonymous_admin=anonymous,
            )
        elif user is not None:
            admin = await self.is_admin(message.chat.id, user.id)
            own_message = user.id == await self.get_bot_id()
            identity = "管理员或身份未核实（豁免）" if admin else "普通成员"
            if user.is_bot:
                identity += "／机器人账号"
            elif getattr(target, "via_bot", None) is not None:
                identity += "／经内联机器人发送"
            sender = SenderContext(
                user_id=user.id,
                nickname=user.full_name,
                username=user.username or "",
                is_bot=user.is_bot,
                is_admin=admin,
                explicitly_exempt=own_message,
            )
        else:
            await message.answer("Telegram 未提供这条消息的可核实发言身份，无法自动处罚。")
            return
        content = self.message_content(target, max_chars=self.settings.classifier.max_content_chars)
        verdict = await self.classify_with_rules(target, content, sender, local_only=True)
        missing = await self.missing_bot_permissions(message.chat.id)
        record = await self.database.get_chat(message.chat.id)
        active = record is not None and record.is_enabled
        labels = {
            "clean": "未判为广告",
            "suspicious": "可疑，未达到删除阈值",
            "advertisement": "广告",
        }
        lines = [
            f"🔎 广告检查（{__version__}，教学规则＋本地规则）",
            f"发言身份：{identity}",
            f"判定：{labels[verdict.label.value]}",
            f"评分：{verdict.confidence:.2f}／删除阈值 {self.settings.classifier.ad_threshold:.2f}",
            "本群权限：" + ("完整" if not missing else "缺少" + "、".join(missing)),
            "本群保护：" + ("已启用" if active else "暂停或未登记"),
            "证据：" + ("、".join(verdict.reasons) if verdict.reasons else "未命中规则"),
            self.content_diagnostics(target, content),
            "未删除消息、未记违规、未调用 AI。",
        ]
        username_blocked = await self.rules.username_blocked(message.chat.id)
        username_hit = (
            username_blocked
            and not sender.exempt_from_automatic_action
            and message_has_username(target)
        )
        lines.append("本群禁发用户名：" + ("开启" if username_blocked else "关闭"))
        if username_hit:
            lines.append("命中禁用户名群规：自动处理时会删除；仅用户名违规不记广告次数。")
        if user is not None and user.is_bot and sender_chat is None:
            lines.append("其他机器人直接发的消息可能不会被 Telegram 主动推送给我。")
        await message.answer("\n".join(lines))

    async def on_check(self, message: Message) -> None:
        if await self.on_message(message):
            return
        if not await self.owner_only(message):
            return
        user_id, _ = self._command_target(message)
        if user_id is None:
            await message.answer("用法：/check 数字用户ID；也可以回复某人的消息后发送 /check")
            return
        offender = await self.database.get_offender(user_id)
        if offender is None:
            await message.answer(f"用户 {user_id} 暂无广告违规记录。")
            return
        status = (
            "全局封禁"
            if offender.global_blocked
            else ("入群预封" if offender.confirmed_ads > 0 else "观察中")
        )
        await message.answer(
            f"用户ID：{offender.user_id}\n"
            f"状态：{status}\n"
            f"累计违规：{offender.confirmed_ads}\n"
            f"最高置信度：{offender.max_confidence:.2%}\n"
            f"原因：{offender.global_block_reason or '—'}"
        )

    async def on_manual_ban(self, message: Message) -> None:
        if await self.on_message(message):
            return
        if not await self.owner_only(message):
            return
        user_id, reason = self._command_target(message)
        if user_id is None:
            await message.answer("用法：/ban 数字用户ID 原因")
            return
        await message.answer(
            await self.owner_ban_user(
                user_id,
                message.from_user.id if message.from_user else None,
                reason,
            )
        )

    async def owner_ban_user(self, user_id: int, actor_id: int | None, reason: str) -> str:
        if not await self.is_owner(actor_id):
            return "此操作仅限主管理。"
        if user_id == await self.get_bot_id() or user_id in self.settings.owner_ids:
            return "不能把机器人自身或主管理员加入预封名单。"
        await self.database.set_global_block(
            user_id,
            reason=reason or "主管理员手动预封",
            actor_user_id=actor_id,
        )
        self.spawn(self.propagate_ban(user_id, reason or "manual_global_block"))
        return f"已将 {user_id} 加入全局预封名单，并开始同步所有群。"

    async def on_manual_unban(self, message: Message) -> None:
        if await self.on_message(message):
            return
        if not await self.owner_only(message):
            return
        user_id, _ = self._command_target(message)
        if user_id is None:
            await message.answer("用法：/unban 数字用户ID")
            return
        await message.answer(
            await self.owner_unban_user(
                user_id,
                message.from_user.id if message.from_user else None,
            )
        )

    async def owner_unban_user(self, user_id: int, actor_id: int | None) -> str:
        if not await self.is_owner(actor_id):
            return "此操作仅限主管理。"
        changed = await self.database.clear_global_block(
            user_id,
            actor_user_id=actor_id,
            reset_strikes=True,
        )
        pending_bot_bans = await self.database.list_bot_ban_chats(user_id)
        if not changed and not pending_bot_bans:
            return f"用户 {user_id} 不在全局预封名单中。"
        self.spawn(self.propagate_unban(user_id))
        return f"已解除 {user_id} 的预封，并开始同步机器人执行过的群。"

    async def invitation_by_group_admin(self, event: ChatMemberUpdated) -> bool:
        """Authorize admission with fresh Telegram status, without owner/cache bypass."""

        actor = event.from_user
        if actor is None or actor.is_bot:
            return False
        try:
            member = await self.bot.get_chat_member(event.chat.id, actor.id)
            return member.status in ADMIN_STATUSES
        except TelegramAPIError:
            # Telegram only guarantees getChatMember for an administrator bot.
            # The administrator list can verify a human inviter before promotion.
            try:
                admins = await self.bot.get_chat_administrators(event.chat.id)
                return any(
                    member.user.id == actor.id and member.status in ADMIN_STATUSES
                    for member in admins
                )
            except TelegramAPIError:
                LOGGER.warning("Cannot verify bot inviter in chat %s", event.chat.id)
                return False

    async def on_my_chat_member(self, event: ChatMemberUpdated) -> None:
        if event.chat.type == ChatType.PRIVATE:
            await self.rules.subscriber_blocked(
                event.chat.id,
                event.new_chat_member.status in ABSENT_STATUSES,
            )
            return
        if event.chat.type not in GROUP_TYPES:
            return
        status = event.new_chat_member.status
        if status in ABSENT_STATUSES:
            await self.database.upsert_chat(
                event.chat.id,
                title=event.chat.title or "",
                username=event.chat.username,
                chat_type=event.chat.type,
                is_enabled=False,
            )
            return
        old = event.old_chat_member
        was_absent = old.status in ABSENT_STATUSES or (
            old.status == ChatMemberStatus.RESTRICTED and not old.is_member
        )
        is_present = status in PRESENT_STATUSES and (
            status != ChatMemberStatus.RESTRICTED or event.new_chat_member.is_member
        )
        if was_absent and is_present and not await self.invitation_by_group_admin(event):
            await self.database.upsert_chat(
                event.chat.id,
                title=event.chat.title or "",
                username=event.chat.username,
                chat_type=event.chat.type,
                is_enabled=False,
            )
            await self.safe_send(
                event.chat.id,
                "仅群主或本群管理员可以邀请此机器人。"
                "本次邀请未通过身份校验，将自动退出；请管理员重新添加。",
            )
            left = False
            try:
                left = bool(await self.bot.leave_chat(event.chat.id))
            except TelegramAPIError:
                LOGGER.warning("Could not leave rejected invitation in chat %s", event.chat.id)
            await self.database.log_audit(
                "bot_invitation_rejected",
                actor_user_id=event.from_user.id if event.from_user else None,
                chat_id=event.chat.id,
                details={"left": left},
            )
            return
        if status not in ADMIN_STATUSES:
            await self.database.upsert_chat(
                event.chat.id,
                title=event.chat.title or "",
                username=event.chat.username,
                chat_type=event.chat.type,
                is_enabled=False,
            )
            with contextlib.suppress(TelegramAPIError):
                await self.bot.send_message(
                    event.chat.id,
                    "请把机器人设为管理员，并开启删除消息、封禁用户和邀请用户权限。",
                )
            return
        missing = await self.missing_bot_permissions(event.chat.id)
        await self.database.upsert_chat(
            event.chat.id,
            title=event.chat.title or "",
            username=event.chat.username,
            chat_type=event.chat.type,
            is_enabled=not missing,
        )
        if missing:
            await self.safe_send(
                event.chat.id,
                "⚠️ 机器人已加入，但缺少权限：" + "、".join(missing),
            )
            return
        await self.safe_send(
            event.chat.id,
            "✅ AI 删广告机器人已自动启用，无需其他配置。",
        )
        self.spawn(self.sync_chat_blocks(event.chat.id))

    async def ensure_chat_active(self, message: Message) -> bool:
        """Lazily register a group if Telegram delivered no membership update."""

        record = await self.database.get_chat(message.chat.id)
        if record is not None:
            return record.is_enabled
        missing = await self.missing_bot_permissions(message.chat.id)
        enabled = not missing
        await self.database.upsert_chat(
            message.chat.id,
            title=message.chat.title or "",
            username=message.chat.username,
            chat_type=message.chat.type,
            is_enabled=enabled,
        )
        if missing:
            await self.safe_send(
                message.chat.id,
                "⚠️ 机器人尚未启用，缺少权限：" + "、".join(missing),
            )
        return enabled

    async def missing_bot_permissions(self, chat_id: int) -> list[str]:
        try:
            member = await self.bot.get_chat_member(chat_id, await self.get_bot_id())
        except TelegramAPIError:
            return ["无法读取机器人权限"]
        if isinstance(member, ChatMemberOwner):
            return []
        if not isinstance(member, ChatMemberAdministrator):
            return ["管理员身份"]
        missing: list[str] = []
        if not member.can_delete_messages:
            missing.append("删除消息")
        if not member.can_restrict_members:
            missing.append("封禁用户")
        if not member.can_invite_users:
            missing.append("邀请用户")
        return missing

    async def on_join_request(self, request: ChatJoinRequest) -> None:
        if request.from_user.id in self.settings.owner_ids:
            return
        if not await self.database.is_join_prebanned(request.from_user.id):
            return
        try:
            await request.decline()
            await self.database.log_audit(
                "preban_join_request_declined",
                target_user_id=request.from_user.id,
                chat_id=request.chat.id,
            )
        except TelegramAPIError as error:
            await self.database.log_audit(
                "preban_join_request_failed",
                target_user_id=request.from_user.id,
                chat_id=request.chat.id,
                details={"error": type(error).__name__},
            )

    @staticmethod
    def member_is_present(member: object) -> bool:
        status = getattr(member, "status", None)
        if status == ChatMemberStatus.RESTRICTED:
            return bool(getattr(member, "is_member", False))
        return status in PRESENT_STATUSES

    async def on_chat_member(self, event: ChatMemberUpdated) -> None:
        if event.chat.type not in GROUP_TYPES:
            return
        user = event.new_chat_member.user
        self._admin_cache.pop((event.chat.id, user.id), None)
        if self.member_is_present(event.old_chat_member):
            async with self._verification_lock:
                pending = await self.rules.get_verification(event.chat.id, user.id)
                if (
                    pending
                    and not pending.get("passed")
                    and (
                        not self.member_is_present(event.new_chat_member)
                        or event.from_user.id != await self.get_bot_id()
                    )
                ):
                    # A human/other bot changed permissions or membership: do
                    # not later undo that action through an old answer button.
                    await self.rules.delete_verification(event.chat.id, user.id)
            return
        if self.member_is_present(event.old_chat_member) or not self.member_is_present(
            event.new_chat_member
        ):
            return
        if user.is_bot:
            return
        if await self.database.is_join_prebanned(user.id):
            await self.ban_in_chat(event.chat.id, user.id, reason="preban_member_joined")
            return
        await self.start_join_verification(event.chat, user, event.date)

    async def on_service_message(self, message: Message) -> None:
        for user in message.new_chat_members or []:
            if user.is_bot:
                continue
            if await self.database.is_join_prebanned(user.id):
                await self.ban_in_chat(message.chat.id, user.id, reason="preban_service_join")
            else:
                await self.start_join_verification(message.chat, user, message.date)
        if self.settings.delete_service_messages:
            await self.safe_delete(message)

    async def start_join_verification(self, chat: object, user: object, joined: datetime) -> None:
        if chat.type != ChatType.SUPERGROUP or user.is_bot or await self.is_owner(user.id):
            return
        async with self._verification_lock:
            record = await self.database.get_chat(chat.id)
            if record is None or not record.is_enabled:
                return
            stamp = int(joined.timestamp())
            state = await self.rules.get_verification(chat.id, user.id)
            if state and state.get("joined", 0) >= stamp:
                return  # membership + service updates refer to the same join
            try:
                member = await self.bot.get_chat_member(chat.id, user.id)
            except TelegramAPIError:
                return  # Never guess role/previous restrictions.
            if member.status in ADMIN_STATUSES or not self.member_is_present(member):
                return
            previous = None
            until = 0
            if member.status == ChatMemberStatus.RESTRICTED:
                previous = {
                    field: bool(getattr(member, field, False))
                    for field in ChatPermissions.model_fields
                }
                date = member.until_date
                until = int(date.timestamp()) if isinstance(date, datetime) else int(date or 0)
            state = {
                "joined": stamp,
                "token": secrets.token_hex(8),
                "a": secrets.randbelow(10) + 1,
                "b": secrets.randbelow(10) + 1,
                "previous": previous,
                "until": until,
                "message_id": 0,
                "passed": False,
            }
            await self.rules.save_verification(chat.id, user.id, state)
            await self.send_join_verification(chat.id, user.id, state)

    async def send_join_verification(self, chat_id: int, user_id: int, state: dict) -> None:
        """Persist before muting; unanswered verification mutes never expire."""

        if state.get("muted"):
            # Resending a missing question must not overwrite a subsequent
            # manual unlock, partial restriction or timed punishment.
            try:
                current = await self.bot.get_chat_member(chat_id, user_id)
            except TelegramAPIError:
                return
            date = getattr(current, "until_date", None)
            until = int(date.timestamp()) if isinstance(date, datetime) else int(date or 0)
            if (
                current.status != ChatMemberStatus.RESTRICTED
                or until > int(time.time())
                or any(getattr(current, field, False) for field in ChatPermissions.model_fields)
            ):
                await self.safe_send(
                    chat_id, f"成员 {user_id} 的权限已变更，请管理员检查，不覆盖现有权限。"
                )
                return
        else:
            try:
                muted = await self.bot.restrict_chat_member(
                    chat_id,
                    user_id,
                    permissions=ChatPermissions(
                        **dict.fromkeys(ChatPermissions.model_fields, False)
                    ),
                    use_independent_chat_permissions=True,
                    until_date=0,
                )
            except TelegramAPIError:
                muted = False
            if not muted:
                await self.safe_send(
                    chat_id, f"⚠️ 无法禁言待验证成员 {user_id}，请检查封禁用户权限。"
                )
                return
            state["muted"] = True
            await self.rules.save_verification(chat_id, user_id, state)
        answer = state["a"] + state["b"]
        options = {answer}
        while len(options) < 4:
            options.add(secrets.randbelow(25) + 1)
        options = list(options)
        secrets.SystemRandom().shuffle(options)
        try:
            prompt = await self.bot.send_message(
                chat_id,
                f"🔐 新成员 {user_id}，请完成入群验证：\n"
                f"{state['a']} + {state['b']} = ？\n"
                "请本人点击正确答案。未验证或答错保持禁言，不会自动解禁。",
                reply_markup=InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text=str(value), callback_data=f"jv:{state['token']}:{value}"
                            )
                            for value in options
                        ]
                    ]
                ),
            )
        except TelegramAPIError:
            await self.database.log_audit(
                "join_verification_prompt_failed",
                chat_id=chat_id,
                target_user_id=user_id,
            )
            return
        state["message_id"] = prompt.message_id
        await self.rules.save_verification(chat_id, user_id, state)

    async def on_verify(self, message: Message) -> None:
        if not await self._rule_manager(message):
            return
        user_id, _ = self._command_target(message)
        if user_id is None:
            await message.answer("用法：/verify 数字用户ID，重新发送该成员未完成的验证。")
            return
        async with self._verification_lock:
            state = await self.rules.get_verification(message.chat.id, user_id)
            if not state or state.get("passed"):
                await message.answer("该成员没有待完成的入群验证。")
                return
            try:
                member = await self.bot.get_chat_member(message.chat.id, user_id)
            except TelegramAPIError:
                await message.answer("无法读取成员权限，请稍后重试。")
                return
            if member.status in ADMIN_STATUSES or not self.member_is_present(member):
                await message.answer("该成员已离群或是管理员，不重新禁言。")
                return
            state["token"] = secrets.token_hex(8)
            state["message_id"] = 0
            await self.rules.save_verification(message.chat.id, user_id, state)
            await self.send_join_verification(message.chat.id, user_id, state)

    async def recover_join_verifications(self) -> None:
        async with self._verification_lock:
            for chat_id, user_id, state in await self.rules.unfinished_verifications():
                record = await self.database.get_chat(chat_id)
                if record is None or not record.is_enabled:
                    continue
                try:
                    member = await self.bot.get_chat_member(chat_id, user_id)
                    if member.status in ADMIN_STATUSES or not self.member_is_present(member):
                        continue
                    if await self.database.is_join_prebanned(user_id):
                        continue
                    await self.send_join_verification(chat_id, user_id, state)
                except TelegramAPIError:
                    continue

    async def on_verify_answer(self, query: CallbackQuery) -> None:
        if not isinstance(query.message, Message) or query.message.chat.type != ChatType.SUPERGROUP:
            await query.answer("此验证不可用。", show_alert=True)
            return
        parts = (query.data or "").split(":")
        if len(parts) != 3 or not parts[2].isdigit():
            await query.answer("无效的验证按钮。", show_alert=True)
            return
        chat_id, user_id = query.message.chat.id, query.from_user.id
        async with self._verification_lock:
            state = await self.rules.get_verification(chat_id, user_id)
            if (
                not state
                or state.get("passed")
                or state["token"] != parts[1]
                or state["message_id"] != query.message.message_id
            ):
                await query.answer("仅本人可验证；题目已失效时请管理员重发。", show_alert=True)
                return
            if int(parts[2]) != state["a"] + state["b"]:
                await query.answer("答案不正确，请重新计算。仍保持禁言。", show_alert=True)
                return
            if await self.database.is_join_prebanned(user_id):
                await query.answer("此账号有广告预封记录，不能通过验证解除。", show_alert=True)
                return
            try:
                member = await self.bot.get_chat_member(chat_id, user_id)
                if not self.member_is_present(member):
                    await query.answer("你已不在群内，请重新入群验证。", show_alert=True)
                    return
                if member.status not in ADMIN_STATUSES:
                    # Do not lift a later timed or partial restriction.
                    date = getattr(member, "until_date", None)
                    until = int(date.timestamp()) if isinstance(date, datetime) else int(date or 0)
                    if until > int(time.time()) or (
                        member.status == ChatMemberStatus.RESTRICTED
                        and any(
                            getattr(member, field, False) for field in ChatPermissions.model_fields
                        )
                    ):
                        await query.answer(
                            "当前存在其他禁言，请联系群管理员处理。", show_alert=True
                        )
                        return
                    previous = state["previous"]
                    old_until = state["until"]
                    if previous is not None and (not old_until or old_until > int(time.time())):
                        permissions = ChatPermissions(**previous)
                        restore_until = max(old_until, int(time.time()) + 31) if old_until else 0
                    else:
                        # All True removes the individual restriction; Telegram
                        # still applies the group's current default permissions.
                        permissions = ChatPermissions(
                            **dict.fromkeys(ChatPermissions.model_fields, True)
                        )
                        restore_until = 0
                    restored = await self.bot.restrict_chat_member(
                        chat_id,
                        user_id,
                        permissions=permissions,
                        use_independent_chat_permissions=True,
                        until_date=restore_until,
                    )
                    if not restored:
                        raise RuntimeError("Telegram did not confirm restriction update")
            except (TelegramAPIError, RuntimeError):
                await query.answer("解除验证禁言失败，请稍后重试或联系管理员。", show_alert=True)
                return
            state["passed"] = True
            await self.rules.save_verification(chat_id, user_id, state)
            await query.answer("验证通过。此前已有的禁言仍按原设置执行。", show_alert=True)
            with contextlib.suppress(TelegramAPIError):
                await self.bot.delete_message(chat_id, state["message_id"])

    @staticmethod
    def content_diagnostics(message: Message, content: str) -> str:
        kinds = [
            name
            for name in (
                "text",
                "caption",
                "rich_message",
                "photo",
                "sticker",
                "video",
                "animation",
                "document",
                "contact",
                "video_note",
            )
            if getattr(message, name, None)
        ]
        rich = rich_content(message)
        return (
            f"读取诊断 {__version__}：类型 {'/'.join(kinds) or '其他'}；"
            f"文字 {len(getattr(message, 'text', None) or '')}；"
            f"富文本 {len(rich.text)}；提取 {len(content)}；"
            f"学习文字 {len(canonical_sample(content))}"
            + ("；富文本超出读取上限" if rich.truncated else "")
        )

    @staticmethod
    def message_content(message: Message, *, max_chars: int = 4_000) -> str:
        text = message.text or message.caption or ""
        rich = rich_content(message)
        if rich.text and rich.text != text.strip():
            text = (text + "\n" + rich.text).strip()
        entities = message.entities if message.text else message.caption_entities
        hidden_links = [
            entity.url for entity in entities or [] if entity.type == "text_link" and entity.url
        ]
        hidden_links.extend(rich.links)
        button_labels: list[str] = []
        markup = getattr(message, "reply_markup", None)
        for row in getattr(markup, "inline_keyboard", None) or []:
            for button in row:
                # callback_data is internal protocol data, not user-visible text.
                label = getattr(button, "text", "")
                if label:
                    button_labels.append(label)
                url = getattr(button, "url", None)
                if url:
                    hidden_links.append(url)
                for field in ("login_url", "web_app"):
                    extra_url = getattr(getattr(button, field, None), "url", None)
                    if extra_url:
                        hidden_links.append(extra_url)
        metadata: list[str] = []
        contact = getattr(message, "contact", None)
        if contact is not None:
            name = " ".join(
                getattr(contact, field, "") or "" for field in ("first_name", "last_name")
            ).strip()[: min(256, max(16, max_chars // 4))]
            phone = (getattr(contact, "phone_number", "") or "")[:32]
            metadata.append(f"联系人名片：{name}\n名片电话：{phone}")
        if hidden_links:
            metadata.append(" ".join(dict.fromkeys(hidden_links)))
        if button_labels:
            metadata.append("按钮：" + "／".join(dict.fromkeys(button_labels)))
        if not metadata:
            return text.strip()[:max_chars]
        # A maximum-length body must not push every hidden/button URL beyond
        # the classifier's limit. Reserve up to half the input for metadata.
        suffix = "\n".join(metadata)[: max_chars // 2]
        body = text.strip()[: max(0, max_chars - len(suffix) - 1)]
        return (body + "\n" + suffix).strip()

    async def classify_with_rules(
        self, message: Message, content: str, sender: SenderContext, *, local_only: bool = False
    ) -> ClassificationVerdict:
        # A taught policy cannot override the existing administrator exemption.
        if not sender.exempt_from_automatic_action:
            categories = matching_categories(content)
            policies = await self.rules.category_policies(message.chat.id)
            if categories and all(policies.get(kind) is False for kind in categories):
                return ClassificationVerdict(
                    VerdictLabel.CLEAN,
                    1.0,
                    reasons=("group_ad_type_disabled",),
                    source="group_policy",
                )
            key = media_key(message) or f"message:{message.chat.id}:{message.message_id}"
            rule = await self.rules.match(message.chat.id, content, key)
            if rule is not None:
                return rule_verdict(rule)
        if local_only:
            local_classifier = HybridAdClassifier(
                replace(self.settings.classifier, ai_endpoint=None, ai_api_key=None)
            )
            return await local_classifier.classify_message(content, sender)
        return await self.classifier.classify_message(content, sender)

    async def enforce_username_policy(self, message: Message, *, exempt: bool = False) -> bool:
        if exempt or not message_has_username(message):
            return False
        if not await self.rules.username_blocked(message.chat.id):
            return False
        deleted = await self.safe_delete(message)
        await self.database.log_audit(
            "group_username_message",
            chat_id=message.chat.id,
            details={"message_id": message.message_id, "deleted": deleted},
        )
        if not deleted:
            await self.send_notice(
                message.chat.id, "⚠️ 检测到禁发用户名消息，但删除失败，请检查权限。"
            )
        return True

    async def on_message(self, message: Message) -> bool:
        """Moderate one group message; return whether an action consumed it."""

        if message.chat.type not in GROUP_TYPES:
            return False
        if not await self.ensure_chat_active(message):
            return False
        if getattr(message, "sender_chat", None) is not None:
            return await self.moderate_sender_chat(message)
        user = message.from_user
        if user is None:
            return False
        if user.id == await self.get_bot_id():
            return False

        is_admin = await self.is_admin(message.chat.id, user.id)
        if not is_admin and await self.database.is_globally_blocked(user.id):
            await self.safe_delete(message)
            await self.ban_in_chat(message.chat.id, user.id, reason="global_preban_message")
            return True

        sender = SenderContext(
            user_id=user.id,
            nickname=user.full_name,
            username=user.username or "",
            is_bot=user.is_bot,
            is_admin=is_admin,
        )
        content = self.message_content(
            message, max_chars=self.settings.classifier.max_content_chars
        )
        if not content and not (user.full_name or user.username):
            return False
        verdict = await self.classify_with_rules(message, content, sender)
        if verdict.reasons and verdict.source != "exemption":
            LOGGER.info(
                "Moderation decision chat=%s message=%s label=%s score=%.2f source=%s",
                message.chat.id,
                message.message_id,
                verdict.label,
                verdict.confidence,
                verdict.source,
            )
        if not verdict.is_ad and not sender.exempt_from_automatic_action and not user.username:
            if await self.rules.username_required(message.chat.id):
                deleted = await self.safe_delete(message)
                await self.database.log_audit(
                    "username_required_message",
                    target_user_id=user.id,
                    chat_id=message.chat.id,
                    details={"message_id": message.message_id, "deleted": deleted},
                )
                await self.send_notice(
                    message.chat.id,
                    "本群已开启无用户名账号禁发。请在 Telegram 设置中设置用户名后再发言。"
                    + ("" if deleted else " 本次删除失败，请管理员检查机器人权限。"),
                )
                return True
        if not verdict.is_ad and await self.enforce_username_policy(
            message, exempt=sender.exempt_from_automatic_action
        ):
            return True
        if verdict.is_suspicious:
            await self.database.log_audit(
                "suspicious_message_observed",
                target_user_id=user.id,
                chat_id=message.chat.id,
                details={
                    "message_id": message.message_id,
                    "confidence": verdict.confidence,
                    "reasons": verdict.reasons,
                },
            )
            return False
        if not verdict.is_ad:
            return False

        deleted = await self.safe_delete(message)
        outcome = await self.database.record_infraction(
            user_id=user.id,
            chat_id=message.chat.id,
            message_id=message.message_id,
            verdict=verdict,
            username=user.username,
            display_name=user.full_name,
            content=content,
            action="automatic_moderation",
            global_preban_threshold=self.settings.classifier.global_preban_threshold,
        )
        if not outcome.inserted:
            return True

        strike = outcome.confirmed_ad_count
        should_global_ban = outcome.global_blocked or strike >= self.settings.global_ban_strikes
        if should_global_ban:
            if not outcome.global_blocked:
                await self.database.set_global_block(
                    user.id,
                    reason=f"累计广告违规 {strike} 次",
                )
            banned = await self.ban_in_chat(
                message.chat.id,
                user.id,
                reason="progressive_global_ban",
            )
            self.spawn(self.propagate_ban(user.id, "advertising"))
            action = "已加入全局预封名单" if banned else "已登记全局预封名单，但当前群执行失败"
            await self.send_notice(
                message.chat.id,
                f"⛔ {'已删除' if deleted else '检测到'}广告，用户 {user.id} {action}。",
            )
            return True

        if strike == 1:
            await self.send_notice(
                message.chat.id,
                f"⚠️ {'已删除' if deleted else '检测到'}广告。"
                f"用户 {user.id} 第 1 次违规，已警告并加入跨群入群预封。",
            )
            return True
        if strike == 2:
            restricted = await self.restrict_user(message.chat.id, user.id, minutes=10)
            await self.send_notice(
                message.chat.id,
                f"🔇 {'已删除' if deleted else '检测到'}广告。用户 {user.id} "
                f"第 2 次违规，{'禁言 10 分钟成功' if restricted else '禁言执行失败'}。",
            )
            return True
        restricted = await self.restrict_user(
            message.chat.id,
            user.id,
            minutes=24 * 60,
        )
        await self.send_notice(
            message.chat.id,
            f"🔇 {'已删除' if deleted else '检测到'}广告。用户 {user.id} "
            f"第 3 次违规，{'禁言 1 天成功' if restricted else '禁言执行失败'}。",
        )
        return True

    async def moderate_sender_chat(self, message: Message) -> bool:
        """Moderate external channel identities without blaming a person."""

        sender_chat = getattr(message, "sender_chat", None)
        if sender_chat is None or sender_chat.id == message.chat.id:
            # sender_chat == current chat is Telegram's anonymous-admin identity.
            return False
        content = self.message_content(
            message, max_chars=self.settings.classifier.max_content_chars
        )
        sender = SenderContext(
            user_id=None,
            nickname=sender_chat.title or "",
            username=sender_chat.username or "",
        )
        verdict = await self.classify_with_rules(message, content, sender)
        if not verdict.is_ad:
            return await self.enforce_username_policy(message)
        deleted = await self.safe_delete(message)
        blocked = False
        try:
            await self.bot.ban_chat_sender_chat(message.chat.id, sender_chat.id)
            blocked = True
        except TelegramAPIError:
            pass
        await self.database.log_audit(
            "sender_chat_advertisement",
            chat_id=message.chat.id,
            details={
                "sender_chat_id": sender_chat.id,
                "confidence": verdict.confidence,
                "deleted": deleted,
                "blocked": blocked,
            },
        )
        await self.send_notice(
            message.chat.id,
            "⛔ 已处理广告频道身份。" if blocked else "⚠️ 检测到广告频道身份，但封禁失败。",
        )
        return True

    async def restrict_user(self, chat_id: int, user_id: int, *, minutes: int) -> bool:
        until = datetime.now(UTC) + timedelta(minutes=minutes)
        try:
            await self.bot.restrict_chat_member(
                chat_id,
                user_id,
                permissions=ChatPermissions(can_send_messages=False),
                until_date=until,
            )
            return True
        except TelegramAPIError as error:
            await self.database.log_audit(
                "restrict_failed",
                target_user_id=user_id,
                chat_id=chat_id,
                details={"error": type(error).__name__, "minutes": minutes},
            )
            return False

    async def ban_in_chat(self, chat_id: int, user_id: int, *, reason: str) -> bool:
        if user_id <= 0 or user_id in self.settings.owner_ids:
            return False
        if user_id == await self.get_bot_id():
            return False
        try:
            member = await self.bot.get_chat_member(chat_id, user_id)
        except TelegramAPIError as error:
            await self.database.log_audit(
                "ban_guard_failed",
                target_user_id=user_id,
                chat_id=chat_id,
                details={"error": type(error).__name__, "reason": reason},
            )
            return False
        if member.status in ADMIN_STATUSES:
            await self.database.log_audit(
                "ban_skipped_administrator",
                target_user_id=user_id,
                chat_id=chat_id,
                details={"reason": reason},
            )
            return False
        if member.status == ChatMemberStatus.KICKED:
            # It was already banned outside this action, so do not claim
            # ownership and never auto-unban it later.
            return False
        try:
            await self.bot.ban_chat_member(chat_id, user_id, revoke_messages=True)
            await self.database.record_bot_ban(chat_id, user_id, reason=reason)
            await self.database.log_audit(
                "user_banned",
                target_user_id=user_id,
                chat_id=chat_id,
                details={"reason": reason},
            )
            return True
        except TelegramRetryAfter as error:
            await asyncio.sleep(float(error.retry_after))
            try:
                await self.bot.ban_chat_member(chat_id, user_id, revoke_messages=True)
                await self.database.record_bot_ban(chat_id, user_id, reason=reason)
                await self.database.log_audit(
                    "user_banned_after_retry",
                    target_user_id=user_id,
                    chat_id=chat_id,
                    details={"reason": reason},
                )
                return True
            except TelegramAPIError as retry_error:
                LOGGER.warning(
                    "Ban retry failed for user %s in chat %s: %s",
                    user_id,
                    chat_id,
                    type(retry_error).__name__,
                )
                pass
        except TelegramAPIError:
            pass
        await self.database.log_audit(
            "ban_failed",
            target_user_id=user_id,
            chat_id=chat_id,
            details={"reason": reason},
        )
        return False

    async def propagate_ban(self, user_id: int, reason: str) -> None:
        for chat in await self.database.list_chats():
            await self.ban_in_chat(chat.chat_id, user_id, reason=reason)

    async def sync_chat_blocks(self, chat_id: int) -> None:
        """Pre-ban the existing shared registry when a new group is connected."""

        offset = 0
        while True:
            offenders = await self.database.list_global_offenders(
                limit=500,
                offset=offset,
            )
            if not offenders:
                return
            for offender in offenders:
                await self.ban_in_chat(
                    chat_id,
                    offender.user_id,
                    reason="new_chat_registry_sync",
                )
            offset += len(offenders)

    async def sync_all_global_blocks(self) -> None:
        """Repair any cross-group propagation missed during a prior outage."""

        for chat in await self.database.list_chats():
            await self.sync_chat_blocks(chat.chat_id)

    async def propagate_unban(self, user_id: int) -> None:
        for chat_id in await self.database.list_bot_ban_chats(user_id):
            try:
                await self.bot.unban_chat_member(chat_id, user_id, only_if_banned=True)
                await self.database.clear_bot_ban(chat_id, user_id)
                await self.database.log_audit(
                    "user_unbanned",
                    target_user_id=user_id,
                    chat_id=chat_id,
                )
            except TelegramAPIError as error:
                await self.database.log_audit(
                    "unban_failed",
                    target_user_id=user_id,
                    chat_id=chat_id,
                    details={"error": type(error).__name__},
                )

    async def safe_delete(self, message: Message) -> bool:
        try:
            await message.delete()
            return True
        except (TelegramBadRequest, TelegramForbiddenError, TelegramAPIError) as error:
            LOGGER.warning(
                "Delete failed chat=%s message=%s error_type=%s",
                message.chat.id,
                message.message_id,
                type(error).__name__,
            )
            return False

    async def safe_send(self, chat_id: int, text: str) -> Message | None:
        try:
            return await self.bot.send_message(chat_id, text)
        except TelegramAPIError:
            return None

    async def send_notice(self, chat_id: int, text: str) -> None:
        if not self.settings.send_action_notice:
            return
        notice = await self.safe_send(chat_id, text)
        if notice is not None:
            self.spawn(self.delete_notice_later(notice))

    async def delete_notice_later(self, message: Message) -> None:
        await asyncio.sleep(self.settings.notice_ttl_seconds)
        await self.safe_delete(message)


async def configure_bot_commands(bot: Bot) -> None:
    commands = [
        BotCommand(command="admin", description="主管理后台（私聊）"),
        BotCommand(command="support", description="联系客服"),
        BotCommand(command="status", description="查看运行状态"),
        BotCommand(command="adcheck", description="回复广告检查漏删原因"),
        BotCommand(command="adlearn", description="回复广告，学习并持续删除同类"),
        BotCommand(command="addelete", description="回复消息直接删除，不学习不处罚"),
        BotCommand(command="adtype", description="开启或关闭本群广告类型规则"),
        BotCommand(command="adrules", description="查看本群教学规则"),
        BotCommand(command="adforget", description="撤销指定教学规则"),
        BotCommand(command="nousername", description="开关本群禁发用户名规则"),
        BotCommand(command="verify", description="重新发送成员未完成的入群验证"),
        BotCommand(command="check", description="查询广告账号记录"),
        BotCommand(command="ban", description="主管理员全局预封"),
        BotCommand(command="unban", description="主管理员解除预封"),
    ]
    with contextlib.suppress(TelegramAPIError):
        await bot.set_my_commands(
            commands,
            scope=BotCommandScopeAllChatAdministrators(),
        )
    rights = ChatAdministratorRights(
        is_anonymous=False,
        can_manage_chat=True,
        can_delete_messages=True,
        can_manage_video_chats=False,
        can_restrict_members=True,
        can_promote_members=False,
        can_change_info=False,
        can_invite_users=True,
        can_post_stories=False,
        can_edit_stories=False,
        can_delete_stories=False,
        can_send_welcome_messages=False,
    )
    with contextlib.suppress(TelegramAPIError):
        await bot.set_my_default_administrator_rights(rights=rights, for_channels=False)


async def run() -> None:
    """Start long polling and release all resources on shutdown."""

    load_dotenv()
    settings = Settings.from_env()
    logging.basicConfig(
        level=getattr(logging, settings.log_level, logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    bot = Bot(
        settings.require_bot_token(),
        default=DefaultBotProperties(parse_mode=None),
    )
    database = Database(
        settings.database.path,
        busy_timeout_ms=settings.database.busy_timeout_ms,
        excerpt_chars=settings.audit_content_excerpt_chars,
    )
    classifier = HybridAdClassifier(settings.classifier)
    service = AntiSpamBot(bot, database, classifier, settings)
    dispatcher = Dispatcher()
    dispatcher.include_router(service.router)
    await database.initialize()
    try:
        await service.rules.initialize()
        await configure_bot_commands(bot)
        await bot.delete_webhook(drop_pending_updates=False)
        service.spawn(service.sync_all_global_blocks())
        service.spawn(service.recover_join_verifications())
        await dispatcher.start_polling(
            bot,
            allowed_updates=[
                "message",
                "edited_message",
                "my_chat_member",
                "chat_member",
                "chat_join_request",
                "callback_query",
            ],
        )
    finally:
        await service.shutdown()
        await service.rules.close()
        await classifier.close()
        await database.close()
        await bot.session.close()
