"""Async SQLite persistence for cross-group anti-spam state."""

from __future__ import annotations

import asyncio
import hashlib
import json
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

import aiosqlite

from .models import (
    AuditEvent,
    ChatRecord,
    ClassificationVerdict,
    InfractionOutcome,
    OffenderRecord,
    utc_now_iso,
)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS chats (
    chat_id INTEGER PRIMARY KEY,
    title TEXT NOT NULL DEFAULT '',
    username TEXT,
    chat_type TEXT NOT NULL DEFAULT 'group',
    is_enabled INTEGER NOT NULL DEFAULT 1 CHECK (is_enabled IN (0, 1)),
    added_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS offenders (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    display_name TEXT,
    total_infractions INTEGER NOT NULL DEFAULT 0,
    confirmed_ads INTEGER NOT NULL DEFAULT 0,
    max_confidence REAL NOT NULL DEFAULT 0.0,
    risk_score REAL NOT NULL DEFAULT 0.0,
    global_blocked INTEGER NOT NULL DEFAULT 0 CHECK (global_blocked IN (0, 1)),
    global_blocked_at TEXT,
    global_block_reason TEXT,
    first_seen_at TEXT NOT NULL,
    last_seen_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS infractions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    chat_id INTEGER NOT NULL,
    message_id INTEGER,
    label TEXT NOT NULL,
    confidence REAL NOT NULL CHECK (confidence >= 0.0 AND confidence <= 1.0),
    reasons_json TEXT NOT NULL DEFAULT '[]',
    detector TEXT NOT NULL,
    content_hash TEXT,
    content_excerpt TEXT,
    action TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES offenders(user_id) ON DELETE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_infractions_message
ON infractions(chat_id, message_id)
WHERE message_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS ix_infractions_user_created
ON infractions(user_id, created_at);

CREATE INDEX IF NOT EXISTS ix_infractions_chat_user
ON infractions(chat_id, user_id);

CREATE INDEX IF NOT EXISTS ix_offenders_global_blocked
ON offenders(global_blocked, last_seen_at);

CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    actor_user_id INTEGER,
    target_user_id INTEGER,
    chat_id INTEGER,
    details_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS ix_audit_target_created
ON audit(target_user_id, created_at);

CREATE TABLE IF NOT EXISTS bot_bans (
    chat_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    reason TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (chat_id, user_id)
);

CREATE INDEX IF NOT EXISTS ix_bot_bans_user
ON bot_bans(user_id, chat_id);
"""


def _json_dumps(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str)


class Database:
    """Small repository with serialized, idempotent write transactions."""

    def __init__(
        self,
        path: str | Path,
        *,
        busy_timeout_ms: int = 5_000,
        excerpt_chars: int = 240,
    ) -> None:
        self.path = Path(path)
        self.busy_timeout_ms = busy_timeout_ms
        self.excerpt_chars = max(32, min(2_000, excerpt_chars))
        self._connection: aiosqlite.Connection | None = None
        self._write_lock = asyncio.Lock()

    async def __aenter__(self) -> Database:
        await self.initialize()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    async def initialize(self) -> None:
        if self._connection is not None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = await aiosqlite.connect(self.path)
        connection.row_factory = aiosqlite.Row
        try:
            await connection.execute("PRAGMA journal_mode=WAL")
            await connection.execute("PRAGMA foreign_keys=ON")
            await connection.execute(f"PRAGMA busy_timeout={max(1, int(self.busy_timeout_ms))}")
            await connection.executescript(_SCHEMA)
            await connection.commit()
        except Exception:
            await connection.close()
            raise
        self._connection = connection

    async def close(self) -> None:
        if self._connection is not None:
            await self._connection.close()
            self._connection = None

    def _conn(self) -> aiosqlite.Connection:
        if self._connection is None:
            raise RuntimeError("database is not initialized")
        return self._connection

    async def upsert_chat(
        self,
        chat_id: int,
        *,
        title: str = "",
        username: str | None = None,
        chat_type: str = "group",
        is_enabled: bool = True,
    ) -> None:
        now = utc_now_iso()
        async with self._write_lock:
            conn = self._conn()
            await conn.execute(
                """
                INSERT INTO chats(
                    chat_id, title, username, chat_type, is_enabled, added_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(chat_id) DO UPDATE SET
                    title = excluded.title,
                    username = excluded.username,
                    chat_type = excluded.chat_type,
                    is_enabled = excluded.is_enabled,
                    updated_at = excluded.updated_at
                """,
                (
                    chat_id,
                    title[:512],
                    username,
                    chat_type[:32],
                    int(is_enabled),
                    now,
                    now,
                ),
            )
            await conn.commit()

    async def get_chat(self, chat_id: int) -> ChatRecord | None:
        cursor = await self._conn().execute("SELECT * FROM chats WHERE chat_id = ?", (chat_id,))
        row = await cursor.fetchone()
        await cursor.close()
        if row is None:
            return None
        return ChatRecord(
            chat_id=row["chat_id"],
            title=row["title"],
            username=row["username"],
            chat_type=row["chat_type"],
            is_enabled=bool(row["is_enabled"]),
            added_at=row["added_at"],
            updated_at=row["updated_at"],
        )

    async def list_chats(
        self,
        *,
        enabled_only: bool = True,
    ) -> list[ChatRecord]:
        query = "SELECT * FROM chats"
        if enabled_only:
            query += " WHERE is_enabled = 1"
        query += " ORDER BY added_at ASC"
        cursor = await self._conn().execute(query)
        rows = await cursor.fetchall()
        await cursor.close()
        return [
            ChatRecord(
                chat_id=row["chat_id"],
                title=row["title"],
                username=row["username"],
                chat_type=row["chat_type"],
                is_enabled=bool(row["is_enabled"]),
                added_at=row["added_at"],
                updated_at=row["updated_at"],
            )
            for row in rows
        ]

    async def get_stats(self) -> dict[str, int]:
        """Return inexpensive counters for the owner status command."""

        row = await self._fetchone(
            self._conn(),
            """
            SELECT
                (SELECT COUNT(*) FROM chats) AS chats,
                (SELECT COUNT(*) FROM chats WHERE is_enabled = 1) AS active_chats,
                (SELECT COUNT(*) FROM offenders) AS offenders,
                (SELECT COUNT(*) FROM offenders WHERE global_blocked = 1)
                    AS global_blocked,
                (SELECT COUNT(*) FROM infractions) AS infractions
            """,
        )
        assert row is not None
        return {
            "chats": int(row["chats"]),
            "active_chats": int(row["active_chats"]),
            "offenders": int(row["offenders"]),
            "global_blocked": int(row["global_blocked"]),
            "infractions": int(row["infractions"]),
        }

    async def record_infraction(
        self,
        *,
        user_id: int,
        chat_id: int,
        message_id: int | None,
        verdict: ClassificationVerdict,
        username: str | None = None,
        display_name: str | None = None,
        content: str | None = None,
        action: str | None = None,
        global_preban_threshold: float = 0.97,
    ) -> InfractionOutcome:
        """Atomically record a verdict and update the cross-group registry.

        ``(chat_id, message_id)`` is unique when a message ID is present, so a
        retried Telegram update cannot increase the strike count twice.
        """

        if not 0.0 <= global_preban_threshold <= 1.0:
            raise ValueError("global_preban_threshold must be between 0 and 1")
        now = utc_now_iso()
        excerpt = (content or "").strip()[: self.excerpt_chars] or None
        content_hash = (
            hashlib.sha256((content or "").encode("utf-8")).hexdigest() if content else None
        )
        reasons_json = _json_dumps(verdict.reasons)
        high_confidence_candidate = verdict.qualifies_for_global_preban(global_preban_threshold)

        async with self._write_lock:
            conn = self._conn()
            await conn.execute("BEGIN IMMEDIATE")
            try:
                await conn.execute(
                    """
                    INSERT INTO offenders(
                        user_id, username, display_name, first_seen_at, last_seen_at
                    ) VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(user_id) DO UPDATE SET
                        username = COALESCE(excluded.username, offenders.username),
                        display_name = COALESCE(
                            excluded.display_name, offenders.display_name
                        ),
                        last_seen_at = excluded.last_seen_at
                    """,
                    (user_id, username, display_name, now, now),
                )
                cursor = await conn.execute(
                    """
                    INSERT OR IGNORE INTO infractions(
                        user_id, chat_id, message_id, label, confidence,
                        reasons_json, detector, content_hash, content_excerpt,
                        action, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        user_id,
                        chat_id,
                        message_id,
                        verdict.label.value,
                        verdict.confidence,
                        reasons_json,
                        verdict.source,
                        content_hash,
                        excerpt,
                        action,
                        now,
                    ),
                )
                inserted = cursor.rowcount == 1
                infraction_id = cursor.lastrowid if inserted else None
                await cursor.close()

                if inserted:
                    confirmed_increment = 1 if verdict.is_ad else 0
                    await conn.execute(
                        """
                        UPDATE offenders SET
                            total_infractions = total_infractions + 1,
                            confirmed_ads = confirmed_ads + ?,
                            max_confidence = MAX(max_confidence, ?),
                            risk_score = MIN(
                                1.0,
                                MAX(risk_score * 0.90, ?)
                            ),
                            last_seen_at = ?
                        WHERE user_id = ?
                        """,
                        (
                            confirmed_increment,
                            verdict.confidence,
                            verdict.confidence,
                            now,
                            user_id,
                        ),
                    )
                    await conn.execute(
                        """
                        INSERT INTO audit(
                            event_type, target_user_id, chat_id, details_json, created_at
                        ) VALUES (?, ?, ?, ?, ?)
                        """,
                        (
                            "infraction_recorded",
                            user_id,
                            chat_id,
                            _json_dumps(
                                {
                                    "infraction_id": infraction_id,
                                    "message_id": message_id,
                                    "label": verdict.label.value,
                                    "confidence": verdict.confidence,
                                    "action": action,
                                    "high_confidence_candidate": (high_confidence_candidate),
                                }
                            ),
                            now,
                        ),
                    )
                    if high_confidence_candidate:
                        await conn.execute(
                            """
                            INSERT INTO audit(
                                event_type, target_user_id, chat_id,
                                details_json, created_at
                            ) VALUES (?, ?, ?, ?, ?)
                            """,
                            (
                                "high_confidence_candidate",
                                user_id,
                                chat_id,
                                _json_dumps(
                                    {
                                        "infraction_id": infraction_id,
                                        "message_id": message_id,
                                        "confidence": verdict.confidence,
                                    }
                                ),
                                now,
                            ),
                        )

                stats = await self._fetchone(
                    conn,
                    """
                    SELECT
                        total_infractions,
                        confirmed_ads,
                        global_blocked,
                        (SELECT COUNT(*) FROM infractions
                         WHERE user_id = ? AND chat_id = ?) AS chat_count
                    FROM offenders WHERE user_id = ?
                    """,
                    (user_id, chat_id, user_id),
                )
                await conn.commit()
            except Exception:
                await conn.rollback()
                raise

        is_globally_blocked = bool(stats["global_blocked"])
        return InfractionOutcome(
            inserted=inserted,
            infraction_id=infraction_id,
            chat_infraction_count=int(stats["chat_count"]),
            global_infraction_count=int(stats["total_infractions"]),
            confirmed_ad_count=int(stats["confirmed_ads"]),
            global_blocked=is_globally_blocked,
            newly_global_blocked=False,
        )

    async def record_bot_ban(
        self,
        chat_id: int,
        user_id: int,
        reason: str,
    ) -> None:
        """Record a successful ban owned by this bot for safe rollback."""

        now = utc_now_iso()
        async with self._write_lock:
            conn = self._conn()
            await conn.execute(
                """
                INSERT INTO bot_bans(chat_id, user_id, reason, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(chat_id, user_id) DO UPDATE SET
                    reason = excluded.reason,
                    updated_at = excluded.updated_at
                """,
                (chat_id, user_id, reason[:512], now, now),
            )
            await conn.commit()

    async def list_bot_ban_chats(self, user_id: int) -> list[int]:
        """List only groups where this bot previously recorded a successful ban."""

        cursor = await self._conn().execute(
            """
            SELECT chat_id FROM bot_bans
            WHERE user_id = ?
            ORDER BY chat_id
            """,
            (user_id,),
        )
        rows = await cursor.fetchall()
        await cursor.close()
        return [int(row["chat_id"]) for row in rows]

    async def clear_bot_ban(self, chat_id: int, user_id: int) -> bool:
        """Forget bot ownership after Telegram confirms a successful unban."""

        async with self._write_lock:
            conn = self._conn()
            cursor = await conn.execute(
                "DELETE FROM bot_bans WHERE chat_id = ? AND user_id = ?",
                (chat_id, user_id),
            )
            changed = cursor.rowcount == 1
            await cursor.close()
            await conn.commit()
        return changed

    async def get_offender(self, user_id: int) -> OffenderRecord | None:
        row = await self._fetchone(
            self._conn(),
            "SELECT * FROM offenders WHERE user_id = ?",
            (user_id,),
        )
        return self._offender_from_row(row) if row is not None else None

    async def is_globally_blocked(self, user_id: int) -> bool:
        row = await self._fetchone(
            self._conn(),
            "SELECT global_blocked FROM offenders WHERE user_id = ?",
            (user_id,),
        )
        return bool(row and row["global_blocked"])

    async def is_join_prebanned(self, user_id: int) -> bool:
        """Return whether a user should be rejected from future group joins.

        A confirmed advertisement is enough to protect other groups from a
        future join, but it does not set the permanent cross-group block. The
        enforcement layer still owns the progressive strike policy.
        """

        row = await self._fetchone(
            self._conn(),
            """
            SELECT global_blocked, confirmed_ads
            FROM offenders WHERE user_id = ?
            """,
            (user_id,),
        )
        return bool(row and (row["global_blocked"] or row["confirmed_ads"] > 0))

    async def list_global_offenders(
        self,
        *,
        limit: int = 100,
        offset: int = 0,
    ) -> list[OffenderRecord]:
        limit = max(1, min(1_000, limit))
        offset = max(0, offset)
        cursor = await self._conn().execute(
            """
            SELECT * FROM offenders
            WHERE global_blocked = 1
            ORDER BY global_blocked_at DESC
            LIMIT ? OFFSET ?
            """,
            (limit, offset),
        )
        rows = await cursor.fetchall()
        await cursor.close()
        return [self._offender_from_row(row) for row in rows]

    async def set_global_block(
        self,
        user_id: int,
        *,
        reason: str,
        actor_user_id: int | None = None,
    ) -> None:
        now = utc_now_iso()
        async with self._write_lock:
            conn = self._conn()
            await conn.execute("BEGIN IMMEDIATE")
            try:
                await conn.execute(
                    """
                    INSERT INTO offenders(
                        user_id, global_blocked, global_blocked_at,
                        global_block_reason, first_seen_at, last_seen_at
                    ) VALUES (?, 1, ?, ?, ?, ?)
                    ON CONFLICT(user_id) DO UPDATE SET
                        global_blocked = 1,
                        global_blocked_at = COALESCE(
                            offenders.global_blocked_at, excluded.global_blocked_at
                        ),
                        global_block_reason = excluded.global_block_reason,
                        last_seen_at = excluded.last_seen_at
                    """,
                    (user_id, now, reason[:512], now, now),
                )
                await self._insert_audit(
                    conn,
                    AuditEvent(
                        event_type="global_block_set",
                        actor_user_id=actor_user_id,
                        target_user_id=user_id,
                        details={"reason": reason[:512]},
                    ),
                    now,
                )
                await conn.commit()
            except Exception:
                await conn.rollback()
                raise

    async def clear_global_block(
        self,
        user_id: int,
        *,
        reason: str = "manual_review",
        actor_user_id: int | None = None,
        reset_strikes: bool = False,
    ) -> bool:
        now = utc_now_iso()
        async with self._write_lock:
            conn = self._conn()
            await conn.execute("BEGIN IMMEDIATE")
            try:
                current = await self._fetchone(
                    conn,
                    """
                    SELECT global_blocked, total_infractions, confirmed_ads,
                           max_confidence, risk_score
                    FROM offenders WHERE user_id = ?
                    """,
                    (user_id,),
                )
                changed = bool(
                    current
                    and (
                        current["global_blocked"]
                        or (
                            reset_strikes
                            and (
                                current["total_infractions"]
                                or current["confirmed_ads"]
                                or current["max_confidence"]
                                or current["risk_score"]
                            )
                        )
                    )
                )
                if not changed:
                    await conn.commit()
                    return False
                cursor = await conn.execute(
                    """
                    UPDATE offenders SET
                        global_blocked = 0,
                        global_blocked_at = NULL,
                        global_block_reason = NULL,
                        total_infractions = CASE WHEN ? THEN 0 ELSE total_infractions END,
                        confirmed_ads = CASE WHEN ? THEN 0 ELSE confirmed_ads END,
                        max_confidence = CASE WHEN ? THEN 0.0 ELSE max_confidence END,
                        risk_score = CASE WHEN ? THEN 0.0 ELSE risk_score END,
                        last_seen_at = ?
                    WHERE user_id = ?
                    """,
                    (
                        int(reset_strikes),
                        int(reset_strikes),
                        int(reset_strikes),
                        int(reset_strikes),
                        now,
                        user_id,
                    ),
                )
                await cursor.close()
                await self._insert_audit(
                    conn,
                    AuditEvent(
                        event_type="global_block_cleared",
                        actor_user_id=actor_user_id,
                        target_user_id=user_id,
                        details={
                            "reason": reason[:512],
                            "reset_strikes": reset_strikes,
                        },
                    ),
                    now,
                )
                await conn.commit()
            except Exception:
                await conn.rollback()
                raise
        return changed

    async def log_audit(
        self,
        event_type: str,
        *,
        actor_user_id: int | None = None,
        target_user_id: int | None = None,
        chat_id: int | None = None,
        details: Mapping[str, Any] | None = None,
    ) -> int:
        event = AuditEvent(
            event_type=event_type,
            actor_user_id=actor_user_id,
            target_user_id=target_user_id,
            chat_id=chat_id,
            details=details or {},
        )
        async with self._write_lock:
            conn = self._conn()
            cursor = await self._insert_audit(conn, event, utc_now_iso())
            audit_id = int(cursor.lastrowid)
            await cursor.close()
            await conn.commit()
        return audit_id

    @staticmethod
    async def _fetchone(
        conn: aiosqlite.Connection,
        query: str,
        parameters: Iterable[Any] = (),
    ) -> aiosqlite.Row | None:
        cursor = await conn.execute(query, tuple(parameters))
        row = await cursor.fetchone()
        await cursor.close()
        return row

    @staticmethod
    async def _insert_audit(
        conn: aiosqlite.Connection,
        event: AuditEvent,
        created_at: str,
    ) -> aiosqlite.Cursor:
        return await conn.execute(
            """
            INSERT INTO audit(
                event_type, actor_user_id, target_user_id,
                chat_id, details_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                event.event_type[:128],
                event.actor_user_id,
                event.target_user_id,
                event.chat_id,
                _json_dumps(event.details),
                created_at,
            ),
        )

    @staticmethod
    def _offender_from_row(row: aiosqlite.Row) -> OffenderRecord:
        return OffenderRecord(
            user_id=row["user_id"],
            username=row["username"],
            display_name=row["display_name"],
            total_infractions=row["total_infractions"],
            confirmed_ads=row["confirmed_ads"],
            max_confidence=row["max_confidence"],
            risk_score=row["risk_score"],
            global_blocked=bool(row["global_blocked"]),
            global_blocked_at=row["global_blocked_at"],
            global_block_reason=row["global_block_reason"],
            first_seen_at=row["first_seen_at"],
            last_seen_at=row["last_seen_at"],
        )
