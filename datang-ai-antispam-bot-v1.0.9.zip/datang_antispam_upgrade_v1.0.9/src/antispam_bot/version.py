"""Release identifier visible in status and offline deployment verification."""

__version__ = "1.0.9"
