"""Bounded extraction of Telegram rich messages, without reading reply history."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


def _field(value: object, name: str, default: Any = None) -> Any:
    return value.get(name, default) if isinstance(value, dict) else getattr(value, name, default)


@dataclass(frozen=True, slots=True)
class RichContent:
    text: str = ""
    links: tuple[str, ...] = ()
    media: tuple[str, ...] = ()
    has_user_mention: bool = False
    truncated: bool = False


def rich_content(message: object) -> RichContent:
    """Read visible rich fields only; ignore callback data, users and replies."""

    root = _field(message, "rich_message")
    if root is None:
        return RichContent()
    text: list[str] = []
    links: list[str] = []
    media: list[str] = []
    chars = 0
    nodes = 0
    mention = False
    truncated = False

    def append(value: str) -> None:
        nonlocal chars, truncated
        remaining = max(0, 20_000 - chars)
        text.append(value[:remaining])
        chars += min(remaining, len(value))
        if len(value) > remaining:
            truncated = True

    def link(value: object) -> None:
        if isinstance(value, str) and value and len(links) < 128:
            links.append(value[:4096])

    def walk(node: object, depth: int = 0) -> None:
        nonlocal nodes, mention, truncated
        if node is None:
            return
        nodes += 1
        if depth > 24 or nodes > 2000:
            truncated = True
            return
        if isinstance(node, str):
            append(node)
            return
        if isinstance(node, list | tuple):
            for item in node:
                if nodes > 2000:
                    truncated = True
                    break
                walk(item, depth + 1)
            return
        kind = _field(node, "type", "")
        link(_field(node, "url"))
        for field in ("login_url", "web_app"):
            link(_field(_field(node, field), "url"))
        if kind == "mention":
            mention = True
            username = _field(node, "username")
            if isinstance(username, str) and username:
                link("https://t.me/" + username.lstrip("@"))
        elif kind == "text_mention":
            mention = True
            user_id = _field(_field(node, "user"), "id")
            if isinstance(user_id, int) and user_id > 0:
                link(f"tg://user?id={user_id}")
        for field in ("photo", "video", "animation", "document", "audio", "voice", "video_note"):
            item = _field(node, field)
            if field == "photo" and isinstance(item, list | tuple) and item:
                item = item[-1]
            unique_id = _field(item, "file_unique_id")
            if isinstance(unique_id, str) and unique_id and len(media) < 64:
                media.append(field + ":" + unique_id)
        # These are visible schema fields, not a generic recursive dict walk.
        for field in (
            "summary",
            "text",
            "blocks",
            "items",
            "cells",
            "caption",
            "credit",
            "button",
            "buttons",
        ):
            walk(_field(node, field), depth + 1)
        if kind == "custom_emoji":
            value = _field(node, "alternative_text")
            if isinstance(value, str):
                append(value)
        if kind in {
            "paragraph",
            "section_heading",
            "preformatted",
            "blockquote",
            "expandable_blockquote",
            "pullquote",
            "list",
            "table",
            "details",
            "footer",
            "buttons",
        }:
            append("\n")

    walk(root)
    return RichContent(
        text="".join(text).strip(),
        links=tuple(dict.fromkeys(links)),
        media=tuple(dict.fromkeys(media)),
        has_user_mention=mention,
        truncated=truncated,
    )
