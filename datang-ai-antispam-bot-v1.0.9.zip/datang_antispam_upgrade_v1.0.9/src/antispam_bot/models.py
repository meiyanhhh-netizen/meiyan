"""Typed values passed between Telegram handlers, classifier, and storage."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any


def utc_now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class VerdictLabel(StrEnum):
    CLEAN = "clean"
    SUSPICIOUS = "suspicious"
    ADVERTISEMENT = "advertisement"


@dataclass(frozen=True, slots=True)
class SenderContext:
    """Identity snapshot used as classification context, never as authority.

    The handler should obtain ``is_admin`` from Telegram immediately before a
    destructive action. A failed administrator lookup should be treated as an
    exemption by the enforcement layer.
    """

    user_id: int | None
    nickname: str = ""
    username: str = ""
    is_bot: bool = False
    is_admin: bool = False
    is_anonymous_admin: bool = False
    explicitly_exempt: bool = False

    @property
    def exempt_from_automatic_action(self) -> bool:
        return self.is_admin or self.is_anonymous_admin or self.explicitly_exempt


@dataclass(frozen=True, slots=True)
class ClassificationVerdict:
    label: VerdictLabel
    confidence: float
    reasons: tuple[str, ...] = field(default_factory=tuple)
    source: str = "heuristic"
    heuristic_confidence: float = 0.0
    ai_confidence: float | None = None
    strong_content_evidence: bool = False

    def __post_init__(self) -> None:
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence must be between 0 and 1")
        if not 0.0 <= self.heuristic_confidence <= 1.0:
            raise ValueError("heuristic_confidence must be between 0 and 1")
        if self.ai_confidence is not None and not 0.0 <= self.ai_confidence <= 1.0:
            raise ValueError("ai_confidence must be between 0 and 1")

    @property
    def is_ad(self) -> bool:
        return self.label is VerdictLabel.ADVERTISEMENT

    @property
    def is_suspicious(self) -> bool:
        return self.label is VerdictLabel.SUSPICIOUS

    def qualifies_for_global_preban(self, threshold: float) -> bool:
        """Require strong message evidence; a sales-like nickname is not enough."""

        return self.is_ad and self.strong_content_evidence and self.confidence >= threshold


@dataclass(frozen=True, slots=True)
class OffenderRecord:
    user_id: int
    username: str | None
    display_name: str | None
    total_infractions: int
    confirmed_ads: int
    max_confidence: float
    risk_score: float
    global_blocked: bool
    global_blocked_at: str | None
    global_block_reason: str | None
    first_seen_at: str
    last_seen_at: str


@dataclass(frozen=True, slots=True)
class InfractionOutcome:
    inserted: bool
    infraction_id: int | None
    chat_infraction_count: int
    global_infraction_count: int
    confirmed_ad_count: int
    global_blocked: bool
    newly_global_blocked: bool


@dataclass(frozen=True, slots=True)
class ChatRecord:
    chat_id: int
    title: str
    username: str | None
    chat_type: str
    is_enabled: bool
    added_at: str
    updated_at: str


@dataclass(frozen=True, slots=True)
class AuditEvent:
    event_type: str
    actor_user_id: int | None = None
    target_user_id: int | None = None
    chat_id: int | None = None
    details: Mapping[str, Any] = field(default_factory=dict)
