"""Environment-backed configuration with conservative moderation defaults."""

from __future__ import annotations

import os
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse


def _as_bool(value: str | None, default: bool) -> bool:
    if value is None:
        return default
    normalized = value.strip().casefold()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    return default


def _as_float(
    value: str | None,
    default: float,
    *,
    minimum: float = 0.0,
    maximum: float = 1.0,
) -> float:
    try:
        parsed = float(value) if value is not None else default
    except (TypeError, ValueError):
        return default
    return min(maximum, max(minimum, parsed))


def _as_int(
    value: str | None,
    default: int,
    *,
    minimum: int = 1,
    maximum: int = 100_000,
) -> int:
    try:
        parsed = int(value) if value is not None else default
    except (TypeError, ValueError):
        return default
    return min(maximum, max(minimum, parsed))


def _as_int_set(value: str | None) -> frozenset[int]:
    if not value:
        return frozenset()
    result: set[int] = set()
    for item in re.split(r"[\s,;]+", value.strip()):
        if not item:
            continue
        try:
            result.add(int(item))
        except ValueError:
            continue
    return frozenset(result)


@dataclass(frozen=True, slots=True)
class ClassifierConfig:
    """Configuration for the deterministic + optional LLM classifier.

    ``ai_endpoint`` should normally be the complete OpenAI-compatible
    ``/chat/completions`` URL. If it ends in ``/v1``, the suffix is appended.
    The bot works without any external AI service.
    """

    ad_threshold: float = 0.88
    suspicious_threshold: float = 0.45
    global_preban_threshold: float = 0.97
    ai_weight: float = 0.45
    ai_endpoint: str | None = None
    ai_api_key: str | None = None
    ai_model: str = "gpt-4o-mini"
    ai_timeout_seconds: float = 8.0
    ai_candidate_threshold: float = 0.12
    ai_max_concurrency: int = 4
    ai_queue_timeout_seconds: float = 0.25
    max_content_chars: int = 4_000

    def __post_init__(self) -> None:
        thresholds = (
            self.suspicious_threshold,
            self.ad_threshold,
            self.global_preban_threshold,
        )
        if any(not 0.0 <= value <= 1.0 for value in thresholds):
            raise ValueError("classifier thresholds must be between 0 and 1")
        if not (self.suspicious_threshold < self.ad_threshold <= self.global_preban_threshold):
            raise ValueError(
                "expected suspicious_threshold < ad_threshold <= global_preban_threshold"
            )
        if not 0.0 <= self.ai_weight <= 1.0:
            raise ValueError("ai_weight must be between 0 and 1")
        if self.ai_timeout_seconds <= 0:
            raise ValueError("ai_timeout_seconds must be positive")
        if not 0.0 <= self.ai_candidate_threshold <= 1.0:
            raise ValueError("ai_candidate_threshold must be between 0 and 1")
        if self.ai_max_concurrency < 1:
            raise ValueError("ai_max_concurrency must be positive")
        if self.ai_queue_timeout_seconds <= 0:
            raise ValueError("ai_queue_timeout_seconds must be positive")
        if self.max_content_chars < 256:
            raise ValueError("max_content_chars must be at least 256")

    @property
    def ai_enabled(self) -> bool:
        if not self.ai_endpoint or not self.ai_model:
            return False
        hostname = (urlparse(self.ai_endpoint).hostname or "").casefold()
        if hostname == "api.openai.com":
            return bool(self.ai_api_key and self.ai_api_key.strip())
        # Local and explicitly configured OpenAI-compatible services may be
        # intentionally unauthenticated.
        return True


@dataclass(frozen=True, slots=True)
class DatabaseConfig:
    path: Path = Path("data/antispam.db")
    busy_timeout_ms: int = 5_000

    def __post_init__(self) -> None:
        if self.busy_timeout_ms < 1:
            raise ValueError("busy_timeout_ms must be positive")


@dataclass(frozen=True, slots=True)
class Settings:
    """Application settings shared by the transport and core layers."""

    bot_token: str = ""
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    classifier: ClassifierConfig = field(default_factory=ClassifierConfig)
    owner_ids: frozenset[int] = field(default_factory=frozenset)
    global_ban_strikes: int = 4
    notice_ttl_seconds: int = 10
    send_action_notice: bool = True
    delete_service_messages: bool = True
    audit_content_excerpt_chars: int = 240
    log_level: str = "INFO"

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None) -> Settings:
        env = os.environ if environ is None else environ
        database = DatabaseConfig(
            path=Path(
                env.get("ANTISPAM_DATABASE_PATH") or env.get("DATABASE_PATH") or "data/antispam.db"
            ),
            busy_timeout_ms=_as_int(
                env.get("ANTISPAM_DB_BUSY_TIMEOUT_MS"),
                5_000,
                maximum=60_000,
            ),
        )
        classifier = ClassifierConfig(
            ad_threshold=_as_float(
                env.get("ANTISPAM_AD_THRESHOLD") or env.get("AD_THRESHOLD"),
                0.88,
            ),
            suspicious_threshold=_as_float(env.get("ANTISPAM_SUSPICIOUS_THRESHOLD"), 0.45),
            global_preban_threshold=_as_float(
                env.get("ANTISPAM_GLOBAL_PREBAN_THRESHOLD") or env.get("GLOBAL_PREBAN_THRESHOLD"),
                0.97,
            ),
            ai_weight=_as_float(env.get("ANTISPAM_AI_WEIGHT"), 0.45),
            ai_endpoint=(env.get("ANTISPAM_AI_ENDPOINT") or env.get("AI_BASE_URL") or None),
            ai_api_key=(
                env.get("ANTISPAM_AI_API_KEY")
                or env.get("AI_API_KEY")
                or env.get("OPENAI_API_KEY")
                or None
            ),
            ai_model=(env.get("ANTISPAM_AI_MODEL") or env.get("AI_MODEL") or "gpt-4o-mini"),
            ai_timeout_seconds=_as_float(
                env.get("ANTISPAM_AI_TIMEOUT_SECONDS"),
                8.0,
                minimum=1.0,
                maximum=60.0,
            ),
            ai_candidate_threshold=_as_float(
                env.get("ANTISPAM_AI_CANDIDATE_THRESHOLD"),
                0.12,
            ),
            ai_max_concurrency=_as_int(
                env.get("ANTISPAM_AI_MAX_CONCURRENCY"),
                4,
                minimum=1,
                maximum=100,
            ),
            ai_queue_timeout_seconds=_as_float(
                env.get("ANTISPAM_AI_QUEUE_TIMEOUT_SECONDS"),
                0.25,
                minimum=0.01,
                maximum=1.0,
            ),
            max_content_chars=_as_int(
                env.get("ANTISPAM_MAX_CONTENT_CHARS"),
                4_000,
                minimum=256,
                maximum=20_000,
            ),
        )
        return cls(
            bot_token=env.get("BOT_TOKEN", "").strip(),
            database=database,
            classifier=classifier,
            owner_ids=_as_int_set(env.get("OWNER_IDS") or env.get("ANTISPAM_OWNER_IDS")),
            global_ban_strikes=_as_int(
                env.get("ANTISPAM_GLOBAL_BAN_STRIKES") or env.get("GLOBAL_BAN_STRIKES"),
                4,
                minimum=1,
                maximum=20,
            ),
            notice_ttl_seconds=_as_int(
                env.get("ANTISPAM_NOTICE_TTL_SECONDS") or env.get("NOTICE_DELETE_SECONDS"),
                10,
                minimum=1,
                maximum=3_600,
            ),
            send_action_notice=_as_bool(
                env.get("ANTISPAM_SEND_ACTION_NOTICE") or env.get("SEND_ACTION_NOTICE"),
                True,
            ),
            delete_service_messages=_as_bool(
                env.get("ANTISPAM_DELETE_SERVICE_MESSAGES") or env.get("DELETE_SERVICE_MESSAGES"),
                True,
            ),
            audit_content_excerpt_chars=_as_int(
                env.get("ANTISPAM_AUDIT_EXCERPT_CHARS"),
                240,
                minimum=32,
                maximum=2_000,
            ),
            log_level=(env.get("LOG_LEVEL") or "INFO").strip().upper(),
        )

    def require_bot_token(self) -> str:
        """Return the token or fail at startup without leaking its value."""

        if not self.bot_token:
            raise RuntimeError("BOT_TOKEN is required")
        return self.bot_token


# A convenient semantic alias for integrations that prefer AppConfig.
AppConfig = Settings
