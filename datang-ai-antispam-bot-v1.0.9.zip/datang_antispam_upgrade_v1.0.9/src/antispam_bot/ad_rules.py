"""Persistent, group-scoped rules explicitly taught by verified administrators.

Rules run locally before the existing classifier. They never train the remote
model or change another group's policy. A separate database keeps upgrades and
rollbacks independent from the existing offender schema.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import unicodedata
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

import aiosqlite

from .classifier import (
    _ADULT_AD_RE,
    _CAUTION_CONTEXT_RE,
    _CONTACT_RE,
    _GAMBLING_RE,
    _HANDLE_RE,
    _PROMOTION_RE,
    _SOLICITATION_RE,
    _URL_RE,
    _normalize,
    income_ad_categories,
)
from .content import rich_content
from .models import ClassificationVerdict, VerdictLabel, utc_now_iso

CATEGORY_NAMES = {
    "gambling": "博彩导流",
    "adult": "色情导流",
    "job_scam": "兼职返利",
    "marketing": "营销导流",
    "red_packet": "红包教程导流",
    "income_project": "赚钱项目导流",
}
CATEGORY_ALIASES = {
    "博彩": "gambling",
    "赌博": "gambling",
    "色情": "adult",
    "兼职": "job_scam",
    "返利": "job_scam",
    "营销": "marketing",
    "引流": "marketing",
    "红包": "red_packet",
    "口令红包": "red_packet",
    "赚钱": "income_project",
    "高收益": "income_project",
    "名片": "income_project",
    **{name: key for key, name in CATEGORY_NAMES.items()},
    **{key: key for key in CATEGORY_NAMES},
}
_JOB_RE = re.compile(r"(?:兼职|刷单|返利|日赚|躺赚|稳赚|包赚|无风险收益)")
_JOB_OFFER_RE = re.compile(r"(?:招聘|招募|加我|私聊|联系|加入|报名|入群|领取|赚|返佣|返利)")
_USERNAME_RE = re.compile(
    r"(?<![a-zA-Z0-9_@.+-])@[a-zA-Z][a-zA-Z0-9_]{2,31}(?![a-zA-Z0-9_]|\.[a-zA-Z])"
)
_BOT_COMMAND_RE = re.compile(r"/[a-zA-Z][a-zA-Z0-9_]{0,31}@[a-zA-Z][a-zA-Z0-9_]{2,31}\b")
_USERNAME_PATH_RE = re.compile(r"[a-zA-Z][a-zA-Z0-9_]{2,31}\Z")
_TELEGRAM_ROUTES = {
    "joinchat",
    "c",
    "share",
    "addstickers",
    "addemoji",
    "addtheme",
    "proxy",
    "socks",
    "login",
    "iv",
    "confirmphone",
    "boost",
    "invoice",
    "giftcode",
    "nft",
    "contact",
}
_SCHEMA = """
CREATE TABLE IF NOT EXISTS group_ad_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    kind TEXT NOT NULL,
    fingerprint TEXT NOT NULL,
    pattern TEXT NOT NULL DEFAULT '',
    media_key TEXT NOT NULL DEFAULT '',
    caution_sample INTEGER NOT NULL DEFAULT 0,
    created_by INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(chat_id, kind, fingerprint)
);
CREATE INDEX IF NOT EXISTS ix_group_ad_rules_chat ON group_ad_rules(chat_id);
CREATE TABLE IF NOT EXISTS group_ad_settings (
    chat_id INTEGER PRIMARY KEY,
    username_blocked INTEGER NOT NULL CHECK (username_blocked IN (0, 1)),
    updated_by INTEGER NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS group_join_verifications (
    chat_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    state TEXT NOT NULL,
    PRIMARY KEY (chat_id, user_id)
);
CREATE TABLE IF NOT EXISTS bot_subscribers (
    user_id INTEGER PRIMARY KEY,
    username TEXT NOT NULL DEFAULT '',
    display_name TEXT NOT NULL DEFAULT '',
    started INTEGER NOT NULL DEFAULT 0,
    blocked INTEGER NOT NULL DEFAULT 0,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS owner_panel_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS group_owner_policies (
    chat_id INTEGER PRIMARY KEY,
    require_username INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS group_category_policies (
    chat_id INTEGER NOT NULL,
    kind TEXT NOT NULL,
    enabled INTEGER NOT NULL,
    PRIMARY KEY(chat_id, kind)
);
"""


def category_key(value: str) -> str | None:
    return CATEGORY_ALIASES.get(_normalize(value).casefold())


def matching_categories(content: str) -> tuple[str, ...]:
    """Type means topic + solicitation + destination, never a topic word alone."""

    text = _normalize(content)[:4000]
    if _CAUTION_CONTEXT_RE.search(text):
        return ()
    matches = list(income_ad_categories(text))
    if not (_URL_RE.search(text) or _HANDLE_RE.search(text)):
        return tuple(matches)
    if _SOLICITATION_RE.search(text):
        if _GAMBLING_RE.search(text):
            matches.append("gambling")
        if _ADULT_AD_RE.search(text):
            matches.append("adult")
    if _JOB_RE.search(text) and _JOB_OFFER_RE.search(text):
        matches.append("job_scam")
    if _PROMOTION_RE.search(text) and _CONTACT_RE.search(text):
        matches.append("marketing")
    return tuple(matches)


def canonical_sample(content: str) -> str:
    """Ignore changed URLs, handles, amounts, case, whitespace and decoration."""

    text = _normalize(content).casefold()[:4000]
    text = _URL_RE.sub(" ", text)
    text = _HANDLE_RE.sub(" ", text)
    # Variable numbers are removed rather than becoming a distinctive feature.
    return "".join(c for c in text if c.isalpha() and unicodedata.category(c) != "Cf")


def destinations(content: str) -> tuple[str, ...]:
    """Exact addresses only, never expand a marked URL to an entire domain."""

    result: set[str] = set()
    normalized = _normalize(content)[:4000]
    # Explicit teaching of a lone handle remembers that destination only.
    result.update("t.me/" + h[1:].casefold() for h in _HANDLE_RE.findall(normalized))
    for raw in _URL_RE.findall(normalized):
        raw = raw.rstrip(".,;!?，。；！？)]}〉》\"'")
        try:
            url = urlsplit(raw if "://" in raw else "https://" + raw)
            if url.scheme == "tg":
                query = parse_qs(url.query)
                if url.netloc.casefold() == "user":
                    result.update("tg:user:" + v for v in query.get("id", []) if v.isdigit())
                elif url.netloc.casefold() == "resolve":
                    result.update(
                        "t.me/" + v.casefold()
                        for v in query.get("domain", [])
                        if _USERNAME_PATH_RE.fullmatch(v)
                    )
                continue
            if not url.netloc or url.scheme not in {"http", "https"}:
                continue
            host = (url.hostname or "").casefold().removeprefix("www.")
            path = unquote(url.path).strip("/")
            if (
                host in {"t.me", "telegram.me", "telegram.dog"}
                and _USERNAME_PATH_RE.fullmatch(path)
                and path not in _TELEGRAM_ROUTES
            ):
                result.add("t.me/" + path.casefold())
                continue
            result.add(
                url.netloc.casefold() + (url.path or "/") + ("?" + url.query if url.query else "")
            )
        except ValueError:
            continue
    return tuple(sorted(result))[:16]


def sample_kind(content: str, media: str) -> str:
    pattern = canonical_sample(content)
    if not media and (len(pattern) < 12 or len(set(pattern)) < 8) and destinations(content):
        return "link"
    return "sample"


def username_in_text(value: str, *, commands_allowed: bool = False) -> bool:
    text = _normalize(value)
    if commands_allowed:
        # /command@bot is a command address, not a shared contact handle.
        text = _BOT_COMMAND_RE.sub(" ", text)
    if _USERNAME_RE.search(text):
        return True
    for raw in _URL_RE.findall(text):
        try:
            url = urlsplit(raw if "://" in raw else "https://" + raw)
            if url.scheme == "tg":
                query = parse_qs(url.query)
                if url.netloc.casefold() == "user" and any(
                    v.isdigit() for v in query.get("id", [])
                ):
                    return True
                if url.netloc.casefold() == "resolve" and any(
                    _USERNAME_PATH_RE.fullmatch(v) for v in query.get("domain", [])
                ):
                    return True
            host = (url.hostname or "").casefold().removeprefix("www.")
            if host not in {"t.me", "telegram.me", "telegram.dog"}:
                continue
            parts = unquote(url.path).rstrip(".,;!?，。；！？)]}〉》\"'").strip("/").split("/")
            name = parts[1] if len(parts) > 1 and parts[0] == "s" else parts[0]
            if name not in _TELEGRAM_ROUTES and _USERNAME_PATH_RE.fullmatch(name):
                return True
        except ValueError:
            continue
    return False


def message_has_username(message: object) -> bool:
    """Inspect authored content, never the sender name or replied-to message."""

    rich = rich_content(message)
    if rich.has_user_mention or username_in_text(rich.text, commands_allowed=True):
        return True
    if any(username_in_text(url) for url in rich.links):
        return True
    for field in ("text", "caption"):
        value = getattr(message, field, None)
        if value and username_in_text(value, commands_allowed=True):
            return True
    for field in ("entities", "caption_entities"):
        for entity in getattr(message, field, None) or []:
            if entity.type in {"mention", "text_mention"}:
                return True
            url = getattr(entity, "url", None)
            if url and username_in_text(url):
                return True
    for row in getattr(getattr(message, "reply_markup", None), "inline_keyboard", None) or []:
        for button in row:
            for value in (getattr(button, "text", ""), getattr(button, "url", None)):
                if value and username_in_text(value):
                    return True
            for field in ("login_url", "web_app"):
                value = getattr(getattr(button, field, None), "url", None)
                if value and username_in_text(value):
                    return True
    contact = getattr(message, "contact", None)
    return any(
        username_in_text(getattr(contact, field, "") or "") for field in ("first_name", "last_name")
    )


def media_key(message: object) -> str:
    """Exact media identity or a taught contact's phone hash; no download/OCR."""

    contact = getattr(message, "contact", None)
    phone = getattr(contact, "phone_number", None)
    if isinstance(phone, str):
        digits = "".join(c for c in _normalize(phone) if c.isdecimal())
        if len(digits) >= 7:
            return "contact:" + hashlib.sha256(digits.encode()).hexdigest()
    photos = getattr(message, "photo", None)
    if photos:
        unique_id = getattr(photos[-1], "file_unique_id", None)
        if isinstance(unique_id, str) and unique_id:
            return "photo:" + unique_id
    for field in ("video", "animation", "document", "sticker", "video_note", "audio", "voice"):
        unique_id = getattr(getattr(message, field, None), "file_unique_id", None)
        if isinstance(unique_id, str) and unique_id:
            return field + ":" + unique_id
    rich = rich_content(message)
    if rich.media:
        return rich.media[0]
    return ""


@dataclass(frozen=True, slots=True)
class AdRule:
    id: int
    chat_id: int
    kind: str
    pattern: str
    media_key: str
    caution_sample: bool

    @property
    def name(self) -> str:
        if self.kind == "exact":
            return "主管理精确样本"
        if self.kind == "link":
            return "指定广告链接"
        return CATEGORY_NAMES.get(self.kind, "相似广告样本")


def _similar(left: str, right: str) -> bool:
    if not left or not right:
        return False
    if left == right:
        return True
    if (
        min(len(left), len(right)) < 20
        or min(len(left), len(right)) / max(len(left), len(right)) < 0.70
    ):
        return False
    a = {left[i : i + 3] for i in range(len(left) - 2)}
    b = {right[i : i + 3] for i in range(len(right) - 2)}
    return len(a & b) / len(a | b) >= 0.72


class AdRuleStore:
    MAX_RULES_PER_CHAT = 100
    MAX_CACHED_CHATS = 256

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self._connection: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()
        self._cache: OrderedDict[int, tuple[AdRule, ...]] = OrderedDict()
        self._username_cache: OrderedDict[int, bool] = OrderedDict()

    async def initialize(self) -> None:
        async with self._lock:
            if self._connection is not None:
                return
            self.path.parent.mkdir(parents=True, exist_ok=True)
            connection = await aiosqlite.connect(self.path)
            connection.row_factory = aiosqlite.Row
            try:
                await connection.execute("PRAGMA journal_mode=WAL")
                await connection.execute("PRAGMA busy_timeout=5000")
                await connection.executescript(_SCHEMA)
                await connection.commit()
            except BaseException:
                await connection.close()
                raise
            self._connection = connection

    def _conn(self) -> aiosqlite.Connection:
        if self._connection is None:
            raise RuntimeError("广告规则库尚未初始化")
        return self._connection

    async def close(self) -> None:
        async with self._lock:
            if self._connection is not None:
                await self._connection.close()
                self._connection = None
            self._cache.clear()
            self._username_cache.clear()

    async def remember_subscriber(
        self,
        user_id: int,
        username: str,
        display_name: str,
        *,
        started: bool = False,
    ) -> None:
        now = utc_now_iso()
        async with self._lock:
            try:
                await self._conn().execute(
                    "INSERT INTO bot_subscribers "
                    "(user_id,username,display_name,started,first_seen,last_seen) "
                    "VALUES (?,?,?,?,?,?) "
                    "ON CONFLICT(user_id) DO UPDATE SET username=excluded.username, "
                    "display_name=excluded.display_name, started=MAX(started,excluded.started), "
                    "blocked=0,last_seen=excluded.last_seen",
                    (user_id, username[:64], display_name[:128], int(started), now, now),
                )
                await self._conn().commit()
            except BaseException:
                await self._conn().rollback()
                raise

    async def subscriber_blocked(self, user_id: int, blocked: bool) -> None:
        async with self._lock:
            await self._conn().execute(
                "UPDATE bot_subscribers SET blocked=? WHERE user_id=?", (int(blocked), user_id)
            )
            await self._conn().commit()

    async def subscribers(self, page: int = 0) -> tuple[int, list[dict]]:
        async with self._lock:
            async with self._conn().execute("SELECT COUNT(*) FROM bot_subscribers") as cursor:
                count = (await cursor.fetchone())[0]
            async with self._conn().execute(
                "SELECT * FROM bot_subscribers ORDER BY first_seen DESC,user_id DESC "
                "LIMIT 10 OFFSET ?",
                (max(0, page) * 10,),
            ) as cursor:
                rows = await cursor.fetchall()
            return count, [dict(row) for row in rows]

    async def panel_setting(self, key: str) -> str:
        async with self._lock:
            async with self._conn().execute(
                "SELECT value FROM owner_panel_settings WHERE key=?", (key,)
            ) as cursor:
                row = await cursor.fetchone()
            return row[0] if row else ""

    async def set_panel_setting(self, key: str, value: str) -> None:
        async with self._lock:
            try:
                await self._conn().execute(
                    "INSERT INTO owner_panel_settings (key,value) VALUES (?,?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (key, value),
                )
                await self._conn().commit()
            except BaseException:
                await self._conn().rollback()
                raise

    async def username_required(self, chat_id: int) -> bool:
        async with self._lock:
            async with self._conn().execute(
                "SELECT require_username FROM group_owner_policies WHERE chat_id=?", (chat_id,)
            ) as cursor:
                row = await cursor.fetchone()
            return bool(row[0]) if row else False

    async def set_username_required(self, chat_id: int, enabled: bool) -> None:
        async with self._lock:
            try:
                await self._conn().execute(
                    "INSERT INTO group_owner_policies(chat_id,require_username) VALUES (?,?) "
                    "ON CONFLICT(chat_id) DO UPDATE SET require_username=excluded.require_username",
                    (chat_id, int(enabled)),
                )
                await self._conn().commit()
            except BaseException:
                await self._conn().rollback()
                raise

    async def category_policies(self, chat_id: int) -> dict[str, bool]:
        async with self._lock:
            async with self._conn().execute(
                "SELECT kind,enabled FROM group_category_policies WHERE chat_id=?", (chat_id,)
            ) as cursor:
                return {row[0]: bool(row[1]) for row in await cursor.fetchall()}

    async def set_category_policy(self, chat_id: int, kind: str, enabled: bool) -> None:
        if kind not in CATEGORY_NAMES:
            raise ValueError("未知广告类型")
        async with self._lock:
            try:
                await self._conn().execute(
                    "INSERT INTO group_category_policies(chat_id,kind,enabled) VALUES (?,?,?) "
                    "ON CONFLICT(chat_id,kind) DO UPDATE SET enabled=excluded.enabled",
                    (chat_id, kind, int(enabled)),
                )
                await self._conn().commit()
            except BaseException:
                await self._conn().rollback()
                raise

    async def get_verification(self, chat_id: int, user_id: int) -> dict | None:
        async with self._lock:
            async with self._conn().execute(
                "SELECT state FROM group_join_verifications WHERE chat_id=? AND user_id=?",
                (chat_id, user_id),
            ) as cursor:
                row = await cursor.fetchone()
            return json.loads(row[0]) if row else None

    async def save_verification(self, chat_id: int, user_id: int, state: dict) -> None:
        async with self._lock:
            try:
                await self._conn().execute(
                    "INSERT INTO group_join_verifications (chat_id,user_id,state) VALUES (?,?,?) "
                    "ON CONFLICT(chat_id,user_id) DO UPDATE SET state=excluded.state",
                    (chat_id, user_id, json.dumps(state)),
                )
                await self._conn().commit()
            except BaseException:
                await self._conn().rollback()
                raise

    async def delete_verification(self, chat_id: int, user_id: int) -> None:
        async with self._lock:
            try:
                await self._conn().execute(
                    "DELETE FROM group_join_verifications WHERE chat_id=? AND user_id=?",
                    (chat_id, user_id),
                )
                await self._conn().commit()
            except BaseException:
                await self._conn().rollback()
                raise

    async def unfinished_verifications(self) -> list[tuple[int, int, dict]]:
        async with self._lock:
            async with self._conn().execute(
                "SELECT chat_id,user_id,state FROM group_join_verifications"
            ) as cursor:
                rows = await cursor.fetchall()
        return [
            (row[0], row[1], state)
            for row in rows
            if not (state := json.loads(row[2])).get("passed") and not state.get("message_id")
        ]

    async def username_blocked(self, chat_id: int) -> bool:
        async with self._lock:
            if chat_id in self._username_cache:
                self._username_cache.move_to_end(chat_id)
                return self._username_cache[chat_id]
            async with self._conn().execute(
                "SELECT username_blocked FROM group_ad_settings WHERE chat_id = ?", (chat_id,)
            ) as cursor:
                row = await cursor.fetchone()
            # Requested group policy is enabled immediately for existing groups.
            enabled = bool(row[0]) if row is not None else True
            self._username_cache[chat_id] = enabled
            if len(self._username_cache) > self.MAX_CACHED_CHATS:
                self._username_cache.popitem(last=False)
            return enabled

    async def set_username_blocked(self, chat_id: int, actor_id: int, enabled: bool) -> None:
        async with self._lock:
            conn = self._conn()
            try:
                await conn.execute(
                    """INSERT INTO group_ad_settings
                    (chat_id, username_blocked, updated_by, updated_at) VALUES (?, ?, ?, ?)
                    ON CONFLICT(chat_id) DO UPDATE SET
                    username_blocked=excluded.username_blocked,
                    updated_by=excluded.updated_by, updated_at=excluded.updated_at""",
                    (chat_id, int(enabled), actor_id, utc_now_iso()),
                )
                await conn.commit()
            except BaseException:
                await conn.rollback()
                raise
            self._username_cache.pop(chat_id, None)

    async def list_rules(self, chat_id: int) -> tuple[AdRule, ...]:
        async with self._lock:
            if chat_id in self._cache:
                self._cache.move_to_end(chat_id)
                return self._cache[chat_id]
            async with self._conn().execute(
                "SELECT * FROM group_ad_rules WHERE chat_id = ? ORDER BY id", (chat_id,)
            ) as cursor:
                rows = await cursor.fetchall()
            rules = tuple(
                AdRule(
                    id=row["id"],
                    chat_id=row["chat_id"],
                    kind=row["kind"],
                    pattern=row["pattern"],
                    media_key=row["media_key"],
                    caution_sample=bool(row["caution_sample"]),
                )
                for row in rows
            )
            self._cache[chat_id] = rules
            if len(self._cache) > self.MAX_CACHED_CHATS:
                self._cache.popitem(last=False)
            return rules

    async def add_rule(
        self,
        chat_id: int,
        actor_id: int,
        *,
        kind: str,
        content: str = "",
        media: str = "",
        force: bool = False,
    ) -> tuple[int, bool]:
        if kind not in {*CATEGORY_NAMES, "sample", "link", "exact"}:
            raise ValueError("未知广告类型")
        if kind == "exact" and not force:
            raise ValueError("强制精确样本仅限主管理")
        pattern = canonical_sample(content) if kind == "sample" else ""
        if kind == "link":
            pattern = "\n".join(destinations(content))
            if not pattern:
                raise ValueError("样本没有可保存的网页链接。")
        if kind == "sample" and (len(pattern) < 12 or len(set(pattern)) < 8):
            if force:
                kind = "exact"
                pattern = _normalize(content).casefold()
            else:
                pattern = ""
            if not media and not force:
                raise ValueError("样本文字太短或只有链接。请选更完整的广告，或指定广告类型。")
        if kind == "exact":
            pattern = _normalize(content).casefold()
            if not pattern and not media:
                raise ValueError("消息没有可读取的匹配特征")
        media = media[:256] if kind in {"sample", "exact"} else ""
        fingerprint = hashlib.sha256((pattern + "\0" + media).encode()).hexdigest()
        async with self._lock:
            conn = self._conn()
            async with conn.execute(
                "SELECT id FROM group_ad_rules WHERE chat_id = ? AND kind = ? AND fingerprint = ?",
                (chat_id, kind, fingerprint),
            ) as cursor:
                existing = await cursor.fetchone()
            if existing is not None:
                return existing["id"], False
            async with conn.execute(
                "SELECT COUNT(*) FROM group_ad_rules WHERE chat_id = ?", (chat_id,)
            ) as cursor:
                count = (await cursor.fetchone())[0]
            if not force and count >= self.MAX_RULES_PER_CHAT:
                raise ValueError("本群已达到 100 条规则，请先用 /adforget 编号 撤销不需要的规则。")
            try:
                async with conn.execute(
                    """INSERT INTO group_ad_rules
                    (chat_id, kind, fingerprint, pattern, media_key, caution_sample,
                     created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        chat_id,
                        kind,
                        fingerprint,
                        pattern,
                        media,
                        int(bool(_CAUTION_CONTEXT_RE.search(_normalize(content)))),
                        actor_id,
                        utc_now_iso(),
                    ),
                ) as cursor:
                    rule_id = cursor.lastrowid
                await conn.commit()
            except BaseException:
                await conn.rollback()
                raise
            self._cache.pop(chat_id, None)
            assert rule_id is not None
            return rule_id, True

    async def remove_rule(self, chat_id: int, rule_id: int) -> bool:
        async with self._lock:
            try:
                async with self._conn().execute(
                    "DELETE FROM group_ad_rules WHERE chat_id = ? AND id = ?", (chat_id, rule_id)
                ) as cursor:
                    changed = cursor.rowcount > 0
                await self._conn().commit()
            except BaseException:
                await self._conn().rollback()
                raise
            self._cache.pop(chat_id, None)
            return changed

    async def match(self, chat_id: int, content: str, media: str = "") -> AdRule | None:
        rules = await self.list_rules(chat_id)
        if not rules:
            return None
        categories = matching_categories(content)
        pattern = canonical_sample(content)
        links = set(destinations(content))
        caution = bool(_CAUTION_CONTEXT_RE.search(_normalize(content)))
        for rule in rules:
            if rule.kind == "exact" and (
                (rule.pattern and _normalize(content).casefold() == rule.pattern)
                or (media and media == rule.media_key)
            ):
                return rule
            if rule.kind in categories:
                return rule
            if (
                rule.kind == "link"
                and (not caution or rule.caution_sample)
                and links.intersection(
                    set(rule.pattern.splitlines()) | set(destinations(rule.pattern))
                )
            ):
                return rule
            if rule.kind != "sample" or (caution and not rule.caution_sample):
                continue
            if (media and media == rule.media_key) or _similar(pattern, rule.pattern):
                return rule
        return None


def rule_verdict(rule: AdRule) -> ClassificationVerdict:
    return ClassificationVerdict(
        label=VerdictLabel.ADVERTISEMENT,
        confidence=1.0,
        reasons=(f"group_rule:{rule.id}:{rule.kind}",),
        source="group_rule",
        strong_content_evidence=True,
    )
