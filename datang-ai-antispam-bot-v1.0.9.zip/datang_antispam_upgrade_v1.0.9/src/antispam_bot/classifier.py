"""Hybrid ad classifier with deterministic offline behavior."""

from __future__ import annotations

import asyncio
import json
import re
import unicodedata
from dataclasses import dataclass
from typing import Any

import aiohttp

from .config import ClassifierConfig
from .models import ClassificationVerdict, SenderContext, VerdictLabel

_URL_RE = re.compile(
    r"(?:https?://|www\.|t\.me/|telegram\.me/|tg://)[^\s<>]+"
    r"|(?<![\w@])(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+"
    r"(?:com|net|org|cn|cc|io|co|me|app|xyz|top|vip|club|live|shop|site|online)"
    r"(?![a-z0-9_-])(?:/[^\s<>]*)?",
    re.IGNORECASE,
)
_TG_INVITE_RE = re.compile(
    r"(?:t\.me/(?:joinchat/|\+)|telegram\.me/(?:joinchat/|\+))[\w-]+",
    re.IGNORECASE,
)
_HANDLE_RE = re.compile(r"(?<!\w)@[a-zA-Z][a-zA-Z0-9_]{4,31}\b")
_CONTACT_RE = re.compile(
    r"(?:微信|威信|飞机|电报|telegram|whatsapp|line|客服|联系|私聊|私信|加我|"
    r"咨询|代理|渠道|供货|合作|contact|dm\s*me|inbox|customer\s*service)",
    re.IGNORECASE,
)
_PROMOTION_RE = re.compile(
    r"(?:广告|推广|引流|拉新|获客|刷粉|涨粉|代充|代付|接单|出货|出售|购买|"
    r"批发|零售|低价|特价|优惠|福利|返佣|返利|日赚|兼职|招募|招商|担保|"
    r"秒到账|稳赚|稳赚不赔|包赔|包过|免费领取|限时|名额有限|"
    r"promotion|advertis(?:e|ing)|discount|wholesale|reseller|affiliate|"
    r"earn\s+money|guaranteed\s+profit|limited\s+offer|buy\s+now)",
    re.IGNORECASE,
)
_TRANSACTION_RE = re.compile(
    r"(?:usdt|trc-?20|bep-?20|币安|支付宝|微信支付|收款|付款|交易|汇率|"
    r"跑分|洗钱|博彩|盘口|下注|娱乐城|虚拟币|充值|提现|"
    r"crypto|deposit|withdraw|payment)",
    re.IGNORECASE,
)
_PRICE_RE = re.compile(
    r"(?:[¥￥$€]\s*\d+(?:\.\d+)?|\d+(?:\.\d+)?\s*(?:元|块|u|usdt|刀))",
    re.IGNORECASE,
)
_CTA_RE = re.compile(
    r"(?:点击|扫码|进群|入群|加入|马上|立即|速来|详情|下单|购买|咨询|"
    r"click|join\s+(?:us|now)|order\s+now|sign\s*up)",
    re.IGNORECASE,
)
_NAME_AD_RE = re.compile(
    r"(?:客服|接单|招商|代理|渠道|供货|担保|推广|引流|代充|出售|商务|"
    r"service|support|seller|vendor|promo)",
    re.IGNORECASE,
)
_REPEATED_SYMBOL_RE = re.compile(r"([^\w\s])\1{3,}")
_GAMBLING_RE = re.compile(
    r"(?:百\s*家\s*乐|博\s*彩|赌\s*博|赌场|下注|娱乐城|真人娱乐场|"
    r"(?:ag|bg|pg)\s*(?:电子|博彩|真人)|casino|baccarat)",
    re.IGNORECASE,
)
_ADULT_AD_RE = re.compile(
    r"(?:色情|成人视频|成人直播|福利姬|偷拍|强奸|禁忌资源|裸聊|色情资源)",
    re.IGNORECASE,
)
_SOLICITATION_RE = re.compile(
    r"(?:开户|代开|可玩可代|可代|邀请码|联系|私聊|私信|加我|代理|充值|"
    r"下注|点我|点这里|点下方|点上方|点击|搜索|观看|试看|免费|领取|"
    r"福利|领\s*\d+|sign\s*up|contact|dm\s*me|click|join\s+now)",
    re.IGNORECASE,
)
_CAUTION_CONTEXT_RE = re.compile(
    r"(?:警惕|谨防|切勿|不要|勿信|远离|反诈|举报|曝光|科普|辟谣|"
    r"警方|新闻报道|骗局|法律案例|防范|禁止)",
    re.IGNORECASE,
)
_RED_PACKET_RE = re.compile(r"(?:支付宝\s*)?口\s*令\s*红\s*包")
_TUTORIAL_RE = re.compile(r"(?:教程|手把手|讲解|操作流程|玩法)")
_INCOME_TOPIC_RE = re.compile(r"(?:多一份收入|多份收入|赚钱|副业|兼职|额外收入|增加收入|收益项目)")
_PROJECT_CTA_RE = re.compile(
    r"(?:欢迎咨询|咨询|联系|私聊|私信|加我|了解详情|了解看看|看看具体|过来了解|点击)"
)
_INCOME_CLAIM_RE = re.compile(
    r"(?:一天|一日|每天|每日|每月|一月|每周|一周|日|月|周)\s*"
    r"(?:(?:能|可|轻松|稳定|躺着)\s*)?(?:赚|入|收入|收益|进账|到手)\s*[:：]?\s*"
    r"(?:\d+(?:\.\d+)?\s*(?:[kw千万百](?:元|块|u)?|元|块|u|刀)|\d{3,}|"
    r"[一二三四五六七八九十百千万]+(?:元|块))",
    re.IGNORECASE,
)
_CONTACT_CARD_RE = re.compile(
    r"联系人名片[:：]\s*(.{0,256}?)\s*名片电话[:：]\s*([+\d][\d ()-]{6,32})"
)
_EASY_PROJECT_RE = re.compile(
    r"(?:简单安全容易上手|(?:简单|容易|零基础|无门槛).{0,12}(?:上手|操作))"
)
_PROJECT_ASSURANCE_RE = re.compile(
    r"(?:没有任何弄虚作假|不弄虚作假|不用担心.{0,6}跑路|不会跑路|真实可靠|安全稳定)"
)


@dataclass(frozen=True, slots=True)
class _HeuristicResult:
    probability: float
    reasons: tuple[str, ...]
    strong_content_evidence: bool


@dataclass(frozen=True, slots=True)
class _AIResult:
    probability: float
    reasons: tuple[str, ...]


def _normalize(value: str) -> str:
    value = unicodedata.normalize("NFKC", value or "")
    value = "".join(char for char in value if unicodedata.category(char) != "Cf")
    value = " ".join(value.split())
    return value.strip()


def income_ad_categories(content: str) -> tuple[str, ...]:
    """Screenshot-derived combinations; no weight is given to a sender's name."""

    text = _normalize(content)
    if _CAUTION_CONTEXT_RE.search(text):
        return ()
    destination = bool(_URL_RE.search(text) or _HANDLE_RE.search(text))
    cta = bool(_PROJECT_CTA_RE.search(text))
    matches: list[str] = []
    if (
        _RED_PACKET_RE.search(text)
        and _TUTORIAL_RE.search(text)
        and _INCOME_TOPIC_RE.search(text)
        and cta
    ):
        matches.append("red_packet")
    card = _CONTACT_CARD_RE.search(text)
    income_card = card is not None and _INCOME_CLAIM_RE.search(card[1]) is not None
    project_pitch = (
        destination
        and cta
        and (
            _INCOME_CLAIM_RE.search(text)
            or (_EASY_PROJECT_RE.search(text) and len(_PROJECT_ASSURANCE_RE.findall(text)) >= 2)
        )
    )
    if income_card or project_pitch:
        matches.append("income_project")
    return tuple(matches)


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


class HybridAdClassifier:
    """Classify text using local rules, optionally augmented by an LLM.

    Results are deterministic when no endpoint is configured or when the
    endpoint fails. Network/API errors never interrupt message handling.
    """

    def __init__(
        self,
        config: ClassifierConfig | None = None,
        session: aiohttp.ClientSession | None = None,
    ) -> None:
        self.config = config or ClassifierConfig()
        self._session = session
        self._owns_session = False
        self._ai_semaphore = asyncio.Semaphore(self.config.ai_max_concurrency)

    async def __aenter__(self) -> HybridAdClassifier:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    async def close(self) -> None:
        if self._owns_session and self._session is not None:
            await self._session.close()
        self._session = None
        self._owns_session = False

    async def classify(
        self,
        text: str | None,
        *,
        nickname: str = "",
        username: str = "",
        sender_is_bot: bool = False,
        sender_is_admin: bool = False,
        exempt: bool = False,
    ) -> ClassificationVerdict:
        """Return a structured verdict.

        ``sender_is_bot`` is context, not a blanket exemption: spam bots should
        still be moderated. Administrators and explicitly allowlisted senders
        return a clean verdict so an enforcement caller cannot accidentally
        punish them.
        """

        if sender_is_admin or exempt:
            return ClassificationVerdict(
                label=VerdictLabel.CLEAN,
                confidence=0.0,
                reasons=("sender_exempt",),
                source="exemption",
            )

        content = _normalize(text or "")[: self.config.max_content_chars]
        display_name = _normalize(nickname)[:256]
        account_name = _normalize(username).lstrip("@")[:64]
        heuristic = self._classify_heuristically(
            content,
            display_name,
            account_name,
            sender_is_bot=sender_is_bot,
        )

        ai_result: _AIResult | None = None
        if (
            self.config.ai_enabled
            and heuristic.probability >= self.config.ai_candidate_threshold
            and (content or display_name or account_name)
        ):
            acquired = False
            try:
                await asyncio.wait_for(
                    self._ai_semaphore.acquire(),
                    timeout=self.config.ai_queue_timeout_seconds,
                )
                acquired = True
                ai_result = await self._classify_with_ai(
                    content,
                    display_name,
                    account_name,
                )
            except TimeoutError:
                # Under a burst, return the deterministic result immediately
                # instead of building an unbounded remote-AI wait queue.
                ai_result = None
            finally:
                if acquired:
                    self._ai_semaphore.release()

        probability = heuristic.probability
        reasons = list(heuristic.reasons)
        source = "heuristic"
        ai_confidence: float | None = None
        if ai_result is not None:
            weight = self.config.ai_weight
            blended_probability = (
                heuristic.probability * (1.0 - weight) + ai_result.probability * weight
            )
            # A remote model may strengthen a local result, but it cannot
            # downgrade a strong deterministic advertisement verdict.
            probability = (
                max(heuristic.probability, blended_probability)
                if heuristic.probability >= self.config.ad_threshold
                else blended_probability
            )
            if (
                heuristic.probability >= self.config.ad_threshold
                and ai_result.probability >= self.config.ad_threshold
            ):
                probability = min(1.0, probability + 0.08)
            reasons.extend(ai_result.reasons)
            source = "hybrid"
            ai_confidence = ai_result.probability

        probability = round(_clamp(probability), 4)
        if probability >= self.config.ad_threshold:
            label = VerdictLabel.ADVERTISEMENT
        elif probability >= self.config.suspicious_threshold:
            label = VerdictLabel.SUSPICIOUS
        else:
            label = VerdictLabel.CLEAN

        return ClassificationVerdict(
            label=label,
            confidence=probability,
            reasons=tuple(dict.fromkeys(reasons)),
            source=source,
            heuristic_confidence=round(heuristic.probability, 4),
            ai_confidence=ai_confidence,
            strong_content_evidence=heuristic.strong_content_evidence,
        )

    async def classify_message(
        self,
        text: str | None,
        sender: SenderContext,
    ) -> ClassificationVerdict:
        """Convenience adapter for handler code using ``SenderContext``."""

        return await self.classify(
            text,
            nickname=sender.nickname,
            username=sender.username,
            sender_is_bot=sender.is_bot,
            sender_is_admin=(sender.is_admin or sender.is_anonymous_admin),
            exempt=sender.explicitly_exempt,
        )

    def _classify_heuristically(
        self,
        content: str,
        nickname: str,
        username: str,
        *,
        sender_is_bot: bool,
    ) -> _HeuristicResult:
        score = 0.0
        reasons: list[str] = []
        strong_signals = 0

        urls = list(dict.fromkeys(_URL_RE.findall(content)))
        handles = _HANDLE_RE.findall(content)
        promo_hits = _PROMOTION_RE.findall(content)

        if urls:
            score += min(0.34, 0.22 + (len(urls) - 1) * 0.06)
            reasons.append("external_link")
        if _TG_INVITE_RE.search(content):
            score += 0.24
            strong_signals += 1
            reasons.append("telegram_invite")
        if handles:
            score += min(0.18, 0.08 + (len(handles) - 1) * 0.04)
            reasons.append("contact_handle")
        if _CONTACT_RE.search(content):
            score += 0.15
            strong_signals += 1
            reasons.append("contact_or_sales_language")
        if promo_hits:
            score += min(0.40, 0.18 + (len(promo_hits) - 1) * 0.07)
            strong_signals += 1
            reasons.append("promotion_language")
        if _TRANSACTION_RE.search(content):
            score += 0.12
            reasons.append("transaction_language")
        if _PRICE_RE.search(content):
            score += 0.13
            strong_signals += 1
            reasons.append("price_or_payment_offer")
        if _CTA_RE.search(content):
            score += 0.13
            strong_signals += 1
            reasons.append("call_to_action")
        if _REPEATED_SYMBOL_RE.search(content):
            score += 0.06
            reasons.append("attention_grabbing_format")
        if len(urls) + len(handles) >= 3:
            score += 0.12
            strong_signals += 1
            reasons.append("multiple_destinations")
        if strong_signals >= 3:
            score += 0.16
            reasons.append("multiple_commercial_signals")

        identity = f"{nickname} {username}".strip()
        if identity and _NAME_AD_RE.search(identity):
            # Identity is deliberately weak evidence and never counts as a
            # strong content signal for the global registry.
            score += 0.16
            reasons.append("sales_like_sender_name")

        if sender_is_bot and strong_signals:
            score += 0.04
            reasons.append("automated_sender_with_ad_signals")

        # Link + commercial/contact language is materially stronger than either
        # alone. This makes the rules useful offline without treating ordinary
        # shared links as advertisements.
        if urls and strong_signals >= 2:
            score += 0.16
            reasons.append("combined_ad_pattern")
        if not content and identity:
            score = min(score, self.config.suspicious_threshold - 0.01)

        # Require a destination AND active solicitation, not merely a sensitive
        # word. Reporting/warning contexts do not get this high-confidence boost.
        targeted_ad = False
        if (
            (urls or handles)
            and _SOLICITATION_RE.search(content)
            and not _CAUTION_CONTEXT_RE.search(content)
        ):
            if _GAMBLING_RE.search(content):
                score = max(score, 0.94)
                targeted_ad = True
                reasons.append("gambling_ad_with_destination")
            if _ADULT_AD_RE.search(content):
                score = max(score, 0.94)
                targeted_ad = True
                reasons.append("adult_ad_with_destination")

        for category in income_ad_categories(content):
            score = max(score, 0.96)
            targeted_ad = True
            reasons.append(f"{category}_advertisement")

        strong_content_evidence = bool(content) and (
            targeted_ad or (bool(urls or handles) and strong_signals >= 2) or strong_signals >= 3
        )
        return _HeuristicResult(
            probability=_clamp(score),
            reasons=tuple(reasons),
            strong_content_evidence=strong_content_evidence,
        )

    async def _classify_with_ai(
        self,
        content: str,
        nickname: str,
        username: str,
    ) -> _AIResult | None:
        endpoint = (self.config.ai_endpoint or "").rstrip("/")
        if endpoint.endswith("/v1"):
            endpoint += "/chat/completions"
        if not endpoint:
            return None

        if self._session is None:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self.config.ai_timeout_seconds)
            )
            self._owns_session = True

        headers = {"Content-Type": "application/json"}
        if self.config.ai_api_key:
            headers["Authorization"] = f"Bearer {self.config.ai_api_key}"

        system_prompt = (
            "You are a conservative Telegram anti-spam classifier. Decide if "
            "the message is unsolicited commercial advertising or spam. A normal "
            "conversation, a single informational link, discussion of payments, "
            "or a sales-like nickname alone is not enough. Return JSON only: "
            '{"is_ad": boolean, "confidence": number from 0 to 1, '
            '"reasons": [up to 3 short reason codes]}.'
        )
        user_payload = {
            "message": content,
            "sender_nickname": nickname,
            "sender_username": username,
        }
        payload: dict[str, Any] = {
            "model": self.config.ai_model,
            "temperature": 0,
            "messages": [
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": json.dumps(user_payload, ensure_ascii=False),
                },
            ],
            "response_format": {"type": "json_object"},
        }

        try:
            async with self._session.post(
                endpoint,
                json=payload,
                headers=headers,
            ) as response:
                response.raise_for_status()
                body = await response.json(content_type=None)
            raw_content = body["choices"][0]["message"]["content"]
            parsed = self._parse_ai_json(raw_content)
            is_ad = parsed.get("is_ad") is True
            confidence = _clamp(float(parsed.get("confidence", 0.0)))
            probability = confidence if is_ad else 1.0 - confidence
            raw_reasons = parsed.get("reasons", [])
            if not isinstance(raw_reasons, list):
                raw_reasons = []
            reasons = tuple(
                f"ai:{str(reason)[:80]}" for reason in raw_reasons[:3] if str(reason).strip()
            )
            return _AIResult(probability=probability, reasons=reasons)
        except (
            aiohttp.ClientError,
            TimeoutError,
            KeyError,
            TypeError,
            ValueError,
            json.JSONDecodeError,
        ):
            return None

    @staticmethod
    def _parse_ai_json(value: Any) -> dict[str, Any]:
        if isinstance(value, dict):
            return value
        if not isinstance(value, str):
            raise TypeError("AI content must be text or an object")
        start = value.find("{")
        end = value.rfind("}")
        if start < 0 or end < start:
            raise ValueError("AI response did not contain JSON")
        parsed = json.loads(value[start : end + 1])
        if not isinstance(parsed, dict):
            raise TypeError("AI JSON must be an object")
        return parsed
