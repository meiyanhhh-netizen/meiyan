"""Core package for the Datang AI anti-spam Telegram bot."""

from .classifier import HybridAdClassifier
from .config import ClassifierConfig, DatabaseConfig, Settings
from .db import Database
from .models import (
    ClassificationVerdict,
    InfractionOutcome,
    OffenderRecord,
    SenderContext,
    VerdictLabel,
)

__all__ = [
    "ClassificationVerdict",
    "ClassifierConfig",
    "Database",
    "DatabaseConfig",
    "HybridAdClassifier",
    "InfractionOutcome",
    "OffenderRecord",
    "SenderContext",
    "Settings",
    "VerdictLabel",
]
